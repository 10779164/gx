/*
Navicat MySQL Data Transfer

Source Server         : 25.156
Source Server Version : 50636
Source Host           : 47.93.25.156:33065
Source Database       : wgi_20170822

Target Server Type    : MYSQL
Target Server Version : 50636
File Encoding         : 65001

Date: 2017-09-05 15:57:43
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wgi_access
-- ----------------------------
DROP TABLE IF EXISTS `wgi_access`;
CREATE TABLE `wgi_access` (
  `role_id` smallint(6) unsigned NOT NULL,
  `node_id` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) NOT NULL,
  `module` varchar(50) DEFAULT NULL,
  KEY `groupId` (`role_id`),
  KEY `nodeId` (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_access
-- ----------------------------
INSERT INTO `wgi_access` VALUES ('1', '46', '2', null);
INSERT INTO `wgi_access` VALUES ('1', '45', '2', null);
INSERT INTO `wgi_access` VALUES ('1', '44', '2', null);
INSERT INTO `wgi_access` VALUES ('1', '43', '2', null);
INSERT INTO `wgi_access` VALUES ('1', '42', '2', null);
INSERT INTO `wgi_access` VALUES ('1', '41', '2', null);
INSERT INTO `wgi_access` VALUES ('1', '40', '2', null);
INSERT INTO `wgi_access` VALUES ('1', '39', '2', null);
INSERT INTO `wgi_access` VALUES ('1', '1', '1', null);
INSERT INTO `wgi_access` VALUES ('2', '45', '2', null);
INSERT INTO `wgi_access` VALUES ('2', '44', '2', null);
INSERT INTO `wgi_access` VALUES ('2', '43', '2', null);
INSERT INTO `wgi_access` VALUES ('2', '42', '2', null);
INSERT INTO `wgi_access` VALUES ('2', '41', '2', null);
INSERT INTO `wgi_access` VALUES ('2', '40', '2', null);
INSERT INTO `wgi_access` VALUES ('2', '39', '2', null);
INSERT INTO `wgi_access` VALUES ('2', '1', '1', null);

-- ----------------------------
-- Table structure for wgi_admin
-- ----------------------------
DROP TABLE IF EXISTS `wgi_admin`;
CREATE TABLE `wgi_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `username` varchar(50) DEFAULT NULL COMMENT '账号',
  `userpass` char(32) DEFAULT NULL COMMENT '密码',
  `realname` varchar(20) DEFAULT NULL COMMENT '称呼',
  `role_id` int(1) DEFAULT NULL COMMENT '角色',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态（0-停用，1-启用）',
  `delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '删除（0-显示，1-删除）',
  `login_ip` varchar(32) DEFAULT NULL COMMENT '登陆IP',
  `login_num` int(11) DEFAULT '0' COMMENT '登陆次数',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='后台管理员';

-- ----------------------------
-- Records of wgi_admin
-- ----------------------------
INSERT INTO `wgi_admin` VALUES ('1', 'admin', '21232f297a57a5a743894a0e4a801fc3', '超级管理员', '0', '1', '0', null, '0');

-- ----------------------------
-- Table structure for wgi_cash
-- ----------------------------
DROP TABLE IF EXISTS `wgi_cash`;
CREATE TABLE `wgi_cash` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `remark` text,
  `content` text,
  `type` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `bank` varchar(50) DEFAULT NULL,
  `recom` int(1) DEFAULT '0',
  `status` int(1) DEFAULT '0',
  `cash_id` int(11) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `delete` int(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='出售现金币';

-- ----------------------------
-- Records of wgi_cash
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_change_log
-- ----------------------------
DROP TABLE IF EXISTS `wgi_change_log`;
CREATE TABLE `wgi_change_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(50) DEFAULT NULL,
  `type` int(11) DEFAULT NULL COMMENT '1-推荐奖 2-见点奖 3-对碰奖 4-领导奖',
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `change_id` int(11) DEFAULT NULL,
  `change_username` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `title_en` varchar(255) DEFAULT NULL,
  `title_sp` varchar(255) DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=284 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of wgi_change_log
-- ----------------------------
INSERT INTO `wgi_change_log` VALUES ('260', 'CB6663484', '1', '123', 'tang001', '204', 'tang002', '5.00', 'tang002(1 星) 注册,您获得 推荐奖 $5.00', 'tang002(1 Star) registered, you get Referral Bonus $5.00', null, '2017-09-05', '2017-09-05 14:27:04');
INSERT INTO `wgi_change_log` VALUES ('261', 'CB9796740', '2', '123', 'tang001', '204', 'tang002', '0.50', 'tang002(1 星) 注册,您获得 见点奖 $0.5', 'tang002(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-05', '2017-09-05 14:27:04');
INSERT INTO `wgi_change_log` VALUES ('262', 'CB3453233', '1', '123', 'tang001', '206', 'tang003', '5.00', 'tang003(1 星) 注册,您获得 推荐奖 $5.00', 'tang003(1 Star) registered, you get Referral Bonus $5.00', null, '2017-09-05', '2017-09-05 15:12:28');
INSERT INTO `wgi_change_log` VALUES ('263', 'CB4074615', '2', '123', 'tang001', '206', 'tang003', '0.50', 'tang003(1 星) 注册,您获得 见点奖 $0.5', 'tang003(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-05', '2017-09-05 15:12:28');
INSERT INTO `wgi_change_log` VALUES ('264', 'CB1263372', '3', '123', 'tang001', '206', 'tang003', '5.00', 'tang003(1 星) 注册,您获得 对碰奖 $5', 'tang003(1 Star) registered, you get Referral Bonus $5', null, '2017-09-05', '2017-09-05 15:12:28');
INSERT INTO `wgi_change_log` VALUES ('265', 'CB9043494', '1', '123', 'tang001', '207', 'tang004', '5.00', 'tang004(1 星) 注册,您获得 推荐奖 $5.00', 'tang004(1 Star) registered, you get Referral Bonus $5.00', null, '2017-09-05', '2017-09-05 15:15:34');
INSERT INTO `wgi_change_log` VALUES ('266', 'CB6471607', '2', '124', 'tang002', '207', 'tang004', '0.50', 'tang004(1 星) 注册,您获得 见点奖 $0.5', 'tang004(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-05', '2017-09-05 15:15:34');
INSERT INTO `wgi_change_log` VALUES ('267', 'CB2736374', '2', '123', 'tang001', '207', 'tang004', '0.50', 'tang004(1 星) 注册,您获得 见点奖 $0.5', 'tang004(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-05', '2017-09-05 15:15:34');
INSERT INTO `wgi_change_log` VALUES ('268', 'CB1079915', '1', '124', 'tang002', '208', 'tang005', '5.00', 'tang005(1 星) 注册,您获得 推荐奖 $5.00', 'tang005(1 Star) registered, you get Referral Bonus $5.00', null, '2017-09-05', '2017-09-05 15:23:23');
INSERT INTO `wgi_change_log` VALUES ('269', 'CB2573720', '2', '124', 'tang002', '208', 'tang005', '0.50', 'tang005(1 星) 注册,您获得 见点奖 $0.5', 'tang005(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-05', '2017-09-05 15:23:23');
INSERT INTO `wgi_change_log` VALUES ('270', 'CB6804548', '2', '123', 'tang001', '208', 'tang005', '0.50', 'tang005(1 星) 注册,您获得 见点奖 $0.5', 'tang005(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-05', '2017-09-05 15:23:23');
INSERT INTO `wgi_change_log` VALUES ('271', 'CB7239682', '3', '124', 'tang002', '208', 'tang005', '5.00', 'tang005(1 星) 注册,您获得 对碰奖 $5', 'tang005(1 Star) registered, you get Referral Bonus $5', null, '2017-09-05', '2017-09-05 15:23:23');
INSERT INTO `wgi_change_log` VALUES ('272', 'CB3341946', '4', '123', 'tang001', '208', 'tang005', '0.10', 'tang005(1 星) 注册,您获得 领导奖 $0.1', 'tang005(1 Star) registered, you get Referral Bonus $0.1', null, '2017-09-05', '2017-09-05 15:23:23');
INSERT INTO `wgi_change_log` VALUES ('273', 'CB4921441', '1', '123', 'tang001', '209', 'juanjuan', '5.00', 'juanjuan(1 星) 注册,您获得 推荐奖 $5.00', 'juanjuan(1 Star) registered, you get Referral Bonus $5.00', null, '2017-09-05', '2017-09-05 15:29:59');
INSERT INTO `wgi_change_log` VALUES ('274', 'CB5428217', '2', '128', 'tang004', '209', 'juanjuan', '0.50', 'juanjuan(1 星) 注册,您获得 见点奖 $0.5', 'juanjuan(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-05', '2017-09-05 15:29:59');
INSERT INTO `wgi_change_log` VALUES ('275', 'CB4255420', '2', '124', 'tang002', '209', 'juanjuan', '0.50', 'juanjuan(1 星) 注册,您获得 见点奖 $0.5', 'juanjuan(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-05', '2017-09-05 15:29:59');
INSERT INTO `wgi_change_log` VALUES ('276', 'CB7684195', '2', '123', 'tang001', '209', 'juanjuan', '0.50', 'juanjuan(1 星) 注册,您获得 见点奖 $0.5', 'juanjuan(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-05', '2017-09-05 15:29:59');
INSERT INTO `wgi_change_log` VALUES ('277', 'CB4415794', '1', '123', 'tang001', '211', 'tang006', '6.00', 'tang006(1 星) 注册,您获得 推荐奖 $6.00', 'tang006(1 Star) registered, you get Referral Bonus $6.00', null, '2017-09-05', '2017-09-05 15:35:46');
INSERT INTO `wgi_change_log` VALUES ('278', 'CB2763317', '2', '127', 'tang003', '211', 'tang006', '0.50', 'tang006(1 星) 注册,您获得 见点奖 $0.5', 'tang006(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-05', '2017-09-05 15:35:46');
INSERT INTO `wgi_change_log` VALUES ('279', 'CB9715987', '1', '123', 'tang001', '213', 'tang007', '60.00', 'tang007(3 星) 注册,您获得 推荐奖 $60.00', 'tang007(3 Star) registered, you get Referral Bonus $60.00', null, '2017-09-05', '2017-09-05 15:52:28');
INSERT INTO `wgi_change_log` VALUES ('280', 'CB6882826', '2', '131', 'tang006', '213', 'tang007', '5.00', 'tang007(3 星) 注册,您获得 见点奖 $5', 'tang007(3 Star) registered, you get Referral Bonus $5', null, '2017-09-05', '2017-09-05 15:52:28');
INSERT INTO `wgi_change_log` VALUES ('281', 'CB5394254', '2', '127', 'tang003', '213', 'tang007', '5.00', 'tang007(3 星) 注册,您获得 见点奖 $5', 'tang007(3 Star) registered, you get Referral Bonus $5', null, '2017-09-05', '2017-09-05 15:52:28');
INSERT INTO `wgi_change_log` VALUES ('282', 'CB2912610', '2', '123', 'tang001', '213', 'tang007', '5.00', 'tang007(3 星) 注册,您获得 见点奖 $5', 'tang007(3 Star) registered, you get Referral Bonus $5', null, '2017-09-05', '2017-09-05 15:52:28');
INSERT INTO `wgi_change_log` VALUES ('283', 'CB2175793', '3', '123', 'tang001', '213', 'tang007', '42.00', 'tang007(3 星) 注册,您获得 对碰奖 $42', 'tang007(3 Star) registered, you get Referral Bonus $42', null, '2017-09-05', '2017-09-05 15:52:28');

-- ----------------------------
-- Table structure for wgi_change_log_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_change_log_info`;
CREATE TABLE `wgi_change_log_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `touch_price` decimal(10,2) DEFAULT '0.00' COMMENT '对碰奖',
  `recom_price` decimal(10,2) DEFAULT '0.00' COMMENT '推荐奖',
  `dot_price` decimal(10,2) DEFAULT '0.00' COMMENT '见点奖',
  `leader_price` decimal(10,2) DEFAULT '0.00' COMMENT '领导奖',
  `dz_price` decimal(10,2) DEFAULT '0.00' COMMENT '电子币',
  `title` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of wgi_change_log_info
-- ----------------------------
INSERT INTO `wgi_change_log_info` VALUES ('73', '123', 'tang001', '52.00', '86.00', '7.50', '0.10', '0.00', null, '2017-09-05', '2017-09-05 14:27:04');
INSERT INTO `wgi_change_log_info` VALUES ('74', '124', 'tang002', '5.00', '5.00', '1.50', '0.00', '0.00', null, '2017-09-05', '2017-09-05 15:15:34');
INSERT INTO `wgi_change_log_info` VALUES ('75', '128', 'tang004', '0.00', '0.00', '0.50', '0.00', '0.00', null, '2017-09-05', '2017-09-05 15:29:59');
INSERT INTO `wgi_change_log_info` VALUES ('76', '127', 'tang003', '0.00', '0.00', '5.50', '0.00', '0.00', null, '2017-09-05', '2017-09-05 15:35:46');
INSERT INTO `wgi_change_log_info` VALUES ('77', '131', 'tang006', '0.00', '0.00', '5.00', '0.00', '0.00', null, '2017-09-05', '2017-09-05 15:52:28');

-- ----------------------------
-- Table structure for wgi_coin_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_coin_info`;
CREATE TABLE `wgi_coin_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `number` int(11) DEFAULT '0',
  `status` int(1) DEFAULT '0',
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_coin_info
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_config
-- ----------------------------
DROP TABLE IF EXISTS `wgi_config`;
CREATE TABLE `wgi_config` (
  `key` varchar(255) DEFAULT NULL COMMENT '键',
  `val` varchar(255) DEFAULT NULL COMMENT '值',
  `note` varchar(255) DEFAULT NULL COMMENT '说明'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='系统配置表';

-- ----------------------------
-- Records of wgi_config
-- ----------------------------
INSERT INTO `wgi_config` VALUES ('sell_stock_switch', '1', '卖出股份开关（1-开启，0-关闭）');
INSERT INTO `wgi_config` VALUES ('sell_stock_sxf_ratio', '0.1', '卖出股份手续费比例');
INSERT INTO `wgi_config` VALUES ('sell_stock_xjb_ratio', '0.6', '卖出股份转现金币比例');
INSERT INTO `wgi_config` VALUES ('sell_stock_dzb_ratio', '0.3', '卖出股份转电子币比例');
INSERT INTO `wgi_config` VALUES ('sell_stock_jf_ratio', '0.1', '卖出股份转积分比例');
INSERT INTO `wgi_config` VALUES ('buy_xjb_switch', '0', '现金币购买开关（1-开启，0-关闭）');
INSERT INTO `wgi_config` VALUES ('buy_xjb_ratio', '0.9', '现金币购买优惠');
INSERT INTO `wgi_config` VALUES ('sell_xjb_switch', '1', '现金币出售开关（1-开启，0-关闭）');
INSERT INTO `wgi_config` VALUES ('sell_xjb_ratio', '0.1', '现金币出售手续费');
INSERT INTO `wgi_config` VALUES ('jj_to_xjb_ratio', '0.8', '动态奖转现金币比例');
INSERT INTO `wgi_config` VALUES ('jj_to_zcb_ratio', '0.2', '动态奖转注册币比例');
INSERT INTO `wgi_config` VALUES ('full_stock_double', '1.5', '爆仓（用户持有的股份数量与投资额倍数）');
INSERT INTO `wgi_config` VALUES ('full_stock_sell_ratio', '0.6', '爆仓后自动卖出股份的比例');
INSERT INTO `wgi_config` VALUES ('pay_max_times', '24', '打款超时时间（小时）');
INSERT INTO `wgi_config` VALUES ('enter_max_times', '24', '收款超时时间（小时）');
INSERT INTO `wgi_config` VALUES ('usb_to_rmb_ratio', '7', '美元兑人民币的汇率');
INSERT INTO `wgi_config` VALUES ('split_stock_double', '2', '股份和股价拆分倍数');
INSERT INTO `wgi_config` VALUES ('again_invest_max_days', '7', '会员复投时间（天）');
INSERT INTO `wgi_config` VALUES ('b_to_xjb_ratio', '0.1', 'B钱包解冻转现金币比例');
INSERT INTO `wgi_config` VALUES ('start_stock_num', '500000', '原始股份数量');

-- ----------------------------
-- Table structure for wgi_config_member_level
-- ----------------------------
DROP TABLE IF EXISTS `wgi_config_member_level`;
CREATE TABLE `wgi_config_member_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL COMMENT '级别名称',
  `en_title` varchar(50) DEFAULT NULL COMMENT '级别名称--英文',
  `price` int(11) NOT NULL DEFAULT '0' COMMENT '投资金额 ($)',
  `matching_ratio` float(8,4) DEFAULT NULL COMMENT '波比率',
  `dot_ratio` float(8,4) DEFAULT NULL COMMENT '见点奖比例',
  `dot_layer` int(3) DEFAULT NULL COMMENT '见点奖层数',
  `recom_reward` float(8,4) DEFAULT NULL COMMENT '直推奖比例',
  `touch_reward` float(8,4) DEFAULT NULL COMMENT '对碰奖比例',
  `leader_reward` float(8,4) DEFAULT NULL COMMENT '管理奖比例',
  `leader_layer` int(3) DEFAULT NULL COMMENT '管理奖代数',
  `touch_day_max` int(10) DEFAULT NULL COMMENT '动态奖日封顶数',
  `share_holding_max` int(10) DEFAULT NULL COMMENT '账户持股最大值',
  `status_profit_max` int(10) NOT NULL COMMENT '静态收益最大值',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否开放(0-未开放，1-开放)',
  `delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除（0-不删除，1-删除）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='会员级别参数设置';

-- ----------------------------
-- Records of wgi_config_member_level
-- ----------------------------
INSERT INTO `wgi_config_member_level` VALUES ('1', '1星', '1 Star', '100', '0.5000', '0.0050', '5', '0.0500', '0.0500', '0.0200', '1', '100', '150', '440', '1', '0');
INSERT INTO `wgi_config_member_level` VALUES ('2', '2星', '2 Star', '500', '0.5200', '0.0050', '7', '0.0600', '0.0600', '0.0200', '1', '500', '750', '2200', '1', '0');
INSERT INTO `wgi_config_member_level` VALUES ('3', '3星', '3 Star', '1000', '0.5400', '0.0050', '10', '0.0700', '0.0700', '0.0300', '2', '1000', '1500', '4400', '1', '0');
INSERT INTO `wgi_config_member_level` VALUES ('4', '4星', '4 Star', '3000', '0.5600', '0.0050', '13', '0.0800', '0.0800', '0.0300', '2', '3000', '4500', '13200', '0', '0');
INSERT INTO `wgi_config_member_level` VALUES ('5', '5星', '5 Star', '5000', '0.5800', '0.0050', '15', '0.0900', '0.0900', '0.0500', '3', '5000', '7500', '22000', '0', '0');
INSERT INTO `wgi_config_member_level` VALUES ('6', '6星', '6 Star', '10000', '0.6000', '0.0050', '20', '0.1000', '0.1000', '0.0500', '3', '10000', '15000', '44000', '0', '0');

-- ----------------------------
-- Table structure for wgi_country
-- ----------------------------
DROP TABLE IF EXISTS `wgi_country`;
CREATE TABLE `wgi_country` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cn_name` varchar(50) DEFAULT NULL,
  `en_name` varchar(50) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `sort` int(11) DEFAULT '0',
  `status` int(1) DEFAULT '1',
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_country
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_delete
-- ----------------------------
DROP TABLE IF EXISTS `wgi_delete`;
CREATE TABLE `wgi_delete` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `delete_id` int(11) DEFAULT NULL,
  `delete_table` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(50) DEFAULT NULL,
  `delete_type` varchar(50) DEFAULT NULL,
  `delete_title` varchar(50) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_delete
-- ----------------------------
INSERT INTO `wgi_delete` VALUES ('7', '24', 'DigitPrice', null, null, null, null, '2017-09-04 11:31:03');
INSERT INTO `wgi_delete` VALUES ('8', '23', 'DigitPrice', null, null, null, null, '2017-09-04 14:14:29');
INSERT INTO `wgi_delete` VALUES ('9', '22', 'DigitPrice', null, null, null, null, '2017-09-04 14:14:31');
INSERT INTO `wgi_delete` VALUES ('10', '21', 'DigitPrice', null, null, null, null, '2017-09-04 14:14:33');
INSERT INTO `wgi_delete` VALUES ('11', '20', 'DigitPrice', null, null, null, null, '2017-09-04 14:14:35');
INSERT INTO `wgi_delete` VALUES ('12', '19', 'DigitPrice', null, null, null, null, '2017-09-04 14:14:36');
INSERT INTO `wgi_delete` VALUES ('13', '18', 'DigitPrice', null, null, null, null, '2017-09-04 14:14:38');
INSERT INTO `wgi_delete` VALUES ('14', '104', 'Member', null, null, '会员', 'tang001', '2017-09-04 14:47:08');
INSERT INTO `wgi_delete` VALUES ('15', '35', 'DigitPrice', null, null, null, null, '2017-09-15 00:06:58');

-- ----------------------------
-- Table structure for wgi_digit_price
-- ----------------------------
DROP TABLE IF EXISTS `wgi_digit_price`;
CREATE TABLE `wgi_digit_price` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` decimal(10,2) DEFAULT '0.00',
  `date` date DEFAULT NULL,
  `number` float DEFAULT '0',
  `addtime` datetime DEFAULT NULL,
  `status` int(1) DEFAULT '0',
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_digit_price
-- ----------------------------
INSERT INTO `wgi_digit_price` VALUES ('35', '2.00', '2017-09-04', '0', '2017-09-04 16:17:33', '1', '1');
INSERT INTO `wgi_digit_price` VALUES ('36', '2.06', '2017-09-05', '0', '2017-09-04 16:31:33', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('37', '2.12', '2017-09-06', '0', '2017-09-04 16:54:33', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('38', '2.30', '2017-09-07', '0', '2017-09-04 16:07:34', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('39', '3.12', '2017-09-08', '0', '2017-09-04 16:01:41', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('40', '3.20', '2017-09-09', '0', '2017-09-04 16:32:41', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('41', '3.50', '2017-09-10', '0', '2017-09-04 16:00:43', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('42', '3.55', '2017-09-11', '0', '2017-09-04 16:12:43', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('43', '4.00', '2017-09-12', '0', '2017-09-04 16:12:44', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('44', '2.00', '2017-09-13', '0', '2017-09-12 02:04:08', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('45', '2.06', '2017-09-14', '0', '2017-09-12 02:34:08', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('46', '2.16', '2017-09-15', '0', '2017-09-12 02:58:08', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('47', '2.26', '2017-09-16', '0', '2017-09-12 02:12:09', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('48', '2.36', '2017-09-17', '0', '2017-09-12 02:32:09', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('49', '2.46', '2017-09-18', '0', '2017-09-12 02:46:09', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('50', '2.56', '2017-09-19', '0', '2017-09-12 02:02:10', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('51', '2.66', '2017-09-20', '0', '2017-09-12 02:13:10', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('52', '2.76', '2017-09-21', '0', '2017-09-12 02:01:11', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('53', '2.86', '2017-09-22', '0', '2017-09-12 02:11:11', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('54', '2.96', '2017-09-23', '0', '2017-09-12 02:36:11', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('55', '3.16', '2017-09-24', '0', '2017-09-12 02:55:11', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('56', '3.26', '2017-09-25', '0', '2017-09-12 02:07:12', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('57', '3.36', '2017-09-26', '0', '2017-09-12 02:21:12', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('58', '3.46', '2017-09-27', '0', '2017-09-12 02:35:12', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('59', '3.56', '2017-09-28', '0', '2017-09-12 02:47:12', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('60', '3.66', '2017-09-29', '0', '2017-09-12 02:01:13', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('61', '3.76', '2017-09-30', '0', '2017-09-12 02:24:13', '1', '0');
INSERT INTO `wgi_digit_price` VALUES ('62', '3.86', '2017-10-01', '0', '2017-09-12 02:34:13', '1', '0');

-- ----------------------------
-- Table structure for wgi_feedback_type
-- ----------------------------
DROP TABLE IF EXISTS `wgi_feedback_type`;
CREATE TABLE `wgi_feedback_type` (
  `id` smallint(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `problem_name` varchar(50) DEFAULT NULL COMMENT '问题名称',
  `en_problem_name` varchar(50) DEFAULT NULL COMMENT '问题名称英文',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_feedback_type
-- ----------------------------
INSERT INTO `wgi_feedback_type` VALUES ('1', '账号冻结', 'Bloqueo de cuenta');
INSERT INTO `wgi_feedback_type` VALUES ('2', '投诉他人违规', 'Denunciar la ilegalidad de otras personas');
INSERT INTO `wgi_feedback_type` VALUES ('3', '提现订单不匹配', 'El pedido para la extracción de dinero no es empar');
INSERT INTO `wgi_feedback_type` VALUES ('4', '买方拒绝付款', 'El comprador rechaza pagar');
INSERT INTO `wgi_feedback_type` VALUES ('5', '卖方不确认收款', 'El vendedor no confirma el recibo de pago');
INSERT INTO `wgi_feedback_type` VALUES ('6', '买方收款信息有误', 'Error con información de cobro del comprador');
INSERT INTO `wgi_feedback_type` VALUES ('7', '收不到短信', 'No puede recibir el mensaje');
INSERT INTO `wgi_feedback_type` VALUES ('8', '奖金计算错误', 'Error con la calculación de premio');
INSERT INTO `wgi_feedback_type` VALUES ('9', '更改个人信息', 'Modificación de información personal');
INSERT INTO `wgi_feedback_type` VALUES ('10', '其他问题', 'Otros problemas');

-- ----------------------------
-- Table structure for wgi_information
-- ----------------------------
DROP TABLE IF EXISTS `wgi_information`;
CREATE TABLE `wgi_information` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `member_id` int(11) unsigned DEFAULT NULL COMMENT '会员ID',
  `member_username` varchar(50) DEFAULT NULL COMMENT '会员账号',
  `member_telephone` varchar(50) DEFAULT NULL COMMENT '会员手机号码',
  `type` smallint(6) DEFAULT NULL COMMENT '类型',
  `picture` varchar(50) DEFAULT NULL COMMENT '图片',
  `content` text COMMENT '内容',
  `remark` text COMMENT '回复',
  `addtime` datetime DEFAULT NULL COMMENT '留言时间',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态（0-未处理，1-处理中，2-处理完成）',
  `delete` tinyint(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  `replaytime` datetime DEFAULT NULL COMMENT '回复时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_information
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_member
-- ----------------------------
DROP TABLE IF EXISTS `wgi_member`;
CREATE TABLE `wgi_member` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `p_id` int(11) unsigned DEFAULT '0' COMMENT '节点领导人ID',
  `p_username` varchar(50) DEFAULT NULL COMMENT '节点领导人账号',
  `username` varchar(50) DEFAULT NULL COMMENT '会员账号',
  `userpass` char(32) DEFAULT NULL COMMENT '登陆密码',
  `paypass` char(32) DEFAULT NULL COMMENT '支付密码',
  `dgcpass` char(32) DEFAULT NULL COMMENT '二级密码',
  `package_type` tinyint(1) DEFAULT '0' COMMENT '会员星级',
  `member_type` tinyint(1) DEFAULT '0' COMMENT '会员类型（0-A类用户，1-B类用户）',
  `price_level` int(11) DEFAULT NULL,
  `surname` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL COMMENT '会员姓名',
  `china_card` varchar(50) DEFAULT NULL COMMENT '身份证号码',
  `extend_china_card` varchar(50) DEFAULT NULL COMMENT '其他证件号码',
  `country` varchar(50) DEFAULT NULL COMMENT '所在国家',
  `telephone` varchar(50) DEFAULT NULL COMMENT '手机号码',
  `weixin` varchar(50) DEFAULT NULL COMMENT '微信号',
  `zhifubao` varchar(50) DEFAULT NULL COMMENT '支付宝号',
  `bank` varchar(255) DEFAULT NULL COMMENT '开户银行',
  `bank_account` varchar(255) DEFAULT NULL COMMENT '银行卡号',
  `bank_account_name` varchar(255) DEFAULT NULL COMMENT '银行卡户名',
  `email` varchar(255) DEFAULT NULL COMMENT '邮箱地址',
  `area` varchar(255) DEFAULT NULL COMMENT '所在地区',
  `address` varchar(255) DEFAULT NULL COMMENT '联系地址',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `credit` tinyint(1) DEFAULT '5' COMMENT '信用分数',
  `passport` varchar(255) DEFAULT NULL,
  `sex` tinyint(1) DEFAULT '0' COMMENT '性别（0-男，1-女）',
  `picture` varchar(255) DEFAULT NULL COMMENT '头像',
  `pay_picture` varchar(255) DEFAULT NULL COMMENT '支付凭证图片',
  `remark` text COMMENT '备注说明',
  `bitcoin` varchar(50) DEFAULT NULL COMMENT '虚拟货币地址',
  `paypal` varchar(50) DEFAULT NULL COMMENT 'paypal账号',
  `bwstate` tinyint(1) DEFAULT '0' COMMENT 'B钱包开通状态 （0-关闭，1-开通）',
  `r_id` int(11) DEFAULT '0' COMMENT '直推会员ID',
  `r_username` varchar(50) DEFAULT NULL COMMENT '直推会员账号',
  `t_id` int(11) DEFAULT '0' COMMENT '顶级会员ID',
  `t_username` varchar(50) DEFAULT '' COMMENT '顶级会员账号',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态（0-冻结，1-未冻结）',
  `status_login` tinyint(1) DEFAULT '0',
  `position` tinyint(1) DEFAULT '0' COMMENT '所在区（0-左区，1-右区）',
  `adddate` date DEFAULT NULL COMMENT '添加日期',
  `addtime` datetime DEFAULT NULL COMMENT '添加时间',
  `delete` tinyint(1) unsigned DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  `p_str` text COMMENT '所有上级ID',
  `topclass` int(10) DEFAULT '1' COMMENT '所在层级',
  `is_out` int(1) DEFAULT '0' COMMENT '出局状态0-未出局1-已出局',
  `out_time` datetime DEFAULT NULL COMMENT '出局时间',
  `split_num` int(2) DEFAULT '0' COMMENT '经历的拆分次数',
  `is_boom` int(1) DEFAULT '0' COMMENT '0-未爆仓 1-爆仓',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8 COMMENT='会员';

-- ----------------------------
-- Records of wgi_member
-- ----------------------------
INSERT INTO `wgi_member` VALUES ('1', '0', null, 'wgi001', 'e2419af0f7c3d3a358b3a694b8e90e7a', '123456', '', '1', '0', null, null, '张学友', '430422199801010808', '430422199801081818', '', '13925126516', '1234567', '12345678', '中国银行', '123456789', '张学友', '455204062@qq.com', '', '', null, '5', null, '1', '', null, '', '', '', '1', '0', null, '0', '', '1', '1', '0', '2017-08-31', '2017-08-31 00:05:35', '0', null, '0', '0', '2017-08-31 11:01:17', '4', '0');
INSERT INTO `wgi_member` VALUES ('123', '0', null, 'tang001', 'b70a08d1e6cf8a371a9bf04faff7fd76', '111111', null, '2', '0', null, null, '', '', '', '', '18373954288', '', '', '', '', '', '', '', '', null, '5', null, '1', '', null, '', '', '', '0', '0', null, '0', '', '1', '1', '0', '2017-09-15', '2017-09-15 00:10:13', '0', null, '1', '0', null, '0', '0');
INSERT INTO `wgi_member` VALUES ('124', '123', 'tang001', 'tang002', '63c4f5e50ff21aa6513e7802a9c96654', '18773583400', null, '2', '0', null, null, null, null, null, null, '18773583400', null, null, null, null, null, null, null, null, null, '5', null, '0', null, null, null, null, null, '0', '123', 'tang001', '0', '', '1', '1', '0', '2017-09-05', '2017-09-05 14:27:04', '0', ',123,', '2', '0', '2017-09-05 14:27:04', '0', '0');
INSERT INTO `wgi_member` VALUES ('125', '0', null, 'jjj001', '9a2c357fa490f4b3610a4c53233b13c7', '111111', null, '0', '1', null, null, '', '', '', '', '18773583400', '', '', '', '', '', '', '', '', null, '5', null, '1', '', null, '', '', '', '1', '0', null, '0', '', '1', '1', '0', '2017-09-05', '2017-09-05 14:45:33', '0', null, '1', '0', null, '0', '0');
INSERT INTO `wgi_member` VALUES ('126', '0', null, 'tang888', '3edfa22a64c543bb394c0e4cc5b7aa92', '', null, '1', '0', null, null, '', '', '', '', '18373965244', '', '', '', '', '', '', '', '', null, '5', null, '1', '', null, '', '', '', '0', '0', null, '0', '', '1', '1', '0', '2017-09-05', '2017-09-05 14:17:55', '0', null, '1', '0', null, '0', '0');
INSERT INTO `wgi_member` VALUES ('127', '123', 'tang001', 'tang003', '8fe971da6bc0698a84dd0dfa4dddee93', '18373954299', null, '1', '0', null, null, null, null, null, null, '18373954299', null, null, null, null, null, null, null, null, null, '5', null, '0', null, null, null, null, null, '0', '123', 'tang001', '0', '', '1', '1', '1', '2017-09-05', '2017-09-05 15:12:28', '0', ',123,', '2', '0', '2017-09-05 15:12:28', '0', '0');
INSERT INTO `wgi_member` VALUES ('128', '124', 'tang002', 'tang004', 'd7e80e6ae94cccaa74c967a954929538', '18373954277', null, '1', '0', null, null, null, null, null, null, '18373954277', null, null, null, null, null, null, null, null, null, '5', null, '0', null, null, null, null, null, '0', '123', 'tang001', '0', '', '1', '1', '0', '2017-09-05', '2017-09-05 15:15:34', '0', ',123,124,', '3', '0', '2017-09-05 15:15:34', '0', '0');
INSERT INTO `wgi_member` VALUES ('129', '124', 'tang002', 'tang005', 'f311687ecb489e7a81ddda17eef9adbd', '18373954210', null, '1', '0', null, null, null, null, null, null, '18373954210', null, null, null, null, null, null, null, null, null, '5', null, '0', null, null, null, null, null, '0', '124', 'tang002', '0', '', '1', '1', '1', '2017-09-05', '2017-09-05 15:23:23', '0', ',123,124,', '3', '0', '2017-09-05 15:23:23', '0', '0');
INSERT INTO `wgi_member` VALUES ('130', '128', 'tang004', 'juanjuan', 'c121688cb353e682272839c9813231fa', '18673112520', null, '1', '0', null, null, null, null, null, null, '18673112520', '12312', '1341', '湖南', '779898', '黄娟', null, null, null, null, '5', null, '0', null, null, null, '123i-90-09-09', null, '0', '123', 'tang001', '0', '', '1', '1', '0', '2017-09-05', '2017-09-05 15:29:59', '0', ',123,124,128,', '4', '0', '2017-09-05 15:29:59', '0', '0');
INSERT INTO `wgi_member` VALUES ('131', '127', 'tang003', 'tang006', '4cd36885f1de98de04bb05c324962fc2', '18373954100', null, '1', '0', null, null, null, null, null, null, '18373954100', null, null, null, null, null, null, null, null, null, '5', null, '0', null, null, null, null, null, '0', '123', 'tang001', '0', '', '1', '1', '0', '2017-09-05', '2017-09-05 15:35:46', '0', ',123,127,', '3', '0', '2017-09-05 15:35:46', '0', '0');
INSERT INTO `wgi_member` VALUES ('132', '131', 'tang006', 'tang007', '387896b81e2b68f1632018ab1126a595', '18373954110', null, '3', '0', null, null, null, null, null, null, '18373954110', null, null, null, null, null, null, null, null, null, '5', null, '0', null, null, null, null, null, '0', '123', 'tang001', '0', '', '1', '1', '0', '2017-09-05', '2017-09-05 15:52:28', '0', ',123,127,131,', '4', '0', '2017-09-05 15:52:28', '0', '0');

-- ----------------------------
-- Table structure for wgi_member_level_log
-- ----------------------------
DROP TABLE IF EXISTS `wgi_member_level_log`;
CREATE TABLE `wgi_member_level_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) DEFAULT NULL COMMENT '单号编码',
  `member_id` int(11) DEFAULT NULL COMMENT '会员ID',
  `member_username` varchar(50) DEFAULT NULL COMMENT '会员账号名称',
  `old_level` varchar(50) DEFAULT NULL COMMENT '升级前星级',
  `en_old_level` varchar(50) DEFAULT NULL COMMENT '升级前星级英文',
  `new_level` varchar(50) DEFAULT NULL COMMENT '升级后星级',
  `en_new_level` varchar(50) DEFAULT NULL COMMENT '升级后星级英文',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '补单金额',
  `addtime` datetime DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_member_level_log
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_member_login_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_member_login_info`;
CREATE TABLE `wgi_member_login_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `member_id` int(11) unsigned DEFAULT NULL COMMENT '会员ID',
  `member_username` varchar(50) DEFAULT NULL COMMENT '会员账号',
  `login_ip` varchar(50) DEFAULT NULL COMMENT '登陆IP',
  `login_time` datetime DEFAULT NULL COMMENT '登陆时间',
  `delete` tinyint(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=213 DEFAULT CHARSET=utf8 COMMENT='会员登陆记录';

-- ----------------------------
-- Records of wgi_member_login_info
-- ----------------------------
INSERT INTO `wgi_member_login_info` VALUES ('206', '123', null, '113.246.105.69', '2017-09-05 14:15:26', '0');
INSERT INTO `wgi_member_login_info` VALUES ('207', '125', null, '113.246.105.69', '2017-09-05 14:34:02', '0');
INSERT INTO `wgi_member_login_info` VALUES ('208', '126', null, '113.246.105.69', '2017-09-05 14:55:37', '0');
INSERT INTO `wgi_member_login_info` VALUES ('209', '123', null, '113.246.105.69', '2017-09-05 14:59:50', '0');
INSERT INTO `wgi_member_login_info` VALUES ('210', '123', null, '113.246.105.69', '2017-09-05 15:18:27', '0');
INSERT INTO `wgi_member_login_info` VALUES ('211', '124', null, '113.246.105.69', '2017-09-05 15:20:33', '0');
INSERT INTO `wgi_member_login_info` VALUES ('212', '130', null, '106.17.191.63', '2017-09-05 15:34:54', '0');

-- ----------------------------
-- Table structure for wgi_member_share_count
-- ----------------------------
DROP TABLE IF EXISTS `wgi_member_share_count`;
CREATE TABLE `wgi_member_share_count` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户股份池',
  `member_id` int(11) DEFAULT NULL COMMENT '用户id',
  `type` int(1) DEFAULT '0' COMMENT '0-转入1-卖出',
  `title` varchar(255) DEFAULT NULL,
  `title_en` varchar(255) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL COMMENT '变更数量',
  `new_shares` int(11) DEFAULT '0' COMMENT '用户股份池剩余股份',
  `old_shares` int(11) DEFAULT '0' COMMENT '变更之前数量',
  `delete` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_member_share_count
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_memberinfo
-- ----------------------------
DROP TABLE IF EXISTS `wgi_memberinfo`;
CREATE TABLE `wgi_memberinfo` (
  `id` int(11) unsigned NOT NULL COMMENT '会员ID',
  `username` varchar(50) DEFAULT '' COMMENT '会员账号',
  `cashb` decimal(18,2) DEFAULT '0.00' COMMENT '现金币',
  `regb` decimal(18,2) DEFAULT '0.00' COMMENT '注册币',
  `jfb` decimal(18,2) DEFAULT '0.00' COMMENT '积分',
  `bwallet` decimal(18,2) DEFAULT '0.00' COMMENT 'B钱包',
  `gfnum` int(11) DEFAULT '0' COMMENT '股份总数',
  `summoney_total` decimal(18,2) DEFAULT '0.00' COMMENT '投资总金额',
  `touchmoney` decimal(18,2) DEFAULT '0.00' COMMENT '已对碰金额',
  `summoney_l` decimal(18,2) DEFAULT '0.00' COMMENT '左区团队投资金额',
  `summoney_r` decimal(18,2) DEFAULT '0.00' COMMENT '右区团队投资金额',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_memberinfo
-- ----------------------------
INSERT INTO `wgi_memberinfo` VALUES ('1', 'wgi001', '0.00', '10000.00', '0.00', '0.00', '0', '0.00', '0.00', '0.00', '0.00');
INSERT INTO `wgi_memberinfo` VALUES ('123', 'tang001', '1000012.48', '988228.12', '0.00', '0.00', '100', '0.00', '800.00', '0.00', '300.00');
INSERT INTO `wgi_memberinfo` VALUES ('124', 'tang002', '9.20', '9502.30', '0.00', '0.00', '0', '100.00', '100.00', '100.00', '0.00');
INSERT INTO `wgi_memberinfo` VALUES ('125', 'jjj001', '0.00', '0.00', '0.00', '100000.00', '0', '0.00', '0.00', '0.00', '0.00');
INSERT INTO `wgi_memberinfo` VALUES ('126', 'tang888', '0.00', '0.00', '0.00', '0.00', '0', '0.00', '0.00', '0.00', '0.00');
INSERT INTO `wgi_memberinfo` VALUES ('127', 'tang003', '4.40', '1.10', '0.00', '0.00', '0', '100.00', '0.00', '1100.00', '0.00');
INSERT INTO `wgi_memberinfo` VALUES ('128', 'tang004', '0.40', '0.10', '0.00', '0.00', '0', '100.00', '0.00', '100.00', '0.00');
INSERT INTO `wgi_memberinfo` VALUES ('129', 'tang005', '0.00', '0.00', '0.00', '0.00', '0', '100.00', '0.00', '0.00', '0.00');
INSERT INTO `wgi_memberinfo` VALUES ('130', 'juanjuan', '0.00', '0.00', '0.00', '0.00', '0', '100.00', '0.00', '0.00', '0.00');
INSERT INTO `wgi_memberinfo` VALUES ('131', 'tang006', '4.00', '1.00', '0.00', '0.00', '0', '100.00', '0.00', '1000.00', '0.00');
INSERT INTO `wgi_memberinfo` VALUES ('132', 'tang007', '0.00', '0.00', '0.00', '0.00', '0', '1000.00', '0.00', '0.00', '0.00');

-- ----------------------------
-- Table structure for wgi_message
-- ----------------------------
DROP TABLE IF EXISTS `wgi_message`;
CREATE TABLE `wgi_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `message` text,
  `emailAddress` varchar(50) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `delete` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_message
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_news
-- ----------------------------
DROP TABLE IF EXISTS `wgi_news`;
CREATE TABLE `wgi_news` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `title` varchar(255) DEFAULT NULL COMMENT '中文标题',
  `title_en` varchar(255) DEFAULT NULL COMMENT '英文标题',
  `content` text COMMENT '中文内容',
  `content_en` text COMMENT '英文内容',
  `addtime` datetime DEFAULT NULL COMMENT '添加时间',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态（0-隐藏，1-显示）',
  `delete` tinyint(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8 COMMENT='新闻';

-- ----------------------------
-- Records of wgi_news
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_node
-- ----------------------------
DROP TABLE IF EXISTS `wgi_node`;
CREATE TABLE `wgi_node` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `name` varchar(20) NOT NULL COMMENT '节点名',
  `title` varchar(50) DEFAULT NULL COMMENT '节点说明',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态（0-关闭，1-开启）',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `sort` smallint(6) unsigned DEFAULT NULL COMMENT '排序',
  `pid` smallint(6) unsigned NOT NULL COMMENT '父节点ID',
  `level` tinyint(1) unsigned NOT NULL COMMENT '层级(1-模块，2-控制器，3-方法）',
  PRIMARY KEY (`id`),
  KEY `level` (`level`),
  KEY `pid` (`pid`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_node
-- ----------------------------
INSERT INTO `wgi_node` VALUES ('1', 'Home', '系统管理', '1', null, '1', '0', '1');
INSERT INTO `wgi_node` VALUES ('39', 'Config', '系统管理', '1', null, '11', '1', '2');
INSERT INTO `wgi_node` VALUES ('46', 'Rbac', '权限管理', '1', null, '81', '1', '2');
INSERT INTO `wgi_node` VALUES ('45', 'Trade', '交易管理', '1', null, '71', '1', '2');
INSERT INTO `wgi_node` VALUES ('40', 'Member', '会员管理', '1', null, '21', '1', '2');
INSERT INTO `wgi_node` VALUES ('41', 'Stock', '股份管理', '1', null, '31', '1', '2');
INSERT INTO `wgi_node` VALUES ('42', 'News', '新闻管理', '1', null, '41', '1', '2');
INSERT INTO `wgi_node` VALUES ('43', 'Information', '留言管理', '1', null, '51', '1', '2');
INSERT INTO `wgi_node` VALUES ('44', 'Wallet', '钱包管理', '1', null, '61', '1', '2');
INSERT INTO `wgi_node` VALUES ('47', 'system', '系统公共设置', '1', null, '1', '39', '3');

-- ----------------------------
-- Table structure for wgi_order_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_order_info`;
CREATE TABLE `wgi_order_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) DEFAULT NULL COMMENT '订单编号',
  `type` int(1) DEFAULT NULL COMMENT '充值类型（0-注册币，1-现金币）',
  `price_info_id` int(11) DEFAULT NULL COMMENT '对应钱包记录ID',
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `title_en` varchar(255) DEFAULT NULL,
  `title_sp` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `out_price` decimal(10,2) DEFAULT '0.00',
  `in_price` decimal(10,2) DEFAULT '0.00',
  `price` decimal(10,2) DEFAULT '0.00',
  `package_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT '0',
  `addtime` datetime DEFAULT '0000-00-00 00:00:00',
  `adddate` date DEFAULT NULL,
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8 COMMENT='后台充值记录';

-- ----------------------------
-- Records of wgi_order_info
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_price_b
-- ----------------------------
DROP TABLE IF EXISTS `wgi_price_b`;
CREATE TABLE `wgi_price_b` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `member_id` int(11) DEFAULT NULL COMMENT '会员ID',
  `member_username` varchar(50) DEFAULT NULL COMMENT '会员账号',
  `title` varchar(255) DEFAULT NULL COMMENT '交易标题-中文',
  `title_en` varchar(255) DEFAULT NULL COMMENT '交易标题-英文',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注说明',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '交易金额数量',
  `admin_id` int(11) DEFAULT NULL COMMENT '管理员ID',
  `adddate` date DEFAULT NULL COMMENT '交易日期',
  `addtime` datetime DEFAULT NULL COMMENT '交易时间',
  `delete` tinyint(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='B钱包解冻记录';

-- ----------------------------
-- Records of wgi_price_b
-- ----------------------------
INSERT INTO `wgi_price_b` VALUES ('17', '1', 'jjj001', '后台充值', 'Background recharge', '后台新增会员添加B钱包', '100000.00', '1', '2017-09-05', '2017-09-05 14:33:45', '0');

-- ----------------------------
-- Table structure for wgi_price_dz
-- ----------------------------
DROP TABLE IF EXISTS `wgi_price_dz`;
CREATE TABLE `wgi_price_dz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT '0' COMMENT '1-配股2-复投3-回购4-注册',
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `order_id` varchar(100) DEFAULT NULL COMMENT '订单ID',
  `title` varchar(255) DEFAULT NULL,
  `title_en` varchar(255) DEFAULT NULL,
  `share_price` decimal(10,2) DEFAULT NULL COMMENT '股价',
  `share_num` int(11) DEFAULT NULL COMMENT '配股数量',
  `remark` varchar(255) DEFAULT NULL,
  `new_price` decimal(10,2) DEFAULT '0.00',
  `old_price` decimal(10,2) DEFAULT '0.00',
  `price` decimal(10,2) DEFAULT '0.00',
  `addtime` datetime DEFAULT NULL,
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_price_dz
-- ----------------------------
INSERT INTO `wgi_price_dz` VALUES ('157', '4', '123', 'tang001', null, '新用户金额转化为电子币', 'The amount of new users is converted into electronic currency', null, null, null, '50.00', '0.00', '50.00', '2017-09-15 00:13:10', '0');
INSERT INTO `wgi_price_dz` VALUES ('158', '4', '124', 'tang002', null, '新用户金额转化为电子币', 'The amount of new users is converted into electronic currency', null, null, null, '50.00', '0.00', '50.00', '2017-09-05 14:27:04', '0');
INSERT INTO `wgi_price_dz` VALUES ('159', '4', '126', 'tang888', null, '新用户金额转化为电子币', 'The amount of new users is converted into electronic currency', null, null, null, '50.00', '0.00', '50.00', '2017-09-05 14:55:17', '0');
INSERT INTO `wgi_price_dz` VALUES ('160', '4', '127', 'tang003', null, '新用户金额转化为电子币', 'The amount of new users is converted into electronic currency', null, null, null, '50.00', '0.00', '50.00', '2017-09-05 15:12:28', '0');
INSERT INTO `wgi_price_dz` VALUES ('161', '4', '128', 'tang004', null, '新用户金额转化为电子币', 'The amount of new users is converted into electronic currency', null, null, null, '50.00', '0.00', '50.00', '2017-09-05 15:15:34', '0');
INSERT INTO `wgi_price_dz` VALUES ('162', '4', '129', 'tang005', null, '新用户金额转化为电子币', 'The amount of new users is converted into electronic currency', null, null, null, '50.00', '0.00', '50.00', '2017-09-05 15:23:23', '0');
INSERT INTO `wgi_price_dz` VALUES ('163', '4', '130', 'juanjuan', null, '新用户金额转化为电子币', 'The amount of new users is converted into electronic currency', null, null, null, '50.00', '0.00', '50.00', '2017-09-05 15:29:59', '0');
INSERT INTO `wgi_price_dz` VALUES ('164', '4', '123', 'tang001', null, '原点升级金额转化为电子币', 'The origin upgrade amount is converted into electronic currency', null, null, null, '208.00', '0.00', '208.00', '2017-09-05 15:30:23', '0');
INSERT INTO `wgi_price_dz` VALUES ('165', '4', '131', 'tang006', null, '新用户金额转化为电子币', 'The amount of new users is converted into electronic currency', null, null, null, '50.00', '0.00', '50.00', '2017-09-05 15:35:46', '0');
INSERT INTO `wgi_price_dz` VALUES ('166', '4', '124', 'tang002', null, '原点升级金额转化为电子币', 'The origin upgrade amount is converted into electronic currency', null, null, null, '208.00', '0.00', '208.00', '2017-09-05 15:47:46', '0');
INSERT INTO `wgi_price_dz` VALUES ('167', '4', '132', 'tang007', null, '新用户金额转化为电子币', 'The amount of new users is converted into electronic currency', null, null, null, '540.00', '0.00', '540.00', '2017-09-05 15:52:28', '0');

-- ----------------------------
-- Table structure for wgi_price_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_price_info`;
CREATE TABLE `wgi_price_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `type` tinyint(1) DEFAULT '0' COMMENT '交易类型（1-充值，2-消费，3-升级，4-转出，5-转入）',
  `member_id` int(11) DEFAULT NULL COMMENT '会员ID',
  `member_username` varchar(50) DEFAULT NULL COMMENT '会员账号',
  `order_id` varchar(50) DEFAULT NULL COMMENT '订单编号',
  `title` varchar(255) DEFAULT NULL COMMENT '交易标题-中文',
  `title_en` varchar(255) DEFAULT NULL COMMENT '交易标题-英文',
  `title_sp` varchar(255) DEFAULT NULL COMMENT '交易标题-西班牙文',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注说明',
  `new_price` decimal(10,2) DEFAULT '0.00' COMMENT '注册币钱包交易后的金额数量',
  `old_price` decimal(10,2) DEFAULT '0.00' COMMENT '注册币钱包交易前的金额数量',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '交易金额数量',
  `admin_id` int(11) DEFAULT NULL COMMENT '管理员ID',
  `adddate` date DEFAULT NULL COMMENT '交易日期',
  `addtime` datetime DEFAULT NULL COMMENT '交易时间',
  `delete` tinyint(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=461 DEFAULT CHARSET=utf8 COMMENT='注册币交易记录';

-- ----------------------------
-- Records of wgi_price_info
-- ----------------------------
INSERT INTO `wgi_price_info` VALUES ('426', '1', '123', 'tang001', 'RC4654329', '注册币充值', 'Registered currency recharge', null, null, '1000000.00', '0.00', '1000000.00', '1', '2017-09-05', '2017-09-05 14:19:21', '0');
INSERT INTO `wgi_price_info` VALUES ('427', '5', '123', 'tang001', null, '现金币转注册币', 'CC Transfers RC', 'CC Transfers RC', null, '1000100.00', '1000000.00', '100.00', null, null, '2017-09-05 14:25:16', '0');
INSERT INTO `wgi_price_info` VALUES ('428', '2', '123', 'tang001', null, 'tang002 注册账号支出', 'tang002 Register', null, null, '1000000.00', '1000100.00', '100.00', null, '2017-09-05', '2017-09-05 14:27:04', '0');
INSERT INTO `wgi_price_info` VALUES ('429', '5', '123', 'tang001', null, 'tang002 注册,推荐奖的20%转为注册币', 'tang002 registered, Referral Bonus20.%transfered into Register Coin', null, null, '1000001.00', '1000000.00', '1.00', null, '2017-09-05', '2017-09-05 14:27:04', '0');
INSERT INTO `wgi_price_info` VALUES ('430', '5', '123', 'tang001', null, 'tang002 注册,见点奖的20%转为注册币', 'tang002 registered, Referral Bonus20.%transfered into Register Coin', null, null, '1000001.10', '1000001.00', '0.10', null, '2017-09-05', '2017-09-05 14:27:04', '0');
INSERT INTO `wgi_price_info` VALUES ('431', '2', '123', 'tang001', null, 'tang003 注册账号支出', 'tang003 Register', null, null, '999901.10', '1000001.10', '100.00', null, '2017-09-05', '2017-09-05 15:12:28', '0');
INSERT INTO `wgi_price_info` VALUES ('432', '5', '123', 'tang001', null, 'tang003 注册,推荐奖的20%转为注册币', 'tang003 registered, Referral Bonus20.%transfered into Register Coin', null, null, '999902.10', '999901.10', '1.00', null, '2017-09-05', '2017-09-05 15:12:28', '0');
INSERT INTO `wgi_price_info` VALUES ('433', '5', '123', 'tang001', null, 'tang003 注册,见点奖的20%转为注册币', 'tang003 registered, Referral Bonus20.%transfered into Register Coin', null, null, '999902.20', '999902.10', '0.10', null, '2017-09-05', '2017-09-05 15:12:28', '0');
INSERT INTO `wgi_price_info` VALUES ('434', '5', '123', 'tang001', null, 'tang003 注册,对碰奖的20%转为注册币', 'tang003 registered, Referral Bonus20.%transfered into Register Coin', null, null, '999903.20', '999902.20', '1.00', null, '2017-09-05', '2017-09-05 15:12:28', '0');
INSERT INTO `wgi_price_info` VALUES ('435', '2', '123', 'tang001', null, 'tang004 注册账号支出', 'tang004 Register', null, null, '999803.20', '999903.20', '100.00', null, '2017-09-05', '2017-09-05 15:15:34', '0');
INSERT INTO `wgi_price_info` VALUES ('436', '5', '123', 'tang001', null, 'tang004 注册,推荐奖的20%转为注册币', 'tang004 registered, Referral Bonus20.%transfered into Register Coin', null, null, '999804.20', '999803.20', '1.00', null, '2017-09-05', '2017-09-05 15:15:34', '0');
INSERT INTO `wgi_price_info` VALUES ('437', '5', '124', 'tang002', null, 'tang004 注册,见点奖的20%转为注册币', 'tang004 registered, Referral Bonus20.%transfered into Register Coin', null, null, '0.10', '0.00', '0.10', null, '2017-09-05', '2017-09-05 15:15:34', '0');
INSERT INTO `wgi_price_info` VALUES ('438', '5', '123', 'tang001', null, 'tang004 注册,见点奖的20%转为注册币', 'tang004 registered, Referral Bonus20.%transfered into Register Coin', null, null, '999804.30', '999804.20', '0.10', null, '2017-09-05', '2017-09-05 15:15:34', '0');
INSERT INTO `wgi_price_info` VALUES ('439', '4', '123', 'tang001', 'WGIT7338472', '转出到 tang002', 'Roll out to tang002', 'Roll out to tang002', null, '989804.30', '999804.30', '10000.00', null, null, '2017-09-05 15:22:36', '0');
INSERT INTO `wgi_price_info` VALUES ('440', '5', '124', 'tang002', 'WGIT7338472', '从 tang001 转入', 'from tang001 To change into', 'from tang001 To change into', null, '10000.10', '0.10', '10000.00', null, null, '2017-09-05 15:22:36', '0');
INSERT INTO `wgi_price_info` VALUES ('441', '2', '124', 'tang002', null, 'tang005 注册账号支出', 'tang005 Register', null, null, '9900.10', '10000.10', '100.00', null, '2017-09-05', '2017-09-05 15:23:23', '0');
INSERT INTO `wgi_price_info` VALUES ('442', '5', '124', 'tang002', null, 'tang005 注册,推荐奖的20%转为注册币', 'tang005 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9901.10', '9900.10', '1.00', null, '2017-09-05', '2017-09-05 15:23:23', '0');
INSERT INTO `wgi_price_info` VALUES ('443', '5', '124', 'tang002', null, 'tang005 注册,见点奖的20%转为注册币', 'tang005 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9901.20', '9901.10', '0.10', null, '2017-09-05', '2017-09-05 15:23:23', '0');
INSERT INTO `wgi_price_info` VALUES ('444', '5', '123', 'tang001', null, 'tang005 注册,见点奖的20%转为注册币', 'tang005 registered, Referral Bonus20.%transfered into Register Coin', null, null, '989804.40', '989804.30', '0.10', null, '2017-09-05', '2017-09-05 15:23:23', '0');
INSERT INTO `wgi_price_info` VALUES ('445', '5', '124', 'tang002', null, 'tang005 注册,对碰奖的20%转为注册币', 'tang005 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9902.20', '9901.20', '1.00', null, '2017-09-05', '2017-09-05 15:23:23', '0');
INSERT INTO `wgi_price_info` VALUES ('446', '5', '123', 'tang001', null, 'tang005 注册,领导奖的20%转为注册币', 'tang005 registered, Referral Bonus20.%transfered into Register Coin', null, null, '989804.42', '989804.40', '0.02', null, '2017-09-05', '2017-09-05 15:23:23', '0');
INSERT INTO `wgi_price_info` VALUES ('447', '2', '123', 'tang001', null, 'juanjuan 注册账号支出', 'juanjuan Register', null, null, '989704.42', '989804.42', '100.00', null, '2017-09-05', '2017-09-05 15:29:59', '0');
INSERT INTO `wgi_price_info` VALUES ('448', '5', '123', 'tang001', null, 'juanjuan 注册,推荐奖的20%转为注册币', 'juanjuan registered, Referral Bonus20.%transfered into Register Coin', null, null, '989705.42', '989704.42', '1.00', null, '2017-09-05', '2017-09-05 15:29:59', '0');
INSERT INTO `wgi_price_info` VALUES ('449', '5', '128', 'tang004', null, 'juanjuan 注册,见点奖的20%转为注册币', 'juanjuan registered, Referral Bonus20.%transfered into Register Coin', null, null, '0.10', '0.00', '0.10', null, '2017-09-05', '2017-09-05 15:29:59', '0');
INSERT INTO `wgi_price_info` VALUES ('450', '5', '124', 'tang002', null, 'juanjuan 注册,见点奖的20%转为注册币', 'juanjuan registered, Referral Bonus20.%transfered into Register Coin', null, null, '9902.30', '9902.20', '0.10', null, '2017-09-05', '2017-09-05 15:29:59', '0');
INSERT INTO `wgi_price_info` VALUES ('451', '5', '123', 'tang001', null, 'juanjuan 注册,见点奖的20%转为注册币', 'juanjuan registered, Referral Bonus20.%transfered into Register Coin', null, null, '989705.52', '989705.42', '0.10', null, '2017-09-05', '2017-09-05 15:29:59', '0');
INSERT INTO `wgi_price_info` VALUES ('452', '2', '123', 'tang001', null, 'tang006 注册账号支出', 'tang006 Register', null, null, '989205.52', '989305.52', '100.00', null, '2017-09-05', '2017-09-05 15:35:46', '0');
INSERT INTO `wgi_price_info` VALUES ('453', '5', '123', 'tang001', null, 'tang006 注册,推荐奖的20%转为注册币', 'tang006 registered, Referral Bonus20.%transfered into Register Coin', null, null, '989206.72', '989205.52', '1.20', null, '2017-09-05', '2017-09-05 15:35:46', '0');
INSERT INTO `wgi_price_info` VALUES ('454', '5', '127', 'tang003', null, 'tang006 注册,见点奖的20%转为注册币', 'tang006 registered, Referral Bonus20.%transfered into Register Coin', null, null, '0.10', '0.00', '0.10', null, '2017-09-05', '2017-09-05 15:35:46', '0');
INSERT INTO `wgi_price_info` VALUES ('455', '2', '123', 'tang001', null, 'tang007 注册账号支出', 'tang007 Register', null, null, '988206.72', '989206.72', '1000.00', null, '2017-09-05', '2017-09-05 15:52:28', '0');
INSERT INTO `wgi_price_info` VALUES ('456', '5', '123', 'tang001', null, 'tang007 注册,推荐奖的20%转为注册币', 'tang007 registered, Referral Bonus20.%transfered into Register Coin', null, null, '988218.72', '988206.72', '12.00', null, '2017-09-05', '2017-09-05 15:52:28', '0');
INSERT INTO `wgi_price_info` VALUES ('457', '5', '131', 'tang006', null, 'tang007 注册,见点奖的20%转为注册币', 'tang007 registered, Referral Bonus20.%transfered into Register Coin', null, null, '1.00', '0.00', '1.00', null, '2017-09-05', '2017-09-05 15:52:28', '0');
INSERT INTO `wgi_price_info` VALUES ('458', '5', '127', 'tang003', null, 'tang007 注册,见点奖的20%转为注册币', 'tang007 registered, Referral Bonus20.%transfered into Register Coin', null, null, '1.10', '0.10', '1.00', null, '2017-09-05', '2017-09-05 15:52:28', '0');
INSERT INTO `wgi_price_info` VALUES ('459', '5', '123', 'tang001', null, 'tang007 注册,见点奖的20%转为注册币', 'tang007 registered, Referral Bonus20.%transfered into Register Coin', null, null, '988219.72', '988218.72', '1.00', null, '2017-09-05', '2017-09-05 15:52:28', '0');
INSERT INTO `wgi_price_info` VALUES ('460', '5', '123', 'tang001', null, 'tang007 注册,对碰奖的20%转为注册币', 'tang007 registered, Referral Bonus20.%transfered into Register Coin', null, null, '988228.12', '988219.72', '8.40', null, '2017-09-05', '2017-09-05 15:52:28', '0');

-- ----------------------------
-- Table structure for wgi_price_integral_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_price_integral_info`;
CREATE TABLE `wgi_price_integral_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '积分',
  `type` int(11) DEFAULT '0' COMMENT '1充值，2 获得,3 出售 ，4转成注册币 ',
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `order_id` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `title_en` varchar(255) DEFAULT NULL,
  `title_sp` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `new_number` decimal(10,2) DEFAULT '0.00',
  `old_number` decimal(10,2) DEFAULT '0.00',
  `number` decimal(10,2) DEFAULT '0.00',
  `admin_id` int(11) DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_price_integral_info
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_price_money_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_price_money_info`;
CREATE TABLE `wgi_price_money_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `type` tinyint(1) DEFAULT '0' COMMENT '交易类型（1-充值，2-动态获得，3-出售，4-转成注册币，5-取消出售返还，6-购买）',
  `member_id` int(11) unsigned DEFAULT NULL COMMENT '会员ID',
  `member_username` varchar(50) DEFAULT NULL COMMENT '会员账号',
  `order_id` varchar(50) DEFAULT NULL COMMENT '订单编号',
  `title` varchar(255) DEFAULT NULL COMMENT '交易标题-中文',
  `title_en` varchar(255) DEFAULT NULL COMMENT '交易标题-英文',
  `title_sp` varchar(255) DEFAULT NULL COMMENT '交易标题-西班牙文',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注说明',
  `new_price` decimal(10,2) DEFAULT '0.00' COMMENT '现金币币钱包交易后的金额数量',
  `old_price` decimal(10,2) DEFAULT '0.00' COMMENT '现金币币钱包交易前的金额数量',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '交易金额数量',
  `change_price` decimal(10,2) DEFAULT '0.00' COMMENT '改变的金额数',
  `server_buy_id` int(11) unsigned DEFAULT NULL COMMENT '买入的会员ID',
  `server_sell_id` int(11) unsigned DEFAULT NULL COMMENT '出售的会员ID',
  `admin_id` int(11) DEFAULT NULL COMMENT '操作的管理员ID',
  `status` tinyint(1) DEFAULT '4' COMMENT '状态（0-待抢单，1-已抢单，2-已付款，3-已拒绝收款， 4-完成）',
  `touch_time` datetime DEFAULT NULL COMMENT '对碰时间',
  `adddate` date DEFAULT NULL COMMENT '交易日期',
  `addtime` datetime DEFAULT NULL COMMENT '交易日期时间',
  `delete` tinyint(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=387 DEFAULT CHARSET=utf8 COMMENT='现金币交易记录';

-- ----------------------------
-- Records of wgi_price_money_info
-- ----------------------------
INSERT INTO `wgi_price_money_info` VALUES ('361', '1', '123', 'tang001', 'CC7042106', '现金币充值', 'Cash coin recharge', null, null, '1000000.00', '0.00', '1000000.00', '0.00', null, null, '1', '4', null, '2017-09-05', '2017-09-05 14:19:39', '0');
INSERT INTO `wgi_price_money_info` VALUES ('362', '4', '123', 'tang001', 'WGIC2888458', '现金币转注册币', 'CC Transfers RC', 'CC Transfers RC', null, '999900.00', '1000000.00', '100.00', '0.00', null, null, null, '4', null, null, '2017-09-05 14:25:16', '0');
INSERT INTO `wgi_price_money_info` VALUES ('363', '5', '123', 'tang001', 'CB6272572', 'tang002 注册,推荐奖的80%转为现金币', 'tang002 registered, POS Bonus80% transfered into Cash Coin', null, null, '999904.00', '999900.00', '4.00', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 14:27:04', '0');
INSERT INTO `wgi_price_money_info` VALUES ('364', '5', '123', 'tang001', 'CB8532895', 'tang002 注册,见点奖的80%转为现金币', 'tang002 registered, POS Bonus80% transfered into Cash Coin', null, null, '999904.40', '999904.00', '0.40', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 14:27:04', '0');
INSERT INTO `wgi_price_money_info` VALUES ('365', '5', '123', 'tang001', 'CB9121262', 'tang003 注册,推荐奖的80%转为现金币', 'tang003 registered, POS Bonus80% transfered into Cash Coin', null, null, '999908.40', '999904.40', '4.00', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:12:28', '0');
INSERT INTO `wgi_price_money_info` VALUES ('366', '5', '123', 'tang001', 'CB5442859', 'tang003 注册,见点奖的80%转为现金币', 'tang003 registered, POS Bonus80% transfered into Cash Coin', null, null, '999908.80', '999908.40', '0.40', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:12:28', '0');
INSERT INTO `wgi_price_money_info` VALUES ('367', '5', '123', 'tang001', 'CB1808306', 'tang003 注册,对碰奖的80%转为现金币', 'tang003 registered, POS Bonus80% transfered into Cash Coin', null, null, '999912.80', '999908.80', '4.00', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:12:28', '0');
INSERT INTO `wgi_price_money_info` VALUES ('368', '5', '123', 'tang001', 'CB2242881', 'tang004 注册,推荐奖的80%转为现金币', 'tang004 registered, POS Bonus80% transfered into Cash Coin', null, null, '999916.80', '999912.80', '4.00', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:15:34', '0');
INSERT INTO `wgi_price_money_info` VALUES ('369', '5', '124', 'tang002', 'CB1707362', 'tang004 注册,见点奖的80%转为现金币', 'tang004 registered, POS Bonus80% transfered into Cash Coin', null, null, '0.40', '0.00', '0.40', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:15:34', '0');
INSERT INTO `wgi_price_money_info` VALUES ('370', '5', '123', 'tang001', 'CB8899219', 'tang004 注册,见点奖的80%转为现金币', 'tang004 registered, POS Bonus80% transfered into Cash Coin', null, null, '999917.20', '999916.80', '0.40', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:15:34', '0');
INSERT INTO `wgi_price_money_info` VALUES ('371', '5', '124', 'tang002', 'CB9308907', 'tang005 注册,推荐奖的80%转为现金币', 'tang005 registered, POS Bonus80% transfered into Cash Coin', null, null, '4.40', '0.40', '4.00', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:23:23', '0');
INSERT INTO `wgi_price_money_info` VALUES ('372', '5', '124', 'tang002', 'CB9309381', 'tang005 注册,见点奖的80%转为现金币', 'tang005 registered, POS Bonus80% transfered into Cash Coin', null, null, '4.80', '4.40', '0.40', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:23:23', '0');
INSERT INTO `wgi_price_money_info` VALUES ('373', '5', '123', 'tang001', 'CB9279113', 'tang005 注册,见点奖的80%转为现金币', 'tang005 registered, POS Bonus80% transfered into Cash Coin', null, null, '999917.60', '999917.20', '0.40', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:23:23', '0');
INSERT INTO `wgi_price_money_info` VALUES ('374', '5', '124', 'tang002', 'CB2322265', 'tang005 注册,对碰奖的80%转为现金币', 'tang005 registered, POS Bonus80% transfered into Cash Coin', null, null, '8.80', '4.80', '4.00', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:23:23', '0');
INSERT INTO `wgi_price_money_info` VALUES ('375', '5', '123', 'tang001', 'CB8436240', 'tang005 注册,领导奖的80%转为现金币', 'tang005 registered, POS Bonus80% transfered into Cash Coin', null, null, '999917.68', '999917.60', '0.08', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:23:23', '0');
INSERT INTO `wgi_price_money_info` VALUES ('376', '5', '123', 'tang001', 'CB2106111', 'juanjuan 注册,推荐奖的80%转为现金币', 'juanjuan registered, POS Bonus80% transfered into Cash Coin', null, null, '999921.68', '999917.68', '4.00', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:29:59', '0');
INSERT INTO `wgi_price_money_info` VALUES ('377', '5', '128', 'tang004', 'CB7397700', 'juanjuan 注册,见点奖的80%转为现金币', 'juanjuan registered, POS Bonus80% transfered into Cash Coin', null, null, '0.40', '0.00', '0.40', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:29:59', '0');
INSERT INTO `wgi_price_money_info` VALUES ('378', '5', '124', 'tang002', 'CB8331712', 'juanjuan 注册,见点奖的80%转为现金币', 'juanjuan registered, POS Bonus80% transfered into Cash Coin', null, null, '9.20', '8.80', '0.40', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:29:59', '0');
INSERT INTO `wgi_price_money_info` VALUES ('379', '5', '123', 'tang001', 'CB2857136', 'juanjuan 注册,见点奖的80%转为现金币', 'juanjuan registered, POS Bonus80% transfered into Cash Coin', null, null, '999922.08', '999921.68', '0.40', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:29:59', '0');
INSERT INTO `wgi_price_money_info` VALUES ('380', '5', '123', 'tang001', 'CB3995712', 'tang006 注册,推荐奖的80%转为现金币', 'tang006 registered, POS Bonus80% transfered into Cash Coin', null, null, '999926.88', '999922.08', '4.80', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:35:46', '0');
INSERT INTO `wgi_price_money_info` VALUES ('381', '5', '127', 'tang003', 'CB8257109', 'tang006 注册,见点奖的80%转为现金币', 'tang006 registered, POS Bonus80% transfered into Cash Coin', null, null, '0.40', '0.00', '0.40', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:35:46', '0');
INSERT INTO `wgi_price_money_info` VALUES ('382', '5', '123', 'tang001', 'CB5951942', 'tang007 注册,推荐奖的80%转为现金币', 'tang007 registered, POS Bonus80% transfered into Cash Coin', null, null, '999974.88', '999926.88', '48.00', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:52:28', '0');
INSERT INTO `wgi_price_money_info` VALUES ('383', '5', '131', 'tang006', 'CB3840711', 'tang007 注册,见点奖的80%转为现金币', 'tang007 registered, POS Bonus80% transfered into Cash Coin', null, null, '4.00', '0.00', '4.00', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:52:28', '0');
INSERT INTO `wgi_price_money_info` VALUES ('384', '5', '127', 'tang003', 'CB8292521', 'tang007 注册,见点奖的80%转为现金币', 'tang007 registered, POS Bonus80% transfered into Cash Coin', null, null, '4.40', '0.40', '4.00', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:52:28', '0');
INSERT INTO `wgi_price_money_info` VALUES ('385', '5', '123', 'tang001', 'CB8419725', 'tang007 注册,见点奖的80%转为现金币', 'tang007 registered, POS Bonus80% transfered into Cash Coin', null, null, '999978.88', '999974.88', '4.00', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:52:28', '0');
INSERT INTO `wgi_price_money_info` VALUES ('386', '5', '123', 'tang001', 'CB8208532', 'tang007 注册,对碰奖的80%转为现金币', 'tang007 registered, POS Bonus80% transfered into Cash Coin', null, null, '1000012.48', '999978.88', '33.60', '0.00', null, null, null, '4', null, '2017-09-05', '2017-09-05 15:52:28', '0');

-- ----------------------------
-- Table structure for wgi_price_touch_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_price_touch_info`;
CREATE TABLE `wgi_price_touch_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT '0' COMMENT '1充值，2 获得,3 出售 ，4转成注册币 ',
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `order_id` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `title_en` varchar(255) DEFAULT NULL,
  `title_sp` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `new_price` decimal(10,2) DEFAULT '0.00',
  `old_price` decimal(10,2) DEFAULT '0.00',
  `price` decimal(10,2) DEFAULT '0.00',
  `admin_id` int(11) DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_price_touch_info
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_protocol
-- ----------------------------
DROP TABLE IF EXISTS `wgi_protocol`;
CREATE TABLE `wgi_protocol` (
  `id` int(1) DEFAULT NULL COMMENT '键',
  `protocol` text COMMENT '键',
  `protocol_en` text COMMENT '值',
  `description` text COMMENT '说明',
  `description_en` text
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='系统配置表';

-- ----------------------------
-- Records of wgi_protocol
-- ----------------------------
INSERT INTO `wgi_protocol` VALUES ('1', '&lt;p&gt;asd&lt;/p&gt;', '&lt;p&gt;asd&lt;/p&gt;', '&lt;p&gt;asd&lt;/p&gt;', '&lt;p&gt;asd如同如同阿萨德阿萨德阿萨德阿萨德asd&lt;/p&gt;');

-- ----------------------------
-- Table structure for wgi_reg_code
-- ----------------------------
DROP TABLE IF EXISTS `wgi_reg_code`;
CREATE TABLE `wgi_reg_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `remark` text,
  `changetime` datetime DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_reg_code
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_repeat_order_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_repeat_order_info`;
CREATE TABLE `wgi_repeat_order_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) DEFAULT NULL,
  `type` int(11) DEFAULT '0' COMMENT '1,转入,2,转出',
  `member_id` int(11) DEFAULT NULL COMMENT '所属用户',
  `member_username` varchar(50) DEFAULT NULL,
  `pay_number` int(11) DEFAULT '0' COMMENT '交易股数',
  `share_price` decimal(10,3) DEFAULT '0.000' COMMENT '股价',
  `pay_price` decimal(10,2) DEFAULT '0.00' COMMENT '交易金额',
  `split_id` int(11) DEFAULT NULL,
  `title` text,
  `remark` text,
  `touch_datetime` datetime DEFAULT NULL COMMENT '配股日期',
  `free_datetime` datetime DEFAULT NULL COMMENT '解冻日期',
  `status` tinyint(1) DEFAULT '0' COMMENT '0 配股(排队中) 1,已配股    4 完成',
  `adddate` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_repeat_order_info
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_role
-- ----------------------------
DROP TABLE IF EXISTS `wgi_role`;
CREATE TABLE `wgi_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `name` varchar(20) NOT NULL COMMENT '名称',
  `pid` smallint(6) DEFAULT NULL COMMENT '上级角色ID',
  `status` tinyint(1) unsigned DEFAULT NULL COMMENT '状态（0-停用，1-启用）',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_role
-- ----------------------------
INSERT INTO `wgi_role` VALUES ('1', '管理员', null, '1', '管理员组');
INSERT INTO `wgi_role` VALUES ('2', '客户部', null, '1', '客户人员组');

-- ----------------------------
-- Table structure for wgi_role_user
-- ----------------------------
DROP TABLE IF EXISTS `wgi_role_user`;
CREATE TABLE `wgi_role_user` (
  `role_id` mediumint(9) unsigned DEFAULT NULL,
  `user_id` char(32) DEFAULT NULL,
  KEY `group_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_role_user
-- ----------------------------
INSERT INTO `wgi_role_user` VALUES ('0', '1');

-- ----------------------------
-- Table structure for wgi_server_buy_price
-- ----------------------------
DROP TABLE IF EXISTS `wgi_server_buy_price`;
CREATE TABLE `wgi_server_buy_price` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `order_number` varchar(50) DEFAULT NULL COMMENT '订单编号',
  `member_id` int(11) DEFAULT NULL COMMENT '购买会员ID',
  `member_username` varchar(50) DEFAULT NULL COMMENT '购买会员账号',
  `member_telephone` varchar(50) DEFAULT NULL COMMENT '购买会员手机号码',
  `picture` varchar(255) DEFAULT NULL,
  `money_id` int(11) DEFAULT NULL COMMENT '现金币交易记录ID',
  `title` varchar(50) DEFAULT NULL COMMENT '标题-中文',
  `title_en` varchar(50) DEFAULT NULL COMMENT '标题-英文',
  `title_sp` varchar(50) DEFAULT NULL COMMENT '标题-西班牙文',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '购买金额数量',
  `price_turn` decimal(10,2) DEFAULT '0.00' COMMENT '折扣率',
  `system_price` decimal(10,2) DEFAULT '0.00' COMMENT '实际购买金额',
  `status` int(1) DEFAULT '0' COMMENT '1-已抢单，2-买家已付款，3-完成',
  `adddate` date DEFAULT NULL COMMENT '购买日期',
  `addtime` datetime DEFAULT NULL COMMENT '购买时间',
  `delete` tinyint(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='现金币购买记录';

-- ----------------------------
-- Records of wgi_server_buy_price
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_server_price_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_server_price_info`;
CREATE TABLE `wgi_server_price_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `type` int(11) DEFAULT NULL COMMENT '1,收入(卖出)   2,支出  (买入) 3,提现 4,退回',
  `title` varchar(50) DEFAULT NULL,
  `title_en` varchar(50) DEFAULT NULL,
  `title_sp` varchar(50) DEFAULT NULL,
  `remark` text,
  `price` decimal(10,2) DEFAULT '0.00',
  `usd_price` decimal(10,2) DEFAULT '0.00',
  `adddate` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_server_price_info
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_share_number_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_share_number_info`;
CREATE TABLE `wgi_share_number_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(1) DEFAULT '0' COMMENT '1,转入 2,转出，4-回购',
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `title_en` varchar(255) NOT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `new_number` decimal(10,0) DEFAULT '0' COMMENT '最新数量',
  `old_number` decimal(10,0) DEFAULT '0',
  `number` decimal(10,0) DEFAULT '0' COMMENT '交易数量',
  `admin_id` int(11) DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_share_number_info
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_share_order_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_share_order_info`;
CREATE TABLE `wgi_share_order_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户股份池',
  `order_number` varchar(50) DEFAULT NULL COMMENT '用户订单号',
  `type` int(11) DEFAULT '0' COMMENT '1,买入,2,卖出3.复投',
  `member_id` int(11) DEFAULT NULL COMMENT '所属用户',
  `member_username` varchar(50) DEFAULT NULL COMMENT '用户名称',
  `pay_number` int(11) DEFAULT '0' COMMENT '交易股数',
  `share_price` decimal(10,2) DEFAULT '0.00' COMMENT '股价',
  `pay_price` decimal(10,2) DEFAULT '0.00' COMMENT '交易金额',
  `rest_sell` int(11) NOT NULL DEFAULT '0' COMMENT '剩下能出售股份的数量',
  `title` varchar(255) DEFAULT NULL,
  `title_en` varchar(255) DEFAULT NULL,
  `title_sp` varchar(255) DEFAULT NULL,
  `remark` text,
  `queue_bt` int(11) NOT NULL DEFAULT '0' COMMENT '排队出售补差价',
  `touch_datetime` datetime DEFAULT NULL COMMENT '配股日期',
  `status` tinyint(1) DEFAULT '0' COMMENT '0 配股(排队中) 1,已配股    4 完成',
  `adddate` date DEFAULT NULL,
  `addtime` datetime NOT NULL,
  `delete` int(11) NOT NULL DEFAULT '0',
  `dzid` int(10) DEFAULT '0' COMMENT '电子订单ID',
  PRIMARY KEY (`id`,`addtime`)
) ENGINE=InnoDB AUTO_INCREMENT=214 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_share_order_info
-- ----------------------------
INSERT INTO `wgi_share_order_info` VALUES ('204', 'SR2525536', '1', '124', 'tang002', '24', '2.06', '50.00', '0', '认购', 'Register', null, null, '0', '0000-00-00 00:00:00', '0', '2017-09-05', '2017-09-05 14:27:04', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('205', 'SR3833895', '1', '126', 'tang888', '24', '2.06', '50.00', '0', '认购', 'Register', null, null, '0', '0000-00-00 00:00:00', '0', '2017-09-05', '2017-09-05 14:55:17', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('206', 'SR8705399', '1', '127', 'tang003', '24', '2.06', '50.00', '0', '认购', 'Register', null, null, '0', '0000-00-00 00:00:00', '0', '2017-09-05', '2017-09-05 15:12:28', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('207', 'SR4629642', '1', '128', 'tang004', '24', '2.06', '50.00', '0', '认购', 'Register', null, null, '0', '0000-00-00 00:00:00', '0', '2017-09-05', '2017-09-05 15:15:34', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('208', 'SR5907474', '1', '129', 'tang005', '24', '2.06', '50.00', '0', '认购', 'Register', null, null, '0', '0000-00-00 00:00:00', '0', '2017-09-05', '2017-09-05 15:23:23', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('209', 'SR2683260', '1', '130', 'juanjuan', '24', '2.06', '50.00', '0', '认购', 'Register', null, null, '0', '0000-00-00 00:00:00', '0', '2017-09-05', '2017-09-05 15:29:59', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('210', 'SR3538713', '1', '123', 'tang001', '101', '2.06', '208.00', '0', '认购', 'Register', null, null, '0', '0000-00-00 00:00:00', '0', '2017-09-05', '2017-09-05 15:30:23', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('211', 'SR1586305', '1', '131', 'tang006', '24', '2.06', '50.00', '0', '认购', 'Register', null, null, '0', '0000-00-00 00:00:00', '0', '2017-09-05', '2017-09-05 15:35:46', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('212', 'SR8331886', '1', '124', 'tang002', '101', '2.06', '208.00', '0', '认购', 'Register', null, null, '0', '0000-00-00 00:00:00', '0', '2017-09-05', '2017-09-05 15:47:46', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('213', 'SR8317959', '1', '132', 'tang007', '262', '2.06', '540.00', '0', '认购', 'Register', null, null, '0', '0000-00-00 00:00:00', '0', '2017-09-05', '2017-09-05 15:52:28', '0', '0');

-- ----------------------------
-- Table structure for wgi_share_system_order_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_share_system_order_info`;
CREATE TABLE `wgi_share_system_order_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '平台股份池',
  `order_number` varchar(50) DEFAULT NULL COMMENT '用户订单号',
  `type` int(11) DEFAULT '0' COMMENT '1.回购',
  `member_id` int(11) DEFAULT NULL COMMENT '所属用户',
  `member_username` varchar(50) DEFAULT NULL COMMENT '用户名称',
  `pay_number` int(11) DEFAULT '0' COMMENT '交易股数',
  `share_price` decimal(10,2) DEFAULT '0.00' COMMENT '股价',
  `pay_price` decimal(10,2) DEFAULT '0.00' COMMENT '交易金额',
  `title` varchar(255) DEFAULT NULL,
  `title_en` varchar(255) DEFAULT NULL,
  `remark` text,
  `touch_datetime` datetime DEFAULT NULL COMMENT '配股日期',
  `adddate` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_share_system_order_info
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_sms
-- ----------------------------
DROP TABLE IF EXISTS `wgi_sms`;
CREATE TABLE `wgi_sms` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一递增编号',
  `member_id` int(11) DEFAULT NULL COMMENT '用户id',
  `tel` varchar(32) DEFAULT NULL COMMENT '手机号码',
  `content` varchar(255) DEFAULT NULL COMMENT '内容',
  `sendtime` datetime DEFAULT NULL COMMENT '发送时间',
  `code` char(10) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL COMMENT '类别（zcyz-注册验证，shtg-审核通过，jhtx-激活提醒，zhmm-找回密码，dktx-打款提醒，xgxx-修改信息，xgzh-收款账户，aqzx-安全中心，xgsj-修改手机号码）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8 COMMENT='短信';

-- ----------------------------
-- Records of wgi_sms
-- ----------------------------
INSERT INTO `wgi_sms` VALUES ('26', '105', '18373954288', '【WGI】您正在进入安全设置修改页面，验证码为：2726', '2017-09-04 15:57:51', '2726', 'AQZX');
INSERT INTO `wgi_sms` VALUES ('27', '105', '18373954288', '【WGI】您正在进入收款账户修改页面，验证码为：4994', '2017-09-04 16:49:08', '4994', 'XGZH');
INSERT INTO `wgi_sms` VALUES ('28', '105', '18373954288', '【WGI】您正在进入安全设置修改页面，验证码为：7277', '2017-09-04 17:34:21', '7277', 'AQZX');
INSERT INTO `wgi_sms` VALUES ('29', '120', '18773583400', '【WGI】您正在进入安全设置修改页面，验证码为：1906', '2017-09-05 10:48:58', '1906', 'AQZX');
INSERT INTO `wgi_sms` VALUES ('30', '123', '18373954288', '【WGI】您正在进入安全设置修改页面，验证码为：2012', '2017-09-05 14:20:32', '2012', 'AQZX');
INSERT INTO `wgi_sms` VALUES ('31', '125', '18773583400', '【WGI】您正在进入安全设置修改页面，验证码为：9629', '2017-09-05 14:35:56', '9629', 'AQZX');
INSERT INTO `wgi_sms` VALUES ('32', null, '18773583400', '【WGI】您的找回密码验证码为1024', '2017-09-05 15:18:22', '1024', 'ZHMM');
INSERT INTO `wgi_sms` VALUES ('33', '130', '18673112520', '【WGI】您正在进入收款账户修改页面，验证码为：6008', '2017-09-05 15:36:40', '6008', 'XGZH');

-- ----------------------------
-- Table structure for wgi_split
-- ----------------------------
DROP TABLE IF EXISTS `wgi_split`;
CREATE TABLE `wgi_split` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `old_all_share` varchar(50) DEFAULT NULL COMMENT '拆分前总股数',
  `new_all_share` varchar(50) DEFAULT NULL,
  `split_double` decimal(10,2) DEFAULT '0.00',
  `split_price` decimal(10,3) DEFAULT '0.000',
  `split_new_price` decimal(10,3) DEFAULT '0.000',
  `admin_id` int(11) DEFAULT NULL,
  `admin_name` varchar(50) DEFAULT NULL,
  `remark` varchar(50) DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_split
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_trade_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_trade_info`;
CREATE TABLE `wgi_trade_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `order_number` varchar(50) DEFAULT NULL COMMENT '订单编号',
  `sell_member_id` int(11) unsigned DEFAULT NULL COMMENT '出售会员ID',
  `buy_member_id` int(11) unsigned DEFAULT NULL COMMENT '购买会员ID',
  `sell_member_username` varchar(50) DEFAULT NULL COMMENT '出售会员账号',
  `buy_member_username` varchar(50) DEFAULT NULL COMMENT '购买会员账号',
  `pay_picture` varchar(255) DEFAULT NULL COMMENT '打款凭证图片',
  `sell_money_id` int(11) unsigned DEFAULT NULL COMMENT '出售会员钱包交易记录ID',
  `buy_money_id` int(11) DEFAULT NULL COMMENT '购买会员钱包交易记录ID',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '交易金额',
  `system_price` decimal(10,2) DEFAULT '0.00' COMMENT '系统交易金额',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注说明',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态（0-待抢单， 1-已抢单， 2-买家已付款，3-拒绝收款，4-确认收款）',
  `qdtime` datetime DEFAULT NULL COMMENT '购买会员抢单时间',
  `paytime` datetime DEFAULT NULL COMMENT '购买会员付款时间',
  `entertime` datetime DEFAULT NULL COMMENT '出售会员确认收款时间',
  `adddate` date DEFAULT NULL COMMENT '出售会员申请卖出日期',
  `addtime` datetime DEFAULT NULL COMMENT '出售会员申请卖出时间',
  `delete` tinyint(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COMMENT='现金币出售记录';

-- ----------------------------
-- Records of wgi_trade_info
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_upgrade
-- ----------------------------
DROP TABLE IF EXISTS `wgi_upgrade`;
CREATE TABLE `wgi_upgrade` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `upsn` varchar(20) DEFAULT '' COMMENT '编号',
  `mid` int(10) DEFAULT '0' COMMENT '会员ID',
  `mname` varchar(32) DEFAULT '' COMMENT '会员姓名',
  `old_lv` int(10) DEFAULT '0' COMMENT '原级别',
  `new_lv` int(10) DEFAULT '0' COMMENT '新级别',
  `diff` decimal(10,2) DEFAULT '0.00' COMMENT '差价',
  `addtime` datetime DEFAULT NULL COMMENT '升级时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_upgrade
-- ----------------------------
INSERT INTO `wgi_upgrade` VALUES ('12', 'UP9729168', '123', 'tang001', '1', '2', '400.00', '2017-09-05 15:30:23');
INSERT INTO `wgi_upgrade` VALUES ('13', 'UP5558306', '124', 'tang002', '1', '2', '400.00', '2017-09-05 15:47:46');

-- ----------------------------
-- Table structure for wgi_verify
-- ----------------------------
DROP TABLE IF EXISTS `wgi_verify`;
CREATE TABLE `wgi_verify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `number` int(11) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_verify
-- ----------------------------
