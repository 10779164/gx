

#!/bin/bash

###wgi运行脚本
while :
do
curl -s "http://47.94.101.127:8000/index.php?m=Home&c=Auto&a=is_boom"
curl -s "http://47.94.101.127:8000/index.php?m=Home&c=Auto&a=index"
sleep 10
done