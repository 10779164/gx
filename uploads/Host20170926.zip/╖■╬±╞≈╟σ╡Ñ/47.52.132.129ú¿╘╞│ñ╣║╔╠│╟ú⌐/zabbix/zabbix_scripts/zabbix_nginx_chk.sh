#!/bin/bash
# Nginx进程及状态监控
# 
case $1 in
	c_nginx)
		check_n=`ps -ef | grep nginx | grep -v grep`
		if [ -n "$check_n" ]
		then 
			echo '0'
		else
			echo '1'
		fi
	;;

 	# 活跃的连接数
	active)
	curl -s http://127.0.0.1/ngx_status | awk '/Active/ {print $3}'
	;;

	# 连接总数
	accepts)
	curl -s http://127.0.0.1/ngx_status | awk 'NR==3 {print $1}'
	;;

	# 处理总数
	handled)
	curl -s http://127.0.0.1/ngx_status | awk 'NR==3 {print $2}'
	;;

	# 请求总数
	requests)
	curl -s http://127.0.0.1/ngx_status | awk 'NR==3 {print $3}'
	;;

	# 客户端的连接数
	reading)
	curl -s http://127.0.0.1/ngx_status | awk '/Reading/ {print $2}'
	;;

	# 响应数据到客户端的数量
	writing)
	curl -s http://127.0.0.1/ngx_status | awk '/Reading/ {print $4}'
	;;

	# Nginx已经处理完正在等候下一次请求指令的驻留连接.开启keep-alive的情况下,这个值等于 active – (reading+writing)
	waiting)
	curl -s http://127.0.0.1/ngx_status | awk '/Reading/ {print $6}'
	;;
	
esac





