#!/bin/bash
# php-fpm进程及状态监控
# 
case $1 in
	c_php_fpm)
		check_php=`ps -ef | grep php-fpm | grep -v grep`
		if [ -n "$check_php" ]
		then 
			echo '0'
		else
			echo '1'
		fi
	;;

 	# 当前池子接受的请求数
	accepted_conn)
	curl -s http://127.0.0.1/phpfpm_status | awk 'NR==5 {print $3}'
	;;

	# 请求等待队列，如果这个值不为0，那么要增加FPM的进程数量
	listen_queue)
	curl -s http://127.0.0.1/phpfpm_status | awk 'NR==6 {print $3}'
	;;

	# socket等待队列长度
	listen_queue_len)
	curl -s http://127.0.0.1/phpfpm_status | awk 'NR==8 {print $4}'
	;;

	# 空闲进程数量
	idle_processes)
	curl -s http://127.0.0.1/phpfpm_status | awk 'NR==9 {print $3}'
	;;

	# 活跃进程数量
	active_processes)
	curl -s http://127.0.0.1/phpfpm_status |  awk 'NR==10 {print $3}'
	;;

	# 总进程数量
	total_processes)
	curl -s http://127.0.0.1/phpfpm_status | awk 'NR==11 {print $3}'
	;;

	# 进程最大数量限制的次数，如果这个数量不为0，那说明你的最大进程数量太小了，请改大一点
	max_children_reached)
	curl -s http://127.0.0.1/phpfpm_status | awk 'NR==13 {print $4}'
	;;
	
	# 启用了php-fpm slow-log，缓慢请求的数量
	slow_requests)
	curl -s http://127.0.0.1/phpfpm_status | awk 'NR==14 {print $3}'
	;;
	
esac
