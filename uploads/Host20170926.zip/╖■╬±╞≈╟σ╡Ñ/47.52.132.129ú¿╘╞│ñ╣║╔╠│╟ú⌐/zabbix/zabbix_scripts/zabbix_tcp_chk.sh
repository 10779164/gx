#!/bin/bash
# TCP连接数
# 
IP=`ip addr | grep "inet " | grep -v "127.0.0.1" | awk '{print $2}' | cut -d/ -f1`

case $1 in

		# 80端口连接数
	80)
		netstat -an | awk '{print $4}' | grep "$IP:80$" | /usr/bin/wc -l
	;;

		# 443端口连接数
	443)
		netstat -an | awk '{print $4}' | grep "$IP:443$" | /usr/bin/wc -l
	;;

		# 打开的连接数
	ESTABLISHED)
		netstat -an | grep "ESTABLISHED" | /usr/bin/wc -l
	;;

		# 监听的TCP端口的连接请求数
	LISTEN)
		netstat -an | grep "LISTEN " | /usr/bin/wc -l
	;;

		# 等待关闭的连接数（从远程TCP等待连接中断请求）
	CLOSE_WAIT)
		netstat -an | grep "CLOSE_WAIT" | /usr/bin/wc -l
	;;

		# 无连接的数量
	CLOSE)
		netstat -an | grep "CLOSE" | /usr/bin/wc -l
	;;

		# 等待足够的时间以确保远程TCP接收到连接中断请求的确认（表示收到了对方的FIN报文，并发送出了ACK报文，等待2MSL后就可回到CLOSED状态）
	TIME_WAIT)
		netstat -an | grep "TIME_WAIT" | /usr/bin/wc -l
	;;

		# 等待远程TCP连接中断请求，或先前的连接中断请求的确认
	FIN_WAIT1)
		netstat -an | grep "FIN_WAIT1" | /usr/bin/wc -l
	;;
	
		# 从远程TCP等待连接中断请求
	FIN_WAIT2)
		netstat -an | grep "FIN_WAIT2" | /usr/bin/wc -l
	;;
	
		# 等待远程TCP对连接中断的确认
	CLOSING)
		netstat -an | grep "CLOSING" | /usr/bin/wc -l
	;;
	
		# 接收到SYN报文  
	SYN_RECV)
		netstat -an | grep "SYN_RECV" | /usr/bin/wc -l
	;;
	
		# 已发送的SYN报文  
	SYN_SENT)	
		netstat -an | grep "SYN_SENT" | /usr/bin/wc -l
	;;
		 
		# 等待原来的发向远程TCP的连接中断请求的确认
	LAST_ACK)
		netstat -an | grep "LAST_ACK" | /usr/bin/wc -l
	;;
		 
esac