#!/bin/bash
# redis监控

case $1 in
	# 进程是否存在
	c_redis)
		check_r =`ps -ef | grep redis | grep -v grep`
		if [ -n $check_r ]
		then
			echo '0'
		else
			echo '1'
		fi
	;;

	# Clients
	# 客户端连接数
	connected_clients)
		/usr/local/bin/redis-cli info | grep connected_clients | cut -d: -f2
	;;

	# Memory
	# redis分配的内存数byte
	used_memory)
		/usr/local/bin/redis-cli info | grep used_memory | cut -d: -f2 | awk 'NR==1 {print $1}'
	;;

	# 操作系统的角度返回redis分配的内存总量byte（常驻大小），该值和top、ps等命令的输出结果一致
	# rss > used ，且两者的值相差较大时，表示存在（内部或外部的）内存碎片。
	used_memory_rss)
		/usr/local/bin/redis-cli info | grep used_memory_rss | cut -d: -f2 | awk 'NR==1 {print $1}'
	;;

	# Stats
	# 运行以来过期的key数量
	expired_keys)
		/usr/local/bin/redis-cli info | grep expired_keys | cut -d: -f2
	;;

	# 运行以来删除过的key数量
	evicted_keys)
		/usr/local/bin/redis-cli info | grep evicted_keys | cut -d: -f2
	;;

	# 命中key 的次数
	keyspace_hits)
		/usr/local/bin/redis-cli info | grep keyspace_hits | cut -d: -f2
	;;

	# 没命中key 的次数
	keyspace_misses)
		/usr/local/bin/redis-cli info | grep keyspace_misses | cut -d: -f2
	;;
	
esac
