/*
Navicat MySQL Data Transfer

Source Server         : 25.156
Source Server Version : 50636
Source Host           : 47.93.25.156:33065
Source Database       : wgi_20170822

Target Server Type    : MYSQL
Target Server Version : 50636
File Encoding         : 65001

Date: 2017-09-11 10:34:45
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for wgi_access
-- ----------------------------
DROP TABLE IF EXISTS `wgi_access`;
CREATE TABLE `wgi_access` (
  `role_id` smallint(6) unsigned NOT NULL,
  `node_id` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) NOT NULL,
  `module` varchar(50) DEFAULT NULL,
  KEY `groupId` (`role_id`),
  KEY `nodeId` (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_access
-- ----------------------------
INSERT INTO `wgi_access` VALUES ('1', '47', '3', null);
INSERT INTO `wgi_access` VALUES ('1', '39', '2', null);
INSERT INTO `wgi_access` VALUES ('1', '1', '1', null);
INSERT INTO `wgi_access` VALUES ('2', '45', '2', null);
INSERT INTO `wgi_access` VALUES ('2', '44', '2', null);
INSERT INTO `wgi_access` VALUES ('2', '43', '2', null);
INSERT INTO `wgi_access` VALUES ('2', '42', '2', null);
INSERT INTO `wgi_access` VALUES ('2', '41', '2', null);
INSERT INTO `wgi_access` VALUES ('2', '40', '2', null);
INSERT INTO `wgi_access` VALUES ('2', '39', '2', null);
INSERT INTO `wgi_access` VALUES ('2', '1', '1', null);

-- ----------------------------
-- Table structure for wgi_admin
-- ----------------------------
DROP TABLE IF EXISTS `wgi_admin`;
CREATE TABLE `wgi_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `username` varchar(50) DEFAULT NULL COMMENT '账号',
  `userpass` char(32) DEFAULT NULL COMMENT '密码',
  `realname` varchar(20) DEFAULT NULL COMMENT '称呼',
  `role_id` int(1) DEFAULT NULL COMMENT '角色',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态（0-停用，1-启用）',
  `login_ip` varchar(32) DEFAULT NULL COMMENT '登陆IP',
  `login_num` int(11) DEFAULT '0' COMMENT '登陆次数',
  `add_time` datetime DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='后台管理员';

-- ----------------------------
-- Records of wgi_admin
-- ----------------------------
INSERT INTO `wgi_admin` VALUES ('1', 'admin', '86eae00867c35ca8004eedd56ab464ef', '超级管理员', '0', '1', null, '0', null);
INSERT INTO `wgi_admin` VALUES ('3', 'admin001', 'e8092b5d0f9cb1c44bfd689c01772531', '管理员一', '1', '1', '113.246.105.69', '0', '2017-09-06 09:36:32');

-- ----------------------------
-- Table structure for wgi_cash
-- ----------------------------
DROP TABLE IF EXISTS `wgi_cash`;
CREATE TABLE `wgi_cash` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `picture` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `remark` text,
  `content` text,
  `type` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `bank` varchar(50) DEFAULT NULL,
  `recom` int(1) DEFAULT '0',
  `status` int(1) DEFAULT '0',
  `cash_id` int(11) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `delete` int(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='出售现金币';

-- ----------------------------
-- Records of wgi_cash
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_change_log
-- ----------------------------
DROP TABLE IF EXISTS `wgi_change_log`;
CREATE TABLE `wgi_change_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(50) DEFAULT NULL,
  `type` int(11) DEFAULT NULL COMMENT '1-推荐奖 2-见点奖 3-对碰奖 4-领导奖',
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `change_id` int(11) DEFAULT NULL,
  `change_username` varchar(50) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `title` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `title_en` varchar(255) DEFAULT NULL,
  `title_sp` varchar(255) DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of wgi_change_log
-- ----------------------------
INSERT INTO `wgi_change_log` VALUES ('81', 'CB3114278', '1', '23', 'tang001', '71', 'tang002', '5.00', 'tang002(1 星) 注册,您获得 推荐奖 $5.00', 'tang002(1 Star) registered, you get Referral Bonus $5.00', null, '2017-09-07', '2017-09-07 19:46:53');
INSERT INTO `wgi_change_log` VALUES ('82', 'CB9359805', '2', '23', 'tang001', '71', 'tang002', '0.50', 'tang002(1 星) 注册,您获得 见点奖 $0.5', 'tang002(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-07', '2017-09-07 19:46:53');
INSERT INTO `wgi_change_log` VALUES ('83', 'CB9765780', '5', '23', 'tang001', '71', 'tang002', '0.50', 'tang002(1 星) 注册,您获得 商务奖 $0.50', 'tang002(1 Star) registered, you get Referral Bonus $0.50', null, '2017-09-07', '2017-09-07 19:46:53');
INSERT INTO `wgi_change_log` VALUES ('84', 'CB9531619', '1', '23', 'tang001', '72', 'tang003', '5.00', 'tang003(1 星) 注册,您获得 推荐奖 $5.00', 'tang003(1 Star) registered, you get Referral Bonus $5.00', null, '2017-09-07', '2017-09-07 19:47:42');
INSERT INTO `wgi_change_log` VALUES ('85', 'CB3806835', '2', '23', 'tang001', '72', 'tang003', '0.50', 'tang003(1 星) 注册,您获得 见点奖 $0.5', 'tang003(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-07', '2017-09-07 19:47:42');
INSERT INTO `wgi_change_log` VALUES ('86', 'CB3709799', '3', '23', 'tang001', '72', 'tang003', '5.00', 'tang003(1 星) 注册,您获得 对碰奖 $5', 'tang003(1 Star) registered, you get Referral Bonus $5', null, '2017-09-07', '2017-09-07 19:47:42');
INSERT INTO `wgi_change_log` VALUES ('87', 'CB2924597', '1', '23', 'tang001', '73', 'tang004', '5.00', 'tang004(1 星) 注册,您获得 推荐奖 $5.00', 'tang004(1 Star) registered, you get Referral Bonus $5.00', null, '2017-09-07', '2017-09-07 19:48:27');
INSERT INTO `wgi_change_log` VALUES ('88', 'CB3044961', '2', '24', 'tang002', '73', 'tang004', '0.50', 'tang004(1 星) 注册,您获得 见点奖 $0.5', 'tang004(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-07', '2017-09-07 19:48:27');
INSERT INTO `wgi_change_log` VALUES ('89', 'CB8309432', '2', '23', 'tang001', '73', 'tang004', '0.50', 'tang004(1 星) 注册,您获得 见点奖 $0.5', 'tang004(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-07', '2017-09-07 19:48:27');
INSERT INTO `wgi_change_log` VALUES ('90', 'CB4275261', '1', '23', 'tang001', '74', 'tang005', '5.00', 'tang005(1 星) 注册,您获得 推荐奖 $5.00', 'tang005(1 Star) registered, you get Referral Bonus $5.00', null, '2017-09-07', '2017-09-07 19:48:52');
INSERT INTO `wgi_change_log` VALUES ('91', 'CB1128841', '2', '25', 'tang003', '74', 'tang005', '0.50', 'tang005(1 星) 注册,您获得 见点奖 $0.5', 'tang005(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-07', '2017-09-07 19:48:52');
INSERT INTO `wgi_change_log` VALUES ('92', 'CB4934142', '2', '23', 'tang001', '74', 'tang005', '0.50', 'tang005(1 星) 注册,您获得 见点奖 $0.5', 'tang005(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-07', '2017-09-07 19:48:52');
INSERT INTO `wgi_change_log` VALUES ('93', 'CB3096379', '3', '23', 'tang001', '74', 'tang005', '5.00', 'tang005(1 星) 注册,您获得 对碰奖 $5', 'tang005(1 Star) registered, you get Referral Bonus $5', null, '2017-09-07', '2017-09-07 19:48:52');
INSERT INTO `wgi_change_log` VALUES ('94', 'CB2520469', '1', '24', 'tang002', '75', 'tang006', '5.00', 'tang006(1 星) 注册,您获得 推荐奖 $5.00', 'tang006(1 Star) registered, you get Referral Bonus $5.00', null, '2017-09-07', '2017-09-07 19:51:03');
INSERT INTO `wgi_change_log` VALUES ('95', 'CB1785680', '2', '24', 'tang002', '75', 'tang006', '0.50', 'tang006(1 星) 注册,您获得 见点奖 $0.5', 'tang006(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-07', '2017-09-07 19:51:03');
INSERT INTO `wgi_change_log` VALUES ('96', 'CB1647830', '2', '23', 'tang001', '75', 'tang006', '0.50', 'tang006(1 星) 注册,您获得 见点奖 $0.5', 'tang006(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-07', '2017-09-07 19:51:03');
INSERT INTO `wgi_change_log` VALUES ('97', 'CB1253549', '3', '24', 'tang002', '75', 'tang006', '5.00', 'tang006(1 星) 注册,您获得 对碰奖 $5', 'tang006(1 Star) registered, you get Referral Bonus $5', null, '2017-09-07', '2017-09-07 19:51:03');
INSERT INTO `wgi_change_log` VALUES ('98', 'CB6024579', '4', '23', 'tang001', '75', 'tang006', '0.10', 'tang006(1 星) 注册,您获得 领导奖 $0.1', 'tang006(1 Star) registered, you get Referral Bonus $0.1', null, '2017-09-07', '2017-09-07 19:51:03');
INSERT INTO `wgi_change_log` VALUES ('99', 'CB1560722', '1', '23', 'tang001', '76', 'tang002', '20.00', 'tang002(2 星) 原点升级,您获得 推荐奖 $20.00', 'tang002(2 Star) origin upgrade, you get Referral Bonus $20.00', null, '2017-09-07', '2017-09-07 19:51:39');
INSERT INTO `wgi_change_log` VALUES ('100', 'CB1961638', '2', '23', 'tang001', '76', 'tang002', '2.00', 'tang002(2 星) 原点升级,您获得 见点奖 $2', 'tang002(2 Star) origin upgrade, you get Referral Bonus $2', null, '2017-09-07', '2017-09-07 19:51:39');
INSERT INTO `wgi_change_log` VALUES ('101', 'CB1215994', '5', '23', 'tang001', '76', 'tang002', '2.00', 'tang002(2 星) 原点升级,您获得 商务奖 $2.00', 'tang002(2 Star) origin upgrade, you get Referral Bonus $2.00', null, '2017-09-07', '2017-09-07 19:51:39');
INSERT INTO `wgi_change_log` VALUES ('102', 'CB4278462', '1', '24', 'tang002', '77', 'tang008', '6.00', 'tang008(1 星) 注册,您获得 推荐奖 $6.00', 'tang008(1 Star) registered, you get Referral Bonus $6.00', null, '2017-09-07', '2017-09-07 19:54:08');
INSERT INTO `wgi_change_log` VALUES ('103', 'CB9011148', '2', '26', 'tang004', '77', 'tang008', '0.50', 'tang008(1 星) 注册,您获得 见点奖 $0.5', 'tang008(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-07', '2017-09-07 19:54:08');
INSERT INTO `wgi_change_log` VALUES ('104', 'CB6459228', '2', '24', 'tang002', '77', 'tang008', '0.50', 'tang008(1 星) 注册,您获得 见点奖 $0.5', 'tang008(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-07', '2017-09-07 19:54:08');
INSERT INTO `wgi_change_log` VALUES ('105', 'CB1894252', '2', '23', 'tang001', '77', 'tang008', '0.50', 'tang008(1 星) 注册,您获得 见点奖 $0.5', 'tang008(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-07', '2017-09-07 19:54:08');
INSERT INTO `wgi_change_log` VALUES ('106', 'CB1292180', '1', '23', 'tang001', '126', 'tang888', '5.00', 'tang888(1 星) 注册,您获得 推荐奖 $5.00', 'tang888(1 Star) registered, you get Referral Bonus $5.00', null, '2017-09-09', '2017-09-09 16:34:33');
INSERT INTO `wgi_change_log` VALUES ('107', 'CB9310727', '2', '23', 'tang001', '126', 'tang888', '0.50', 'tang888(1 星) 注册,您获得 见点奖 $0.5', 'tang888(1 Star) registered, you get Referral Bonus $0.5', null, '2017-09-09', '2017-09-09 16:34:33');
INSERT INTO `wgi_change_log` VALUES ('108', 'CB6474729', '3', '23', 'tang001', '126', 'tang888', '5.00', 'tang888(1 星) 注册,您获得 对碰奖 $5', 'tang888(1 Star) registered, you get Referral Bonus $5', null, '2017-09-09', '2017-09-09 16:34:33');

-- ----------------------------
-- Table structure for wgi_change_log_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_change_log_info`;
CREATE TABLE `wgi_change_log_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `touch_price` decimal(10,2) DEFAULT '0.00' COMMENT '对碰奖',
  `recom_price` decimal(10,2) DEFAULT '0.00' COMMENT '推荐奖',
  `dot_price` decimal(10,2) DEFAULT '0.00' COMMENT '见点奖',
  `leader_price` decimal(10,2) DEFAULT '0.00' COMMENT '领导奖',
  `buss_price` decimal(10,2) DEFAULT '0.00' COMMENT '电子币',
  `title` varchar(50) CHARACTER SET utf8 DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of wgi_change_log_info
-- ----------------------------
INSERT INTO `wgi_change_log_info` VALUES ('10', '23', 'tang001', '15.00', '40.00', '5.50', '0.10', '2.50', null, '2017-09-07', '2017-09-07 19:46:53');
INSERT INTO `wgi_change_log_info` VALUES ('11', '24', 'tang002', '5.00', '11.00', '1.50', '0.00', '0.00', null, '2017-09-07', '2017-09-07 19:48:27');
INSERT INTO `wgi_change_log_info` VALUES ('12', '25', 'tang003', '0.00', '0.00', '0.50', '0.00', '0.00', null, '2017-09-07', '2017-09-07 19:48:52');
INSERT INTO `wgi_change_log_info` VALUES ('13', '26', 'tang004', '0.00', '0.00', '0.50', '0.00', '0.00', null, '2017-09-07', '2017-09-07 19:54:08');
INSERT INTO `wgi_change_log_info` VALUES ('14', '23', 'tang001', '5.00', '5.00', '0.50', '0.00', '0.00', null, '2017-09-09', '2017-09-09 16:34:33');

-- ----------------------------
-- Table structure for wgi_config
-- ----------------------------
DROP TABLE IF EXISTS `wgi_config`;
CREATE TABLE `wgi_config` (
  `key` varchar(255) DEFAULT NULL COMMENT '键',
  `val` varchar(255) DEFAULT NULL COMMENT '值',
  `note` varchar(255) DEFAULT NULL COMMENT '说明'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='系统配置表';

-- ----------------------------
-- Records of wgi_config
-- ----------------------------
INSERT INTO `wgi_config` VALUES ('sell_stock_switch', '1', '卖出股份开关（1-开启，0-关闭）');
INSERT INTO `wgi_config` VALUES ('sell_stock_sxf_ratio', '0.1', '卖出股份手续费比例');
INSERT INTO `wgi_config` VALUES ('sell_stock_xjb_ratio', '0.6', '卖出股份转现金币比例');
INSERT INTO `wgi_config` VALUES ('sell_stock_dzb_ratio', '0.3', '卖出股份转电子币比例');
INSERT INTO `wgi_config` VALUES ('sell_stock_jf_ratio', '0.1', '卖出股份转积分比例');
INSERT INTO `wgi_config` VALUES ('buy_xjb_switch', '1', '现金币购买开关（1-开启，0-关闭）');
INSERT INTO `wgi_config` VALUES ('buy_xjb_ratio', '0.9', '现金币购买优惠');
INSERT INTO `wgi_config` VALUES ('sell_xjb_switch', '1', '现金币出售开关（1-开启，0-关闭）');
INSERT INTO `wgi_config` VALUES ('sell_xjb_ratio', '0.1', '现金币出售手续费');
INSERT INTO `wgi_config` VALUES ('jj_to_xjb_ratio', '0.8', '动态奖转现金币比例');
INSERT INTO `wgi_config` VALUES ('jj_to_zcb_ratio', '0.2', '动态奖转注册币比例');
INSERT INTO `wgi_config` VALUES ('full_stock_double', '1.5', '爆仓（用户持有的股份数量与投资额倍数）');
INSERT INTO `wgi_config` VALUES ('full_stock_sell_ratio', '0.8', '爆仓后自动卖出股份的比例');
INSERT INTO `wgi_config` VALUES ('pay_max_times', '24', '打款超时时间（小时）');
INSERT INTO `wgi_config` VALUES ('enter_max_times', '24', '收款超时时间（小时）');
INSERT INTO `wgi_config` VALUES ('usb_to_rmb_ratio', '6.5', '美元兑人民币的汇率');
INSERT INTO `wgi_config` VALUES ('split_stock_double', '2', '股份和股价拆分倍数');
INSERT INTO `wgi_config` VALUES ('again_invest_max_days', '7', '会员复投时间（天）');
INSERT INTO `wgi_config` VALUES ('b_to_xjb_ratio', '0.1', 'B钱包解冻转现金币比例');
INSERT INTO `wgi_config` VALUES ('start_stock_num', '-22', '原始股份数量');
INSERT INTO `wgi_config` VALUES ('day_reg_num', '300', '每天最大注册人数');

-- ----------------------------
-- Table structure for wgi_config_member_level
-- ----------------------------
DROP TABLE IF EXISTS `wgi_config_member_level`;
CREATE TABLE `wgi_config_member_level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL COMMENT '级别名称',
  `en_title` varchar(50) DEFAULT NULL COMMENT '级别名称--英文',
  `price` int(11) NOT NULL DEFAULT '0' COMMENT '投资金额 ($)',
  `matching_ratio` float(8,4) DEFAULT NULL COMMENT '波比率',
  `dot_ratio` float(8,4) DEFAULT NULL COMMENT '见点奖比例',
  `dot_layer` int(3) DEFAULT NULL COMMENT '见点奖层数',
  `recom_reward` float(8,4) DEFAULT NULL COMMENT '直推奖比例',
  `touch_reward` float(8,4) DEFAULT NULL COMMENT '对碰奖比例',
  `leader_reward` float(8,4) DEFAULT NULL COMMENT '管理奖比例',
  `leader_layer` int(3) DEFAULT NULL COMMENT '管理奖代数',
  `touch_day_max` int(10) DEFAULT NULL COMMENT '动态奖日封顶数',
  `share_holding_max` int(10) DEFAULT NULL COMMENT '账户持股最大值',
  `status_profit_max` int(10) NOT NULL COMMENT '静态收益最大值',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否开放(0-未开放，1-开放)',
  `delete` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否删除（0-不删除，1-删除）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COMMENT='会员级别参数设置';

-- ----------------------------
-- Records of wgi_config_member_level
-- ----------------------------
INSERT INTO `wgi_config_member_level` VALUES ('1', '1星', '1 Star', '100', '0.5000', '0.0050', '5', '0.0500', '0.0500', '0.0200', '1', '100', '150', '440', '1', '0');
INSERT INTO `wgi_config_member_level` VALUES ('2', '2星', '2 Star', '500', '0.5200', '0.0050', '7', '0.0600', '0.0600', '0.0200', '1', '500', '750', '2200', '1', '0');
INSERT INTO `wgi_config_member_level` VALUES ('3', '3星', '3 Star', '1000', '0.5400', '0.0050', '10', '0.0700', '0.0700', '0.0300', '2', '1000', '1500', '4400', '0', '0');
INSERT INTO `wgi_config_member_level` VALUES ('4', '4星', '4 Star', '3000', '0.5600', '0.0050', '13', '0.0800', '0.0800', '0.0300', '2', '3000', '4500', '13200', '0', '0');
INSERT INTO `wgi_config_member_level` VALUES ('5', '5星', '5 Star', '5000', '0.5800', '0.0050', '15', '0.0900', '0.0900', '0.0500', '3', '5000', '7500', '22000', '0', '0');
INSERT INTO `wgi_config_member_level` VALUES ('6', '6星', '6 Star', '10000', '0.6000', '0.0050', '20', '0.1000', '0.1000', '0.0500', '3', '10000', '15000', '44000', '0', '0');

-- ----------------------------
-- Table structure for wgi_delete
-- ----------------------------
DROP TABLE IF EXISTS `wgi_delete`;
CREATE TABLE `wgi_delete` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `delete_id` int(11) DEFAULT NULL,
  `delete_table` varchar(50) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(50) DEFAULT NULL,
  `delete_type` varchar(50) DEFAULT NULL,
  `delete_title` varchar(50) DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_delete
-- ----------------------------
INSERT INTO `wgi_delete` VALUES ('1', '10', 'Member', '1', 'admin', '会员', 'tang001', '2017-09-07 17:46:57');

-- ----------------------------
-- Table structure for wgi_digit_price
-- ----------------------------
DROP TABLE IF EXISTS `wgi_digit_price`;
CREATE TABLE `wgi_digit_price` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `price` decimal(10,2) DEFAULT '0.00',
  `date` date DEFAULT NULL,
  `number` float DEFAULT '0',
  `addtime` datetime DEFAULT NULL,
  `status` int(1) DEFAULT '0',
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_digit_price
-- ----------------------------
INSERT INTO `wgi_digit_price` VALUES ('17', '2.00', '2017-09-07', '0', '2017-09-07 17:44:46', '1', '0');

-- ----------------------------
-- Table structure for wgi_feedback_type
-- ----------------------------
DROP TABLE IF EXISTS `wgi_feedback_type`;
CREATE TABLE `wgi_feedback_type` (
  `id` smallint(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `problem_name` varchar(50) DEFAULT NULL COMMENT '问题名称',
  `en_problem_name` varchar(50) DEFAULT NULL COMMENT '问题名称英文',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_feedback_type
-- ----------------------------
INSERT INTO `wgi_feedback_type` VALUES ('1', '账号冻结', 'Bloqueo de cuenta');
INSERT INTO `wgi_feedback_type` VALUES ('2', '投诉他人违规', 'Denunciar la ilegalidad de otras personas');
INSERT INTO `wgi_feedback_type` VALUES ('3', '提现订单不匹配', 'El pedido para la extracción de dinero no es empar');
INSERT INTO `wgi_feedback_type` VALUES ('4', '买方拒绝付款', 'El comprador rechaza pagar');
INSERT INTO `wgi_feedback_type` VALUES ('5', '卖方不确认收款', 'El vendedor no confirma el recibo de pago');
INSERT INTO `wgi_feedback_type` VALUES ('6', '买方收款信息有误', 'Error con información de cobro del comprador');
INSERT INTO `wgi_feedback_type` VALUES ('7', '收不到短信', 'No puede recibir el mensaje');
INSERT INTO `wgi_feedback_type` VALUES ('8', '奖金计算错误', 'Error con la calculación de premio');
INSERT INTO `wgi_feedback_type` VALUES ('9', '更改个人信息', 'Modificación de información personal');
INSERT INTO `wgi_feedback_type` VALUES ('10', '其他问题', 'Otros problemas');

-- ----------------------------
-- Table structure for wgi_information
-- ----------------------------
DROP TABLE IF EXISTS `wgi_information`;
CREATE TABLE `wgi_information` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `member_id` int(11) unsigned DEFAULT NULL COMMENT '会员ID',
  `member_username` varchar(50) DEFAULT NULL COMMENT '会员账号',
  `member_telephone` varchar(50) DEFAULT NULL COMMENT '会员手机号码',
  `type` smallint(6) DEFAULT NULL COMMENT '类型',
  `picture` varchar(50) DEFAULT NULL COMMENT '图片',
  `content` text COMMENT '内容',
  `remark` text COMMENT '回复',
  `addtime` datetime DEFAULT NULL COMMENT '留言时间',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态（0-未处理，1-处理中，2-处理完成）',
  `delete` tinyint(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  `replaytime` datetime DEFAULT NULL COMMENT '回复时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_information
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_member
-- ----------------------------
DROP TABLE IF EXISTS `wgi_member`;
CREATE TABLE `wgi_member` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `p_id` int(11) unsigned DEFAULT '0' COMMENT '节点领导人ID',
  `p_username` varchar(50) DEFAULT NULL COMMENT '节点领导人账号',
  `username` varchar(50) DEFAULT NULL COMMENT '会员账号',
  `userpass` char(32) DEFAULT NULL COMMENT '登陆密码',
  `paypass` char(32) DEFAULT NULL COMMENT '支付密码',
  `dgcpass` char(32) DEFAULT NULL COMMENT '二级密码',
  `package_type` tinyint(1) DEFAULT '0' COMMENT '会员星级',
  `member_type` tinyint(1) DEFAULT '0' COMMENT '会员类型（0-A类用户，1-B类用户）',
  `price_level` int(11) DEFAULT NULL,
  `surname` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL COMMENT '会员姓名',
  `china_card` varchar(50) DEFAULT NULL COMMENT '身份证号码',
  `extend_china_card` varchar(50) DEFAULT NULL COMMENT '其他证件号码',
  `country` varchar(50) DEFAULT NULL COMMENT '所在国家',
  `telephone` varchar(50) DEFAULT NULL COMMENT '手机号码',
  `weixin` varchar(50) DEFAULT NULL COMMENT '微信号',
  `zhifubao` varchar(50) DEFAULT NULL COMMENT '支付宝号',
  `bank` varchar(255) DEFAULT NULL COMMENT '开户银行',
  `bank_account` varchar(255) DEFAULT NULL COMMENT '银行卡号',
  `bank_account_name` varchar(255) DEFAULT NULL COMMENT '银行卡户名',
  `email` varchar(255) DEFAULT NULL COMMENT '邮箱地址',
  `area` varchar(255) DEFAULT NULL COMMENT '所在地区',
  `address` varchar(255) DEFAULT NULL COMMENT '联系地址',
  `birthday` date DEFAULT NULL COMMENT '生日',
  `credit` tinyint(1) DEFAULT '5' COMMENT '信用分数',
  `passport` varchar(255) DEFAULT NULL,
  `sex` tinyint(1) DEFAULT '0' COMMENT '性别（0-男，1-女）',
  `picture` varchar(255) DEFAULT NULL COMMENT '头像',
  `pay_picture` varchar(255) DEFAULT NULL COMMENT '支付凭证图片',
  `remark` text COMMENT '备注说明',
  `bitcoin` varchar(50) DEFAULT NULL COMMENT '虚拟货币地址',
  `paypal` varchar(50) DEFAULT NULL COMMENT 'paypal账号',
  `bwstate` tinyint(1) DEFAULT '0' COMMENT 'B钱包开通状态 （0-关闭，1-开通）',
  `r_id` int(11) DEFAULT '0' COMMENT '直推会员ID',
  `r_username` varchar(50) DEFAULT NULL COMMENT '直推会员账号',
  `t_id` int(11) DEFAULT '0' COMMENT '顶级会员ID',
  `t_username` varchar(50) DEFAULT '' COMMENT '顶级会员账号',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态（0-冻结，1-未冻结）',
  `status_login` tinyint(1) DEFAULT '0',
  `position` tinyint(1) DEFAULT '0' COMMENT '所在区（0-左区，1-右区）',
  `adddate` date DEFAULT NULL COMMENT '添加日期',
  `addtime` datetime DEFAULT NULL COMMENT '添加时间',
  `delete` tinyint(1) unsigned DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  `p_str` text COMMENT '所有上级ID',
  `topclass` int(10) DEFAULT '1' COMMENT '所在层级',
  `is_out` int(1) DEFAULT '0' COMMENT '出局状态0-未出局1-已出局',
  `out_time` datetime DEFAULT NULL COMMENT '出局时间',
  `split_num` int(2) DEFAULT '0' COMMENT '经历的拆分次数',
  `is_boom` int(1) DEFAULT '0' COMMENT '0-未爆仓 1-爆仓',
  `is_buss` tinyint(1) DEFAULT '0' COMMENT '商务中心 0-不是 1-是',
  `buss_id` int(10) DEFAULT '0' COMMENT '商务ID',
  `buss_username` varchar(50) DEFAULT '' COMMENT '商务姓名',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COMMENT='会员';

-- ----------------------------
-- Records of wgi_member
-- ----------------------------
INSERT INTO `wgi_member` VALUES ('23', '0', null, 'tang001', 'b70a08d1e6cf8a371a9bf04faff7fd76', '111111', null, '1', '0', null, null, '', '', '', null, '18373954288', '11', '11', '111', '111', '11', null, null, null, null, '4', null, '1', '', null, '', '11', null, '0', '0', null, '0', '', '1', '1', '0', '2017-09-07', '2017-09-07 19:45:33', '0', null, '1', '0', '2017-09-07 20:08:35', '5', '0', '1', '0', '');
INSERT INTO `wgi_member` VALUES ('24', '23', 'tang001', 'tang002', '05e8c7bfcd2a195603e7048f64c91dc5', '18373954288', null, '2', '0', null, null, null, null, null, null, '18373954288', null, null, null, null, null, null, null, null, null, '4', null, '0', null, null, null, null, null, '0', '23', 'tang001', '23', 'tang001', '1', '1', '0', '2017-09-07', '2017-09-07 19:46:53', '0', ',23,', '2', '0', '2017-09-07 20:43:08', '5', '0', '0', '23', 'tang001');
INSERT INTO `wgi_member` VALUES ('25', '23', 'tang001', 'tang003', 'a19eb48faef02d2dbffabb70c24adb76', '18373954288', null, '1', '0', null, null, null, null, null, null, '18373954288', null, null, null, null, null, null, null, null, null, '5', null, '0', null, null, null, null, null, '0', '23', 'tang001', '23', 'tang001', '1', '1', '1', '2017-09-07', '2017-09-07 19:47:42', '0', ',23,', '2', '1', '2017-09-07 20:35:42', '5', '0', '0', '0', '');
INSERT INTO `wgi_member` VALUES ('26', '24', 'tang002', 'tang004', '3b7072d111cdb14662b035168044cd34', '13762096614', null, '1', '0', null, null, null, null, null, null, '13762096614', null, null, null, null, null, null, null, null, null, '5', null, '0', null, null, null, null, null, '0', '23', 'tang001', '23', 'tang001', '1', '1', '0', '2017-09-07', '2017-09-07 19:48:27', '0', ',23,24,', '3', '1', '2017-09-07 20:35:42', '5', '0', '0', '0', '');
INSERT INTO `wgi_member` VALUES ('27', '25', 'tang003', 'tang005', '4ae683fff43e4fb7f6a5d9409d142b94', '18673112520', null, '1', '0', null, null, null, null, null, null, '18673112520', null, null, null, null, null, null, null, null, null, '5', null, '0', null, null, null, null, null, '0', '23', 'tang001', '23', 'tang001', '1', '1', '0', '2017-09-07', '2017-09-07 19:48:52', '0', ',23,25,', '3', '1', '2017-09-07 20:35:42', '5', '0', '0', '0', '');
INSERT INTO `wgi_member` VALUES ('28', '24', 'tang002', 'tang006', '11d27eee2c88031cc56af88a60838fef', '18373954281', null, '1', '0', null, null, null, null, null, null, '18373954281', null, null, null, null, null, null, null, null, null, '5', null, '0', null, null, null, null, null, '0', '24', 'tang002', '23', 'tang001', '1', '1', '1', '2017-09-07', '2017-09-07 19:51:03', '0', ',23,24,', '3', '1', '2017-09-07 20:35:42', '5', '0', '0', '0', '');
INSERT INTO `wgi_member` VALUES ('29', '26', 'tang004', 'tang008', 'f8eb214722c0676ecd5a88f046513716', '18373954388', null, '1', '0', null, null, null, null, null, null, '18373954388', null, null, null, null, null, null, null, null, null, '5', null, '0', null, null, null, null, null, '0', '24', 'tang002', '23', 'tang001', '1', '1', '0', '2017-09-07', '2017-09-07 19:54:08', '0', ',23,24,26,', '4', '1', '2017-09-07 20:35:42', '5', '0', '0', '0', '');
INSERT INTO `wgi_member` VALUES ('30', '27', 'tang005', 'tang888', '96e79218965eb72c92a549dd5a330112', '18608409053', null, '1', '0', null, null, null, null, null, null, '18608409053', null, null, null, null, null, null, null, null, null, '5', null, '0', null, null, null, null, null, '0', '23', 'tang001', '23', 'tang001', '1', '1', '0', '2017-09-09', '2017-09-09 16:34:33', '0', ',23,25,27,', '4', '0', '2017-09-09 16:34:33', '0', '0', '0', '0', '');

-- ----------------------------
-- Table structure for wgi_member_level_log
-- ----------------------------
DROP TABLE IF EXISTS `wgi_member_level_log`;
CREATE TABLE `wgi_member_level_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) DEFAULT NULL COMMENT '单号编码',
  `member_id` int(11) DEFAULT NULL COMMENT '会员ID',
  `member_username` varchar(50) DEFAULT NULL COMMENT '会员账号名称',
  `old_level` varchar(50) DEFAULT NULL COMMENT '升级前星级',
  `en_old_level` varchar(50) DEFAULT NULL COMMENT '升级前星级英文',
  `new_level` varchar(50) DEFAULT NULL COMMENT '升级后星级',
  `en_new_level` varchar(50) DEFAULT NULL COMMENT '升级后星级英文',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '补单金额',
  `addtime` datetime DEFAULT NULL COMMENT '添加时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_member_level_log
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_member_login_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_member_login_info`;
CREATE TABLE `wgi_member_login_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `member_id` int(11) unsigned DEFAULT NULL COMMENT '会员ID',
  `member_username` varchar(50) DEFAULT NULL COMMENT '会员账号',
  `login_ip` varchar(50) DEFAULT NULL COMMENT '登陆IP',
  `login_time` datetime DEFAULT NULL COMMENT '登陆时间',
  `delete` tinyint(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8 COMMENT='会员登陆记录';

-- ----------------------------
-- Records of wgi_member_login_info
-- ----------------------------
INSERT INTO `wgi_member_login_info` VALUES ('39', '23', 'tang001', '113.246.107.225', '2017-09-07 19:46:28', '0');
INSERT INTO `wgi_member_login_info` VALUES ('40', '24', 'tang002', '113.246.107.225', '2017-09-07 19:50:01', '0');
INSERT INTO `wgi_member_login_info` VALUES ('41', '23', 'tang001', '113.246.107.225', '2017-09-07 20:13:33', '0');
INSERT INTO `wgi_member_login_info` VALUES ('42', '24', 'tang002', '113.246.107.225', '2017-09-07 20:28:14', '0');
INSERT INTO `wgi_member_login_info` VALUES ('43', '23', 'tang001', '113.246.107.225', '2017-09-07 20:39:41', '0');
INSERT INTO `wgi_member_login_info` VALUES ('44', '23', 'tang001', '113.246.107.225', '2017-09-07 20:43:54', '0');
INSERT INTO `wgi_member_login_info` VALUES ('45', '23', 'tang001', '113.246.107.225', '2017-09-07 20:52:40', '0');
INSERT INTO `wgi_member_login_info` VALUES ('46', '23', 'tang001', '113.246.107.225', '2017-09-08 10:17:21', '0');
INSERT INTO `wgi_member_login_info` VALUES ('47', '23', 'tang001', '118.206.241.206', '2017-09-09 16:33:10', '0');
INSERT INTO `wgi_member_login_info` VALUES ('48', '30', 'tang888', '118.206.241.206', '2017-09-09 16:34:55', '0');
INSERT INTO `wgi_member_login_info` VALUES ('49', '30', 'tang888', '118.206.241.206', '2017-09-09 16:51:15', '0');
INSERT INTO `wgi_member_login_info` VALUES ('50', '23', 'tang001', '113.246.154.126', '2017-09-09 16:52:15', '0');
INSERT INTO `wgi_member_login_info` VALUES ('51', '23', 'tang001', '113.246.154.43', '2017-09-11 10:24:48', '0');

-- ----------------------------
-- Table structure for wgi_member_share_count
-- ----------------------------
DROP TABLE IF EXISTS `wgi_member_share_count`;
CREATE TABLE `wgi_member_share_count` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户股份池',
  `member_id` int(11) DEFAULT NULL COMMENT '用户id',
  `type` int(1) DEFAULT '0' COMMENT '0-转入1-卖出',
  `title` varchar(255) DEFAULT NULL,
  `title_en` varchar(255) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL COMMENT '变更数量',
  `new_shares` int(11) DEFAULT '0' COMMENT '用户股份池剩余股份',
  `old_shares` int(11) DEFAULT '0' COMMENT '变更之前数量',
  `delete` int(11) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_member_share_count
-- ----------------------------
INSERT INTO `wgi_member_share_count` VALUES ('39', null, '0', null, null, null, '299975', '0', '0');
INSERT INTO `wgi_member_share_count` VALUES ('54', '24', '0', null, null, '25', '299950', '299975', '0');
INSERT INTO `wgi_member_share_count` VALUES ('55', '25', '0', null, null, '25', '299925', '299950', '0');
INSERT INTO `wgi_member_share_count` VALUES ('56', '26', '0', null, null, '25', '299900', '299925', '0');
INSERT INTO `wgi_member_share_count` VALUES ('57', '27', '0', null, null, '25', '299875', '299900', '0');
INSERT INTO `wgi_member_share_count` VALUES ('58', '28', '0', null, null, '25', '299850', '299875', '0');
INSERT INTO `wgi_member_share_count` VALUES ('59', '24', '0', null, null, '104', '299746', '299850', '0');
INSERT INTO `wgi_member_share_count` VALUES ('60', '29', '0', null, null, '25', '299721', '299746', '0');
INSERT INTO `wgi_member_share_count` VALUES ('61', '23', '0', null, null, '20', '299741', '299721', '0');
INSERT INTO `wgi_member_share_count` VALUES ('62', '1', '0', '拆分后配股', null, '299741', '599482', '299741', '0');
INSERT INTO `wgi_member_share_count` VALUES ('63', '1', '0', '拆分后配股', null, '599482', '1198964', '599482', '0');
INSERT INTO `wgi_member_share_count` VALUES ('64', '1', '0', '拆分后配股', null, '1198964', '2397928', '1198964', '0');
INSERT INTO `wgi_member_share_count` VALUES ('65', '1', '0', '拆分后配股', null, '2397928', '4795856', '2397928', '0');
INSERT INTO `wgi_member_share_count` VALUES ('66', '1', '0', '拆分后配股', null, '4795856', '9591712', '4795856', '0');
INSERT INTO `wgi_member_share_count` VALUES ('67', '23', '0', null, null, '165', '9591877', '9591712', '0');
INSERT INTO `wgi_member_share_count` VALUES ('68', '23', '0', 'tang001爆仓自动卖股', 'Auto sell', '40', '9591752', null, '0');
INSERT INTO `wgi_member_share_count` VALUES ('69', '24', '0', 'tang002爆仓自动卖股', 'Burst warehouse automatically sell shares', '2200', '9593952', null, '0');
INSERT INTO `wgi_member_share_count` VALUES ('70', '24', '0', 'tang002爆仓多余股份', 'Burst warehouse excess shares', '1928', '9595880', '9593952', '0');
INSERT INTO `wgi_member_share_count` VALUES ('71', '25', '0', 'tang003爆仓自动卖股', 'Burst warehouse automatically sell shares', '440', '9596320', null, '0');
INSERT INTO `wgi_member_share_count` VALUES ('72', '25', '0', 'tang003爆仓多余股份', 'Burst warehouse excess shares', '360', '9596680', '9596320', '0');
INSERT INTO `wgi_member_share_count` VALUES ('73', '26', '0', 'tang004爆仓自动卖股', 'Burst warehouse automatically sell shares', '440', '9597120', null, '0');
INSERT INTO `wgi_member_share_count` VALUES ('74', '26', '0', 'tang004爆仓多余股份', 'Burst warehouse excess shares', '360', '9597480', '9597120', '0');
INSERT INTO `wgi_member_share_count` VALUES ('75', '27', '0', 'tang005爆仓自动卖股', 'Burst warehouse automatically sell shares', '440', '9597920', null, '0');
INSERT INTO `wgi_member_share_count` VALUES ('76', '27', '0', 'tang005爆仓多余股份', 'Burst warehouse excess shares', '360', '9598280', '9597920', '0');
INSERT INTO `wgi_member_share_count` VALUES ('77', '28', '0', 'tang006爆仓自动卖股', 'Burst warehouse automatically sell shares', '440', '9598720', null, '0');
INSERT INTO `wgi_member_share_count` VALUES ('78', '28', '0', 'tang006爆仓多余股份', 'Burst warehouse excess shares', '360', '9599080', '9598720', '0');
INSERT INTO `wgi_member_share_count` VALUES ('79', '29', '0', 'tang008爆仓自动卖股', 'Burst warehouse automatically sell shares', '440', '9599520', null, '0');
INSERT INTO `wgi_member_share_count` VALUES ('80', '29', '0', 'tang008爆仓多余股份', 'Burst warehouse excess shares', '360', '9599880', '9599520', '0');
INSERT INTO `wgi_member_share_count` VALUES ('81', '23', '0', 'tang001爆仓自动卖股', 'Auto sell', '173', '9600053', null, '0');
INSERT INTO `wgi_member_share_count` VALUES ('82', '24', '1', 'tang002复投', null, '130', '9599923', '9600053', '0');
INSERT INTO `wgi_member_share_count` VALUES ('83', '30', '0', null, null, '0', '9599923', '9599923', '0');

-- ----------------------------
-- Table structure for wgi_memberinfo
-- ----------------------------
DROP TABLE IF EXISTS `wgi_memberinfo`;
CREATE TABLE `wgi_memberinfo` (
  `id` int(11) unsigned NOT NULL COMMENT '会员ID',
  `username` varchar(50) DEFAULT '' COMMENT '会员账号',
  `cashb` decimal(18,2) DEFAULT '0.00' COMMENT '现金币',
  `regb` decimal(18,2) DEFAULT '0.00' COMMENT '注册币',
  `jfb` decimal(18,2) DEFAULT '0.00' COMMENT '积分',
  `bwallet` decimal(18,2) DEFAULT '0.00' COMMENT 'B钱包',
  `gfnum` int(11) DEFAULT '0' COMMENT '股份总数',
  `summoney_total` decimal(18,2) DEFAULT '0.00' COMMENT '投资总金额',
  `touchmoney` decimal(18,2) DEFAULT '0.00' COMMENT '已对碰金额',
  `summoney_l` decimal(18,2) DEFAULT '0.00' COMMENT '左区团队投资金额',
  `summoney_r` decimal(18,2) DEFAULT '0.00' COMMENT '右区团队投资金额',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_memberinfo
-- ----------------------------
INSERT INTO `wgi_memberinfo` VALUES ('23', 'tang001', '10121.00', '9999513.12', '41.86', '0.00', '43', '0.00', '300.00', '500.00', '0.00');
INSERT INTO `wgi_memberinfo` VALUES ('24', 'tang002', '3778.00', '8903.50', '396.00', '0.00', '130', '500.00', '100.00', '100.00', '0.00');
INSERT INTO `wgi_memberinfo` VALUES ('25', 'tang003', '713.20', '0.10', '79.20', '0.00', '0', '100.00', '0.00', '200.00', '0.00');
INSERT INTO `wgi_memberinfo` VALUES ('26', 'tang004', '713.20', '0.10', '79.20', '0.00', '0', '100.00', '0.00', '100.00', '0.00');
INSERT INTO `wgi_memberinfo` VALUES ('27', 'tang005', '712.80', '0.00', '79.20', '0.00', '0', '100.00', '0.00', '100.00', '0.00');
INSERT INTO `wgi_memberinfo` VALUES ('28', 'tang006', '712.80', '0.00', '79.20', '0.00', '0', '100.00', '0.00', '0.00', '0.00');
INSERT INTO `wgi_memberinfo` VALUES ('29', 'tang008', '712.80', '0.00', '79.20', '0.00', '0', '100.00', '0.00', '0.00', '0.00');
INSERT INTO `wgi_memberinfo` VALUES ('30', 'tang888', '0.00', '0.00', '0.00', '0.00', '0', '100.00', '0.00', '0.00', '0.00');

-- ----------------------------
-- Table structure for wgi_news
-- ----------------------------
DROP TABLE IF EXISTS `wgi_news`;
CREATE TABLE `wgi_news` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `title` varchar(255) DEFAULT NULL COMMENT '中文标题',
  `title_en` varchar(255) DEFAULT NULL COMMENT '英文标题',
  `content` text COMMENT '中文内容',
  `content_en` text COMMENT '英文内容',
  `addtime` datetime DEFAULT NULL COMMENT '添加时间',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态（0-隐藏，1-显示）',
  `delete` tinyint(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='新闻';

-- ----------------------------
-- Records of wgi_news
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_node
-- ----------------------------
DROP TABLE IF EXISTS `wgi_node`;
CREATE TABLE `wgi_node` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `name` varchar(20) NOT NULL COMMENT '节点名',
  `title` varchar(50) DEFAULT NULL COMMENT '节点说明',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态（0-关闭，1-开启）',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  `sort` smallint(6) unsigned DEFAULT NULL COMMENT '排序',
  `pid` smallint(6) unsigned NOT NULL COMMENT '父节点ID',
  `level` tinyint(1) unsigned NOT NULL COMMENT '层级(1-模块，2-控制器，3-方法）',
  PRIMARY KEY (`id`),
  KEY `level` (`level`),
  KEY `pid` (`pid`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=48 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_node
-- ----------------------------
INSERT INTO `wgi_node` VALUES ('1', 'Home', '系统管理', '1', null, '1', '0', '1');
INSERT INTO `wgi_node` VALUES ('39', 'Config', '系统管理', '1', null, '11', '1', '2');
INSERT INTO `wgi_node` VALUES ('46', 'Rbac', '权限管理', '1', null, '81', '1', '2');
INSERT INTO `wgi_node` VALUES ('45', 'Trade', '交易管理', '1', null, '71', '1', '2');
INSERT INTO `wgi_node` VALUES ('40', 'Member', '会员管理', '1', null, '21', '1', '2');
INSERT INTO `wgi_node` VALUES ('41', 'Stock', '股份管理', '1', null, '31', '1', '2');
INSERT INTO `wgi_node` VALUES ('42', 'News', '新闻管理', '1', null, '41', '1', '2');
INSERT INTO `wgi_node` VALUES ('43', 'Information', '留言管理', '1', null, '51', '1', '2');
INSERT INTO `wgi_node` VALUES ('44', 'Wallet', '钱包管理', '1', null, '61', '1', '2');
INSERT INTO `wgi_node` VALUES ('47', 'system', '系统公共设置', '1', null, '1', '39', '3');

-- ----------------------------
-- Table structure for wgi_price_b
-- ----------------------------
DROP TABLE IF EXISTS `wgi_price_b`;
CREATE TABLE `wgi_price_b` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `member_id` int(11) DEFAULT NULL COMMENT '会员ID',
  `member_username` varchar(50) DEFAULT NULL COMMENT '会员账号',
  `title` varchar(255) DEFAULT NULL COMMENT '交易标题-中文',
  `title_en` varchar(255) DEFAULT NULL COMMENT '交易标题-英文',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注说明',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '交易金额数量',
  `admin_id` int(11) DEFAULT NULL COMMENT '管理员ID',
  `adddate` date DEFAULT NULL COMMENT '交易日期',
  `addtime` datetime DEFAULT NULL COMMENT '交易时间',
  `delete` tinyint(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  `type` tinyint(1) DEFAULT '0' COMMENT '0-解冻 1-充值',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COMMENT='B钱包解冻记录';

-- ----------------------------
-- Records of wgi_price_b
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_price_dz
-- ----------------------------
DROP TABLE IF EXISTS `wgi_price_dz`;
CREATE TABLE `wgi_price_dz` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT '0' COMMENT '1-配股2-复投3-回购4-注册',
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `order_id` varchar(100) DEFAULT NULL COMMENT '订单ID',
  `title` varchar(255) DEFAULT NULL,
  `title_en` varchar(255) DEFAULT NULL,
  `share_price` decimal(10,2) DEFAULT NULL COMMENT '股价',
  `share_num` int(11) DEFAULT NULL COMMENT '配股数量',
  `remark` varchar(255) DEFAULT NULL,
  `new_price` decimal(10,2) DEFAULT '0.00',
  `old_price` decimal(10,2) DEFAULT '0.00',
  `price` decimal(10,2) DEFAULT '0.00',
  `addtime` datetime DEFAULT NULL,
  `delete` int(1) DEFAULT '0',
  `queue_price` decimal(10,2) DEFAULT NULL COMMENT '补贴',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_price_dz
-- ----------------------------
INSERT INTO `wgi_price_dz` VALUES ('65', '4', '23', 'tang001', null, '新用户金额转化为电子币', 'The amount of new users is converted into electronic currency', null, null, null, '50.00', '0.00', '50.00', '2017-09-07 19:45:59', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('66', '1', '23', 'tang001', null, '后台配股', 'pg', null, null, null, '0.00', '0.00', '50.00', '2017-09-07 19:45:59', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('67', '4', '24', 'tang002', null, '新用户金额转化为电子币', 'The amount of new users is converted into electronic currency', null, null, null, '50.00', '0.00', '50.00', '2017-09-07 19:46:53', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('68', '1', '24', 'tang002', null, '配股', 'pg', null, null, null, '0.00', '0.00', '50.00', '2017-09-07 19:46:53', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('69', '4', '25', 'tang003', null, '新用户金额转化为电子币', 'The amount of new users is converted into electronic currency', null, null, null, '50.00', '0.00', '50.00', '2017-09-07 19:47:42', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('70', '1', '25', 'tang003', null, '配股', 'pg', null, null, null, '0.00', '0.00', '50.00', '2017-09-07 19:47:42', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('71', '4', '26', 'tang004', null, '新用户金额转化为电子币', 'The amount of new users is converted into electronic currency', null, null, null, '50.00', '0.00', '50.00', '2017-09-07 19:48:27', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('72', '1', '26', 'tang004', null, '配股', 'pg', null, null, null, '0.00', '0.00', '50.00', '2017-09-07 19:48:27', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('73', '4', '27', 'tang005', null, '新用户金额转化为电子币', 'The amount of new users is converted into electronic currency', null, null, null, '50.00', '0.00', '50.00', '2017-09-07 19:48:52', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('74', '1', '27', 'tang005', null, '配股', 'pg', null, null, null, '0.00', '0.00', '50.00', '2017-09-07 19:48:52', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('75', '4', '28', 'tang006', null, '新用户金额转化为电子币', 'The amount of new users is converted into electronic currency', null, null, null, '50.00', '0.00', '50.00', '2017-09-07 19:51:03', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('76', '1', '28', 'tang006', null, '配股', 'pg', null, null, null, '0.00', '0.00', '50.00', '2017-09-07 19:51:03', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('77', '4', '24', 'tang002', null, '原点升级金额转化为电子币', 'The origin upgrade amount is converted into electronic currency', null, null, null, '208.00', '0.00', '208.00', '2017-09-07 19:51:39', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('78', '1', '24', 'tang002', null, '配股', 'pg', null, null, null, '0.00', '0.00', '208.00', '2017-09-07 19:51:39', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('79', '4', '29', 'tang008', null, '新用户金额转化为电子币', 'The amount of new users is converted into electronic currency', null, null, null, '50.00', '0.00', '50.00', '2017-09-07 19:54:08', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('80', '1', '29', 'tang008', null, '配股', 'pg', null, null, null, '0.00', '0.00', '50.00', '2017-09-07 19:54:08', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('81', '3', '23', 'tang001', 'WGI23992646', '股份回购转电子币', 'hgzdzb', '2.00', '3', null, '0.00', '0.00', '5.40', '2017-09-07 19:57:40', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('82', '3', '23', 'tang001', 'WGI23415960', '股份回购转电子币', 'Stock repurchase', '2.00', '22', null, '0.00', '0.00', '44.55', '2017-09-07 20:35:42', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('83', '2', '24', 'tang002', null, '复投', 'Reinvested', '2.00', '130', '复投', '260.00', '0.00', '260.00', '2017-09-07 20:43:08', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('84', '1', '24', 'tang002', null, '复投配股', 'Re-allocation of shares', '2.00', '130', '复投', '0.00', '260.00', '260.00', '2017-09-07 20:43:08', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('85', '4', '30', 'tang888', null, '新用户金额转化为电子币', 'The amount of new users is converted into electronic currency', null, null, null, '50.00', '0.00', '50.00', '2017-09-09 16:34:33', '0', null);
INSERT INTO `wgi_price_dz` VALUES ('86', '1', '30', 'tang888', null, '配股', 'pg', null, null, null, '0.00', '0.00', '50.00', '2017-09-09 16:34:33', '0', null);

-- ----------------------------
-- Table structure for wgi_price_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_price_info`;
CREATE TABLE `wgi_price_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `type` tinyint(1) DEFAULT '0' COMMENT '交易类型（1-充值，2-消费，3-升级，4-转出，5-转入）',
  `member_id` int(11) DEFAULT NULL COMMENT '会员ID',
  `member_username` varchar(50) DEFAULT NULL COMMENT '会员账号',
  `order_id` varchar(50) DEFAULT NULL COMMENT '订单编号',
  `title` varchar(255) DEFAULT NULL COMMENT '交易标题-中文',
  `title_en` varchar(255) DEFAULT NULL COMMENT '交易标题-英文',
  `title_sp` varchar(255) DEFAULT NULL COMMENT '交易标题-西班牙文',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注说明',
  `new_price` decimal(10,2) DEFAULT '0.00' COMMENT '注册币钱包交易后的金额数量',
  `old_price` decimal(10,2) DEFAULT '0.00' COMMENT '注册币钱包交易前的金额数量',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '交易金额数量',
  `admin_id` int(11) DEFAULT NULL COMMENT '管理员ID',
  `adddate` date DEFAULT NULL COMMENT '交易日期',
  `addtime` datetime DEFAULT NULL COMMENT '交易时间',
  `delete` tinyint(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8 COMMENT='注册币交易记录';

-- ----------------------------
-- Records of wgi_price_info
-- ----------------------------
INSERT INTO `wgi_price_info` VALUES ('97', '1', '23', 'tang001', 'RC1508837', '注册币充值', 'Registered currency recharge', null, null, '10000000.00', '0.00', '10000000.00', '1', '2017-09-07', '2017-09-07 19:46:14', '0');
INSERT INTO `wgi_price_info` VALUES ('98', '2', '23', 'tang001', null, 'tang002 注册账号支出', 'tang002 Register', null, null, '9999900.00', '10000000.00', '100.00', null, '2017-09-07', '2017-09-07 19:46:53', '0');
INSERT INTO `wgi_price_info` VALUES ('99', '5', '23', 'tang001', null, 'tang002 注册,推荐奖的20%转为注册币', 'tang002 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9999901.00', '9999900.00', '1.00', null, '2017-09-07', '2017-09-07 19:46:53', '0');
INSERT INTO `wgi_price_info` VALUES ('100', '5', '23', 'tang001', null, 'tang002 注册,见点奖的20%转为注册币', 'tang002 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9999901.10', '9999901.00', '0.10', null, '2017-09-07', '2017-09-07 19:46:53', '0');
INSERT INTO `wgi_price_info` VALUES ('101', '2', '23', 'tang001', null, 'tang003 注册账号支出', 'tang003 Register', null, null, '9999801.10', '9999901.10', '100.00', null, '2017-09-07', '2017-09-07 19:47:42', '0');
INSERT INTO `wgi_price_info` VALUES ('102', '5', '23', 'tang001', null, 'tang003 注册,推荐奖的20%转为注册币', 'tang003 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9999802.10', '9999801.10', '1.00', null, '2017-09-07', '2017-09-07 19:47:42', '0');
INSERT INTO `wgi_price_info` VALUES ('103', '5', '23', 'tang001', null, 'tang003 注册,见点奖的20%转为注册币', 'tang003 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9999802.20', '9999802.10', '0.10', null, '2017-09-07', '2017-09-07 19:47:42', '0');
INSERT INTO `wgi_price_info` VALUES ('104', '5', '23', 'tang001', null, 'tang003 注册,对碰奖的20%转为注册币', 'tang003 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9999803.20', '9999802.20', '1.00', null, '2017-09-07', '2017-09-07 19:47:42', '0');
INSERT INTO `wgi_price_info` VALUES ('105', '2', '23', 'tang001', null, 'tang004 注册账号支出', 'tang004 Register', null, null, '9999703.20', '9999803.20', '100.00', null, '2017-09-07', '2017-09-07 19:48:27', '0');
INSERT INTO `wgi_price_info` VALUES ('106', '5', '23', 'tang001', null, 'tang004 注册,推荐奖的20%转为注册币', 'tang004 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9999704.20', '9999703.20', '1.00', null, '2017-09-07', '2017-09-07 19:48:27', '0');
INSERT INTO `wgi_price_info` VALUES ('107', '5', '24', 'tang002', null, 'tang004 注册,见点奖的20%转为注册币', 'tang004 registered, Referral Bonus20.%transfered into Register Coin', null, null, '0.10', '0.00', '0.10', null, '2017-09-07', '2017-09-07 19:48:27', '0');
INSERT INTO `wgi_price_info` VALUES ('108', '5', '23', 'tang001', null, 'tang004 注册,见点奖的20%转为注册币', 'tang004 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9999704.30', '9999704.20', '0.10', null, '2017-09-07', '2017-09-07 19:48:27', '0');
INSERT INTO `wgi_price_info` VALUES ('109', '2', '23', 'tang001', null, 'tang005 注册账号支出', 'tang005 Register', null, null, '9999604.30', '9999704.30', '100.00', null, '2017-09-07', '2017-09-07 19:48:52', '0');
INSERT INTO `wgi_price_info` VALUES ('110', '5', '23', 'tang001', null, 'tang005 注册,推荐奖的20%转为注册币', 'tang005 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9999605.30', '9999604.30', '1.00', null, '2017-09-07', '2017-09-07 19:48:52', '0');
INSERT INTO `wgi_price_info` VALUES ('111', '5', '25', 'tang003', null, 'tang005 注册,见点奖的20%转为注册币', 'tang005 registered, Referral Bonus20.%transfered into Register Coin', null, null, '0.10', '0.00', '0.10', null, '2017-09-07', '2017-09-07 19:48:52', '0');
INSERT INTO `wgi_price_info` VALUES ('112', '5', '23', 'tang001', null, 'tang005 注册,见点奖的20%转为注册币', 'tang005 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9999605.40', '9999605.30', '0.10', null, '2017-09-07', '2017-09-07 19:48:52', '0');
INSERT INTO `wgi_price_info` VALUES ('113', '5', '23', 'tang001', null, 'tang005 注册,对碰奖的20%转为注册币', 'tang005 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9999606.40', '9999605.40', '1.00', null, '2017-09-07', '2017-09-07 19:48:52', '0');
INSERT INTO `wgi_price_info` VALUES ('114', '1', '24', 'tang002', 'RC9794894', '注册币充值', 'Registered currency recharge', null, null, '10000.10', '0.10', '10000.00', '1', '2017-09-07', '2017-09-07 19:50:30', '0');
INSERT INTO `wgi_price_info` VALUES ('115', '2', '24', 'tang002', null, 'tang006 注册账号支出', 'tang006 Register', null, null, '9900.10', '10000.10', '100.00', null, '2017-09-07', '2017-09-07 19:51:03', '0');
INSERT INTO `wgi_price_info` VALUES ('116', '5', '24', 'tang002', null, 'tang006 注册,推荐奖的20%转为注册币', 'tang006 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9901.10', '9900.10', '1.00', null, '2017-09-07', '2017-09-07 19:51:03', '0');
INSERT INTO `wgi_price_info` VALUES ('117', '5', '24', 'tang002', null, 'tang006 注册,见点奖的20%转为注册币', 'tang006 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9901.20', '9901.10', '0.10', null, '2017-09-07', '2017-09-07 19:51:03', '0');
INSERT INTO `wgi_price_info` VALUES ('118', '5', '23', 'tang001', null, 'tang006 注册,见点奖的20%转为注册币', 'tang006 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9999606.50', '9999606.40', '0.10', null, '2017-09-07', '2017-09-07 19:51:03', '0');
INSERT INTO `wgi_price_info` VALUES ('119', '5', '24', 'tang002', null, 'tang006 注册,对碰奖的20%转为注册币', 'tang006 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9902.20', '9901.20', '1.00', null, '2017-09-07', '2017-09-07 19:51:03', '0');
INSERT INTO `wgi_price_info` VALUES ('120', '5', '23', 'tang001', null, 'tang006 注册,领导奖的20%转为注册币', 'tang006 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9999606.52', '9999606.50', '0.02', null, '2017-09-07', '2017-09-07 19:51:03', '0');
INSERT INTO `wgi_price_info` VALUES ('121', '5', '23', 'tang001', null, 'tang002 原点升级,推荐奖的20%转为注册币', 'tang002 origin upgrade, Referral Bonus20.%transfered into Register Coin', null, null, '9999610.52', '9999606.52', '4.00', null, '2017-09-07', '2017-09-07 19:51:39', '0');
INSERT INTO `wgi_price_info` VALUES ('122', '5', '23', 'tang001', null, 'tang002 原点升级,见点奖的20%转为注册币', 'tang002 origin upgrade, Referral Bonus20.%transfered into Register Coin', null, null, '9999610.92', '9999610.52', '0.40', null, '2017-09-07', '2017-09-07 19:51:39', '0');
INSERT INTO `wgi_price_info` VALUES ('123', '2', '24', 'tang002', null, 'tang008 注册账号支出', 'tang008 Register', null, null, '9402.20', '9502.20', '100.00', null, '2017-09-07', '2017-09-07 19:54:08', '0');
INSERT INTO `wgi_price_info` VALUES ('124', '5', '24', 'tang002', null, 'tang008 注册,推荐奖的20%转为注册币', 'tang008 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9403.40', '9402.20', '1.20', null, '2017-09-07', '2017-09-07 19:54:08', '0');
INSERT INTO `wgi_price_info` VALUES ('125', '5', '26', 'tang004', null, 'tang008 注册,见点奖的20%转为注册币', 'tang008 registered, Referral Bonus20.%transfered into Register Coin', null, null, '0.10', '0.00', '0.10', null, '2017-09-07', '2017-09-07 19:54:08', '0');
INSERT INTO `wgi_price_info` VALUES ('126', '5', '24', 'tang002', null, 'tang008 注册,见点奖的20%转为注册币', 'tang008 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9403.50', '9403.40', '0.10', null, '2017-09-07', '2017-09-07 19:54:08', '0');
INSERT INTO `wgi_price_info` VALUES ('127', '5', '23', 'tang001', null, 'tang008 注册,见点奖的20%转为注册币', 'tang008 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9999611.02', '9999610.92', '0.10', null, '2017-09-07', '2017-09-07 19:54:08', '0');
INSERT INTO `wgi_price_info` VALUES ('128', '2', '24', 'tang002', 'WGI24271294', 'tang002复投', 'tang002Reinvested', null, 'tang002复投', '8903.50', '9403.50', '500.00', null, '2017-09-07', '2017-09-07 20:43:08', '0');
INSERT INTO `wgi_price_info` VALUES ('129', '2', '23', 'tang001', null, 'tang888 注册账号支出', 'tang888 Register', null, null, '9999511.02', '9999611.02', '100.00', null, '2017-09-09', '2017-09-09 16:34:33', '0');
INSERT INTO `wgi_price_info` VALUES ('130', '5', '23', 'tang001', null, 'tang888 注册,推荐奖的20%转为注册币', 'tang888 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9999512.02', '9999511.02', '1.00', null, '2017-09-09', '2017-09-09 16:34:33', '0');
INSERT INTO `wgi_price_info` VALUES ('131', '5', '23', 'tang001', null, 'tang888 注册,见点奖的20%转为注册币', 'tang888 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9999512.12', '9999512.02', '0.10', null, '2017-09-09', '2017-09-09 16:34:33', '0');
INSERT INTO `wgi_price_info` VALUES ('132', '5', '23', 'tang001', null, 'tang888 注册,对碰奖的20%转为注册币', 'tang888 registered, Referral Bonus20.%transfered into Register Coin', null, null, '9999513.12', '9999512.12', '1.00', null, '2017-09-09', '2017-09-09 16:34:33', '0');

-- ----------------------------
-- Table structure for wgi_price_integral_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_price_integral_info`;
CREATE TABLE `wgi_price_integral_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '积分',
  `type` int(11) DEFAULT '0' COMMENT '1充值，2 获得,3 出售 ，4转成注册币 ',
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `order_id` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `title_en` varchar(255) DEFAULT NULL,
  `title_sp` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `new_number` decimal(10,2) DEFAULT '0.00',
  `old_number` decimal(10,2) DEFAULT '0.00',
  `number` decimal(10,2) DEFAULT '0.00',
  `admin_id` int(11) DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_price_integral_info
-- ----------------------------
INSERT INTO `wgi_price_integral_info` VALUES ('14', '2', '23', 'tang001', 'WGI23167585', '售出股份转化为WGI积分', 'Converted to WGI shares sold', null, null, '3.60', null, '3.60', null, '2017-09-07', '2017-09-07 19:57:40', '0');
INSERT INTO `wgi_price_integral_info` VALUES ('15', '2', '23', 'tang001', 'WGI23445180', '售出股份转化为WGI积分', 'Converted to WGI shares sold', null, null, '33.30', '3.60', '29.70', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_price_integral_info` VALUES ('16', '2', '23', 'tang001', 'WGI23968424', 'tang001爆仓自动卖股转积分', 'Burst warehouse automatically sell shares to points', null, '爆仓', '10.76', '3.60', '7.16', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_price_integral_info` VALUES ('17', '2', '24', null, 'WGI24922929', 'tang002爆仓自动卖股转积分', 'Burst warehouse automatically sell shares to points', null, '爆仓', '396.00', null, '396.00', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_price_integral_info` VALUES ('18', '2', '25', null, 'WGI25163649', 'tang003爆仓自动卖股转积分', 'Burst warehouse automatically sell shares to points', null, '爆仓', '79.20', null, '79.20', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_price_integral_info` VALUES ('19', '2', '26', null, 'WGI26669308', 'tang004爆仓自动卖股转积分', 'Burst warehouse automatically sell shares to points', null, '爆仓', '79.20', null, '79.20', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_price_integral_info` VALUES ('20', '2', '27', null, 'WGI27321680', 'tang005爆仓自动卖股转积分', 'Burst warehouse automatically sell shares to points', null, '爆仓', '79.20', null, '79.20', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_price_integral_info` VALUES ('21', '2', '28', null, 'WGI28201166', 'tang006爆仓自动卖股转积分', 'Burst warehouse automatically sell shares to points', null, '爆仓', '79.20', null, '79.20', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_price_integral_info` VALUES ('22', '2', '29', null, 'WGI29147025', 'tang008爆仓自动卖股转积分', 'Burst warehouse automatically sell shares to points', null, '爆仓', '79.20', null, '79.20', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_price_integral_info` VALUES ('23', '2', '23', 'tang001', 'WGI23243730', 'tang001爆仓自动卖股转积分', 'Burst warehouse automatically sell shares to points', null, '爆仓', '41.86', '10.76', '31.10', null, '2017-09-07', '2017-09-07 20:35:52', '0');

-- ----------------------------
-- Table structure for wgi_price_money_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_price_money_info`;
CREATE TABLE `wgi_price_money_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `type` tinyint(1) DEFAULT '0' COMMENT '交易类型（1-充值，2-动态获得，3-出售，4-转成注册币，5-取消出售返还，6-购买）',
  `member_id` int(11) unsigned DEFAULT NULL COMMENT '会员ID',
  `member_username` varchar(50) DEFAULT NULL COMMENT '会员账号',
  `order_id` varchar(50) DEFAULT NULL COMMENT '订单编号',
  `title` varchar(255) DEFAULT NULL COMMENT '交易标题-中文',
  `title_en` varchar(255) DEFAULT NULL COMMENT '交易标题-英文',
  `title_sp` varchar(255) DEFAULT NULL COMMENT '交易标题-西班牙文',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注说明',
  `new_price` decimal(10,2) DEFAULT '0.00' COMMENT '现金币币钱包交易后的金额数量',
  `old_price` decimal(10,2) DEFAULT '0.00' COMMENT '现金币币钱包交易前的金额数量',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '交易金额数量',
  `change_price` decimal(10,2) DEFAULT '0.00' COMMENT '改变的金额数',
  `server_buy_id` int(11) unsigned DEFAULT NULL COMMENT '买入的会员ID',
  `server_sell_id` int(11) unsigned DEFAULT NULL COMMENT '出售的会员ID',
  `admin_id` int(11) DEFAULT NULL COMMENT '操作的管理员ID',
  `status` tinyint(1) DEFAULT '4' COMMENT '状态（0-待抢单，1-已抢单，2-已付款，3-已拒绝收款， 4-完成）',
  `touch_time` datetime DEFAULT NULL COMMENT '对碰时间',
  `adddate` date DEFAULT NULL COMMENT '交易日期',
  `addtime` datetime DEFAULT NULL COMMENT '交易日期时间',
  `delete` tinyint(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=171 DEFAULT CHARSET=utf8 COMMENT='现金币交易记录';

-- ----------------------------
-- Records of wgi_price_money_info
-- ----------------------------
INSERT INTO `wgi_price_money_info` VALUES ('127', '5', '23', 'tang001', 'CB5643708', 'tang002 注册,推荐奖的80%转为现金币', 'tang002 registered, POS Bonus80% transfered into Cash Coin', null, null, '4.00', '0.00', '4.00', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:46:53', '0');
INSERT INTO `wgi_price_money_info` VALUES ('128', '5', '23', 'tang001', 'CB6886484', 'tang002 注册,见点奖的80%转为现金币', 'tang002 registered, POS Bonus80% transfered into Cash Coin', null, null, '4.40', '4.00', '0.40', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:46:53', '0');
INSERT INTO `wgi_price_money_info` VALUES ('129', '5', '23', 'tang001', 'CB1851294', 'tang002 注册,商务奖的0.5%转为现金币', 'tang002 registered, POS Bonus0.5% transfered into Cash Coin', null, null, '4.90', '4.40', '0.50', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:46:53', '0');
INSERT INTO `wgi_price_money_info` VALUES ('130', '5', '23', 'tang001', 'CB5180762', 'tang003 注册,推荐奖的80%转为现金币', 'tang003 registered, POS Bonus80% transfered into Cash Coin', null, null, '8.90', '4.90', '4.00', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:47:42', '0');
INSERT INTO `wgi_price_money_info` VALUES ('131', '5', '23', 'tang001', 'CB3155789', 'tang003 注册,见点奖的80%转为现金币', 'tang003 registered, POS Bonus80% transfered into Cash Coin', null, null, '9.30', '8.90', '0.40', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:47:42', '0');
INSERT INTO `wgi_price_money_info` VALUES ('132', '5', '23', 'tang001', 'CB6577136', 'tang003 注册,对碰奖的80%转为现金币', 'tang003 registered, POS Bonus80% transfered into Cash Coin', null, null, '13.30', '9.30', '4.00', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:47:42', '0');
INSERT INTO `wgi_price_money_info` VALUES ('133', '5', '23', 'tang001', 'CB8569320', 'tang004 注册,推荐奖的80%转为现金币', 'tang004 registered, POS Bonus80% transfered into Cash Coin', null, null, '17.30', '13.30', '4.00', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:48:27', '0');
INSERT INTO `wgi_price_money_info` VALUES ('134', '5', '24', 'tang002', 'CB2873867', 'tang004 注册,见点奖的80%转为现金币', 'tang004 registered, POS Bonus80% transfered into Cash Coin', null, null, '0.40', '0.00', '0.40', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:48:27', '0');
INSERT INTO `wgi_price_money_info` VALUES ('135', '5', '23', 'tang001', 'CB2912349', 'tang004 注册,见点奖的80%转为现金币', 'tang004 registered, POS Bonus80% transfered into Cash Coin', null, null, '17.70', '17.30', '0.40', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:48:27', '0');
INSERT INTO `wgi_price_money_info` VALUES ('136', '5', '23', 'tang001', 'CB3015771', 'tang005 注册,推荐奖的80%转为现金币', 'tang005 registered, POS Bonus80% transfered into Cash Coin', null, null, '21.70', '17.70', '4.00', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:48:52', '0');
INSERT INTO `wgi_price_money_info` VALUES ('137', '5', '25', 'tang003', 'CB7668464', 'tang005 注册,见点奖的80%转为现金币', 'tang005 registered, POS Bonus80% transfered into Cash Coin', null, null, '0.40', '0.00', '0.40', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:48:52', '0');
INSERT INTO `wgi_price_money_info` VALUES ('138', '5', '23', 'tang001', 'CB4523210', 'tang005 注册,见点奖的80%转为现金币', 'tang005 registered, POS Bonus80% transfered into Cash Coin', null, null, '22.10', '21.70', '0.40', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:48:52', '0');
INSERT INTO `wgi_price_money_info` VALUES ('139', '5', '23', 'tang001', 'CB8507784', 'tang005 注册,对碰奖的80%转为现金币', 'tang005 registered, POS Bonus80% transfered into Cash Coin', null, null, '26.10', '22.10', '4.00', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:48:52', '0');
INSERT INTO `wgi_price_money_info` VALUES ('140', '5', '24', 'tang002', 'CB9500154', 'tang006 注册,推荐奖的80%转为现金币', 'tang006 registered, POS Bonus80% transfered into Cash Coin', null, null, '4.40', '0.40', '4.00', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:51:03', '0');
INSERT INTO `wgi_price_money_info` VALUES ('141', '5', '24', 'tang002', 'CB4691716', 'tang006 注册,见点奖的80%转为现金币', 'tang006 registered, POS Bonus80% transfered into Cash Coin', null, null, '4.80', '4.40', '0.40', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:51:03', '0');
INSERT INTO `wgi_price_money_info` VALUES ('142', '5', '23', 'tang001', 'CB8949767', 'tang006 注册,见点奖的80%转为现金币', 'tang006 registered, POS Bonus80% transfered into Cash Coin', null, null, '26.50', '26.10', '0.40', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:51:03', '0');
INSERT INTO `wgi_price_money_info` VALUES ('143', '5', '24', 'tang002', 'CB5728249', 'tang006 注册,对碰奖的80%转为现金币', 'tang006 registered, POS Bonus80% transfered into Cash Coin', null, null, '8.80', '4.80', '4.00', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:51:03', '0');
INSERT INTO `wgi_price_money_info` VALUES ('144', '5', '23', 'tang001', 'CB9305588', 'tang006 注册,领导奖的80%转为现金币', 'tang006 registered, POS Bonus80% transfered into Cash Coin', null, null, '26.58', '26.50', '0.08', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:51:03', '0');
INSERT INTO `wgi_price_money_info` VALUES ('145', '5', '23', 'tang001', 'CB4758845', 'tang002 原点升级,推荐奖的80%转为现金币', 'tang002 origin upgrade, POS Bonus80% transfered into Cash Coin', null, null, '42.58', '26.58', '16.00', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:51:39', '0');
INSERT INTO `wgi_price_money_info` VALUES ('146', '5', '23', 'tang001', 'CB1887601', 'tang002 原点升级,见点奖的80%转为现金币', 'tang002 origin upgrade, POS Bonus80% transfered into Cash Coin', null, null, '44.18', '42.58', '1.60', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:51:39', '0');
INSERT INTO `wgi_price_money_info` VALUES ('147', '5', '23', 'tang001', 'CB7931250', 'tang002 原点升级,商务奖的0.5%转为现金币', 'tang002 origin upgrade, POS Bonus0.5% transfered into Cash Coin', null, null, '46.18', '44.18', '2.00', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:51:39', '0');
INSERT INTO `wgi_price_money_info` VALUES ('148', '5', '24', 'tang002', 'CB4122187', 'tang008 注册,推荐奖的80%转为现金币', 'tang008 registered, POS Bonus80% transfered into Cash Coin', null, null, '13.60', '8.80', '4.80', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:54:08', '0');
INSERT INTO `wgi_price_money_info` VALUES ('149', '5', '26', 'tang004', 'CB2912720', 'tang008 注册,见点奖的80%转为现金币', 'tang008 registered, POS Bonus80% transfered into Cash Coin', null, null, '0.40', '0.00', '0.40', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:54:08', '0');
INSERT INTO `wgi_price_money_info` VALUES ('150', '5', '24', 'tang002', 'CB9407193', 'tang008 注册,见点奖的80%转为现金币', 'tang008 registered, POS Bonus80% transfered into Cash Coin', null, null, '14.00', '13.60', '0.40', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:54:08', '0');
INSERT INTO `wgi_price_money_info` VALUES ('151', '5', '23', 'tang001', 'CB9616850', 'tang008 注册,见点奖的80%转为现金币', 'tang008 registered, POS Bonus80% transfered into Cash Coin', null, null, '46.58', '46.18', '0.40', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 19:54:08', '0');
INSERT INTO `wgi_price_money_info` VALUES ('152', '2', '23', 'tang001', 'WGI23167585', '卖出股份转现金币', 'Sell shares transfer cash', null, null, '68.18', '46.58', '21.60', '0.00', null, null, null, '4', '2017-09-07 19:57:40', '2017-09-07', '2017-09-07 19:57:40', '0');
INSERT INTO `wgi_price_money_info` VALUES ('153', '1', '23', 'tang001', 'CC2049247', '现金币充值', 'Cash coin recharge', null, null, '10068.18', '68.18', '10000.00', '0.00', null, null, '1', '4', null, '2017-09-07', '2017-09-07 20:01:13', '0');
INSERT INTO `wgi_price_money_info` VALUES ('154', '3', '23', 'tang001', 'WGICB9103833', '售出现金币', 'Sold CC', 'Sold CC', null, '9968.18', '10068.18', '100.00', '100.00', '6', null, null, '4', null, '2017-09-07', '2017-09-07 20:27:50', '0');
INSERT INTO `wgi_price_money_info` VALUES ('155', '6', '24', 'tang002', 'WGICB9103833', '购买现金币', 'Enable Buy CC', 'Enable Buy CC', null, '114.00', '14.00', '100.00', '100.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 20:29:48', '0');
INSERT INTO `wgi_price_money_info` VALUES ('156', '3', '23', 'tang001', 'WGICB6893813', '售出现金币', 'Sold CC', 'Sold CC', null, '9868.18', '9968.18', '100.00', '100.00', '7', null, null, '4', null, '2017-09-07', '2017-09-07 20:30:12', '0');
INSERT INTO `wgi_price_money_info` VALUES ('157', '3', '23', 'tang001', 'WGICB6983185', '售出现金币', 'Sold CC', 'Sold CC', null, '9768.18', '9868.18', '100.00', '100.00', '8', null, null, '4', null, '2017-09-07', '2017-09-07 20:31:39', '0');
INSERT INTO `wgi_price_money_info` VALUES ('158', '6', '24', 'tang002', 'RC9801176', '购买现金币', 'Buy Cash Coin', null, null, '100.40', '0.40', '100.00', '0.00', null, null, '1', '4', null, '2017-09-07', '2017-09-07 20:33:30', '0');
INSERT INTO `wgi_price_money_info` VALUES ('159', '2', '23', 'tang001', 'WGI23445180', '卖出股份转现金币', 'Sell shares transfer cash', null, null, '9946.38', '9768.18', '178.20', '0.00', null, null, null, '4', '2017-09-07 20:35:42', '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_price_money_info` VALUES ('160', '2', '23', 'tang001', 'WGI23968424', 'tang001爆仓自动卖股转现金币', 'Burst warehouse automatically sell shares to cash', null, '爆仓', '9832.66', '9768.18', '64.48', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_price_money_info` VALUES ('161', '2', '24', null, 'WGI24922929', 'tang002爆仓自动卖股转现金币', 'Burst warehouse automatically sell shares to cash', null, '爆仓', '3664.40', '100.40', '3564.00', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_price_money_info` VALUES ('162', '2', '25', null, 'WGI25163649', 'tang003爆仓自动卖股转现金币', 'Burst warehouse automatically sell shares to cash', null, '爆仓', '713.20', '0.40', '712.80', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_price_money_info` VALUES ('163', '2', '26', null, 'WGI26669308', 'tang004爆仓自动卖股转现金币', 'Burst warehouse automatically sell shares to cash', null, '爆仓', '713.20', '0.40', '712.80', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_price_money_info` VALUES ('164', '2', '27', null, 'WGI27321680', 'tang005爆仓自动卖股转现金币', 'Burst warehouse automatically sell shares to cash', null, '爆仓', '712.80', null, '712.80', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_price_money_info` VALUES ('165', '2', '28', null, 'WGI28201166', 'tang006爆仓自动卖股转现金币', 'Burst warehouse automatically sell shares to cash', null, '爆仓', '712.80', null, '712.80', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_price_money_info` VALUES ('166', '2', '29', null, 'WGI29147025', 'tang008爆仓自动卖股转现金币', 'Burst warehouse automatically sell shares to cash', null, '爆仓', '712.80', null, '712.80', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_price_money_info` VALUES ('167', '2', '23', 'tang001', 'WGI23243730', 'tang001爆仓自动卖股转现金币', 'Burst warehouse automatically sell shares to cash', null, '爆仓', '10112.60', '9832.66', '279.94', '0.00', null, null, null, '4', null, '2017-09-07', '2017-09-07 20:35:52', '0');
INSERT INTO `wgi_price_money_info` VALUES ('168', '5', '23', 'tang001', 'CB5347509', 'tang888 注册,推荐奖的80%转为现金币', 'tang888 registered, POS Bonus80% transfered into Cash Coin', null, null, '10116.60', '10112.60', '4.00', '0.00', null, null, null, '4', null, '2017-09-09', '2017-09-09 16:34:33', '0');
INSERT INTO `wgi_price_money_info` VALUES ('169', '5', '23', 'tang001', 'CB6377990', 'tang888 注册,见点奖的80%转为现金币', 'tang888 registered, POS Bonus80% transfered into Cash Coin', null, null, '10117.00', '10116.60', '0.40', '0.00', null, null, null, '4', null, '2017-09-09', '2017-09-09 16:34:33', '0');
INSERT INTO `wgi_price_money_info` VALUES ('170', '5', '23', 'tang001', 'CB2436131', 'tang888 注册,对碰奖的80%转为现金币', 'tang888 registered, POS Bonus80% transfered into Cash Coin', null, null, '10121.00', '10117.00', '4.00', '0.00', null, null, null, '4', null, '2017-09-09', '2017-09-09 16:34:33', '0');

-- ----------------------------
-- Table structure for wgi_reg_code
-- ----------------------------
DROP TABLE IF EXISTS `wgi_reg_code`;
CREATE TABLE `wgi_reg_code` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `code` varchar(50) DEFAULT NULL,
  `remark` text,
  `changetime` datetime DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `status` int(1) DEFAULT '1',
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_reg_code
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_repeat_order_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_repeat_order_info`;
CREATE TABLE `wgi_repeat_order_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_number` varchar(50) DEFAULT NULL,
  `type` int(11) DEFAULT '0' COMMENT '1,转入,2,转出',
  `member_id` int(11) DEFAULT NULL COMMENT '所属用户',
  `member_username` varchar(50) DEFAULT NULL,
  `pay_number` int(11) DEFAULT '0' COMMENT '交易股数',
  `share_price` decimal(10,3) DEFAULT '0.000' COMMENT '股价',
  `pay_price` decimal(10,2) DEFAULT '0.00' COMMENT '交易金额',
  `split_id` int(11) DEFAULT NULL,
  `title` text,
  `remark` text,
  `touch_datetime` datetime DEFAULT NULL COMMENT '配股日期',
  `free_datetime` datetime DEFAULT NULL COMMENT '解冻日期',
  `status` tinyint(1) DEFAULT '0' COMMENT '0 配股(排队中) 1,已配股    4 完成',
  `adddate` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_repeat_order_info
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_role
-- ----------------------------
DROP TABLE IF EXISTS `wgi_role`;
CREATE TABLE `wgi_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `name` varchar(20) NOT NULL COMMENT '名称',
  `pid` smallint(6) DEFAULT NULL COMMENT '上级角色ID',
  `status` tinyint(1) unsigned DEFAULT NULL COMMENT '状态（0-停用，1-启用）',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`id`),
  KEY `pid` (`pid`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_role
-- ----------------------------
INSERT INTO `wgi_role` VALUES ('1', '管理员', null, '1', '管理员组');
INSERT INTO `wgi_role` VALUES ('2', '客户部', null, '1', '客户人员组');

-- ----------------------------
-- Table structure for wgi_role_user
-- ----------------------------
DROP TABLE IF EXISTS `wgi_role_user`;
CREATE TABLE `wgi_role_user` (
  `role_id` mediumint(9) unsigned DEFAULT NULL,
  `user_id` char(32) DEFAULT NULL,
  KEY `group_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_role_user
-- ----------------------------
INSERT INTO `wgi_role_user` VALUES ('0', '1');

-- ----------------------------
-- Table structure for wgi_server_buy_price
-- ----------------------------
DROP TABLE IF EXISTS `wgi_server_buy_price`;
CREATE TABLE `wgi_server_buy_price` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `order_number` varchar(50) DEFAULT NULL COMMENT '订单编号',
  `member_id` int(11) DEFAULT NULL COMMENT '购买会员ID',
  `member_username` varchar(50) DEFAULT NULL COMMENT '购买会员账号',
  `member_telephone` varchar(50) DEFAULT NULL COMMENT '购买会员手机号码',
  `picture` varchar(255) DEFAULT NULL,
  `money_id` int(11) DEFAULT NULL COMMENT '现金币交易记录ID',
  `title` varchar(50) DEFAULT NULL COMMENT '标题-中文',
  `title_en` varchar(50) DEFAULT NULL COMMENT '标题-英文',
  `title_sp` varchar(50) DEFAULT NULL COMMENT '标题-西班牙文',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '购买金额数量',
  `price_turn` decimal(10,2) DEFAULT '0.00' COMMENT '折扣率',
  `system_price` decimal(10,2) DEFAULT '0.00' COMMENT '实际购买金额',
  `status` int(1) DEFAULT '0' COMMENT '1-已抢单，2-买家已付款，3-完成',
  `adddate` date DEFAULT NULL COMMENT '购买日期',
  `addtime` datetime DEFAULT NULL COMMENT '购买时间',
  `delete` tinyint(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='现金币购买记录';

-- ----------------------------
-- Records of wgi_server_buy_price
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_server_price_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_server_price_info`;
CREATE TABLE `wgi_server_price_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `type` int(11) DEFAULT NULL COMMENT '1,收入(卖出)   2,支出  (买入) 3,提现 4,退回',
  `title` varchar(50) DEFAULT NULL,
  `title_en` varchar(50) DEFAULT NULL,
  `title_sp` varchar(50) DEFAULT NULL,
  `remark` text,
  `price` decimal(10,2) DEFAULT '0.00',
  `usd_price` decimal(10,2) DEFAULT '0.00',
  `adddate` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_server_price_info
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_share_number_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_share_number_info`;
CREATE TABLE `wgi_share_number_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(1) DEFAULT '0' COMMENT '1,转入 2,转出，4-回购',
  `member_id` int(11) DEFAULT NULL,
  `member_username` varchar(50) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `title_en` varchar(255) NOT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `new_number` decimal(10,0) DEFAULT '0' COMMENT '最新数量',
  `old_number` decimal(10,0) DEFAULT '0',
  `number` decimal(10,0) DEFAULT '0' COMMENT '交易数量',
  `admin_id` int(11) DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_share_number_info
-- ----------------------------
INSERT INTO `wgi_share_number_info` VALUES ('45', '2', '23', 'tang001', '股票出售', 'Sell', '股票出售', '5', '25', '20', null, '2017-09-07', '2017-09-07 19:57:40', '0');
INSERT INTO `wgi_share_number_info` VALUES ('46', '4', '23', 'tang001', '回购', 'hg', null, '8', '5', '3', null, '2017-09-07', '2017-09-07 19:57:40', '0');
INSERT INTO `wgi_share_number_info` VALUES ('47', '1', '23', 'tang001', '拆分后配股', 'Split', '拆分', '16', '8', '8', '1', '2017-09-07', '2017-09-07 20:13:13', '0');
INSERT INTO `wgi_share_number_info` VALUES ('48', '1', '24', 'tang002', '拆分后配股', 'Split', '拆分', '258', '129', '129', '1', '2017-09-07', '2017-09-07 20:13:13', '0');
INSERT INTO `wgi_share_number_info` VALUES ('49', '1', '25', 'tang003', '拆分后配股', 'Split', '拆分', '50', '25', '25', '1', '2017-09-07', '2017-09-07 20:13:13', '0');
INSERT INTO `wgi_share_number_info` VALUES ('50', '1', '26', 'tang004', '拆分后配股', 'Split', '拆分', '50', '25', '25', '1', '2017-09-07', '2017-09-07 20:13:13', '0');
INSERT INTO `wgi_share_number_info` VALUES ('51', '1', '27', 'tang005', '拆分后配股', 'Split', '拆分', '50', '25', '25', '1', '2017-09-07', '2017-09-07 20:13:13', '0');
INSERT INTO `wgi_share_number_info` VALUES ('52', '1', '28', 'tang006', '拆分后配股', 'Split', '拆分', '50', '25', '25', '1', '2017-09-07', '2017-09-07 20:13:13', '0');
INSERT INTO `wgi_share_number_info` VALUES ('53', '1', '29', 'tang008', '拆分后配股', 'Split', '拆分', '50', '25', '25', '1', '2017-09-07', '2017-09-07 20:13:13', '0');
INSERT INTO `wgi_share_number_info` VALUES ('54', '1', '23', 'tang001', '拆分后配股', 'Split', '拆分', '32', '16', '16', '1', '2017-09-07', '2017-09-07 20:15:47', '0');
INSERT INTO `wgi_share_number_info` VALUES ('55', '1', '24', 'tang002', '拆分后配股', 'Split', '拆分', '516', '258', '258', '1', '2017-09-07', '2017-09-07 20:15:47', '0');
INSERT INTO `wgi_share_number_info` VALUES ('56', '1', '25', 'tang003', '拆分后配股', 'Split', '拆分', '100', '50', '50', '1', '2017-09-07', '2017-09-07 20:15:47', '0');
INSERT INTO `wgi_share_number_info` VALUES ('57', '1', '26', 'tang004', '拆分后配股', 'Split', '拆分', '100', '50', '50', '1', '2017-09-07', '2017-09-07 20:15:47', '0');
INSERT INTO `wgi_share_number_info` VALUES ('58', '1', '27', 'tang005', '拆分后配股', 'Split', '拆分', '100', '50', '50', '1', '2017-09-07', '2017-09-07 20:15:47', '0');
INSERT INTO `wgi_share_number_info` VALUES ('59', '1', '28', 'tang006', '拆分后配股', 'Split', '拆分', '100', '50', '50', '1', '2017-09-07', '2017-09-07 20:15:47', '0');
INSERT INTO `wgi_share_number_info` VALUES ('60', '1', '29', 'tang008', '拆分后配股', 'Split', '拆分', '100', '50', '50', '1', '2017-09-07', '2017-09-07 20:15:47', '0');
INSERT INTO `wgi_share_number_info` VALUES ('61', '1', '23', 'tang001', '拆分后配股', 'Split', '拆分', '64', '32', '32', '1', '2017-09-07', '2017-09-07 20:16:06', '0');
INSERT INTO `wgi_share_number_info` VALUES ('62', '1', '24', 'tang002', '拆分后配股', 'Split', '拆分', '1032', '516', '516', '1', '2017-09-07', '2017-09-07 20:16:06', '0');
INSERT INTO `wgi_share_number_info` VALUES ('63', '1', '25', 'tang003', '拆分后配股', 'Split', '拆分', '200', '100', '100', '1', '2017-09-07', '2017-09-07 20:16:06', '0');
INSERT INTO `wgi_share_number_info` VALUES ('64', '1', '26', 'tang004', '拆分后配股', 'Split', '拆分', '200', '100', '100', '1', '2017-09-07', '2017-09-07 20:16:06', '0');
INSERT INTO `wgi_share_number_info` VALUES ('65', '1', '27', 'tang005', '拆分后配股', 'Split', '拆分', '200', '100', '100', '1', '2017-09-07', '2017-09-07 20:16:06', '0');
INSERT INTO `wgi_share_number_info` VALUES ('66', '1', '28', 'tang006', '拆分后配股', 'Split', '拆分', '200', '100', '100', '1', '2017-09-07', '2017-09-07 20:16:06', '0');
INSERT INTO `wgi_share_number_info` VALUES ('67', '1', '29', 'tang008', '拆分后配股', 'Split', '拆分', '200', '100', '100', '1', '2017-09-07', '2017-09-07 20:16:06', '0');
INSERT INTO `wgi_share_number_info` VALUES ('68', '1', '23', 'tang001', '拆分后配股', 'Split', '拆分', '128', '64', '64', '1', '2017-09-07', '2017-09-07 20:17:51', '0');
INSERT INTO `wgi_share_number_info` VALUES ('69', '1', '24', 'tang002', '拆分后配股', 'Split', '拆分', '2064', '1032', '1032', '1', '2017-09-07', '2017-09-07 20:17:51', '0');
INSERT INTO `wgi_share_number_info` VALUES ('70', '1', '25', 'tang003', '拆分后配股', 'Split', '拆分', '400', '200', '200', '1', '2017-09-07', '2017-09-07 20:17:51', '0');
INSERT INTO `wgi_share_number_info` VALUES ('71', '1', '26', 'tang004', '拆分后配股', 'Split', '拆分', '400', '200', '200', '1', '2017-09-07', '2017-09-07 20:17:51', '0');
INSERT INTO `wgi_share_number_info` VALUES ('72', '1', '27', 'tang005', '拆分后配股', 'Split', '拆分', '400', '200', '200', '1', '2017-09-07', '2017-09-07 20:17:51', '0');
INSERT INTO `wgi_share_number_info` VALUES ('73', '1', '28', 'tang006', '拆分后配股', 'Split', '拆分', '400', '200', '200', '1', '2017-09-07', '2017-09-07 20:17:51', '0');
INSERT INTO `wgi_share_number_info` VALUES ('74', '1', '29', 'tang008', '拆分后配股', 'Split', '拆分', '400', '200', '200', '1', '2017-09-07', '2017-09-07 20:17:51', '0');
INSERT INTO `wgi_share_number_info` VALUES ('75', '1', '23', 'tang001', '拆分后配股', 'Split', '拆分', '256', '128', '128', '1', '2017-09-07', '2017-09-07 20:21:39', '0');
INSERT INTO `wgi_share_number_info` VALUES ('76', '1', '24', 'tang002', '拆分后配股', 'Split', '拆分', '4128', '2064', '2064', '1', '2017-09-07', '2017-09-07 20:21:39', '0');
INSERT INTO `wgi_share_number_info` VALUES ('77', '1', '25', 'tang003', '拆分后配股', 'Split', '拆分', '800', '400', '400', '1', '2017-09-07', '2017-09-07 20:21:39', '0');
INSERT INTO `wgi_share_number_info` VALUES ('78', '1', '26', 'tang004', '拆分后配股', 'Split', '拆分', '800', '400', '400', '1', '2017-09-07', '2017-09-07 20:21:39', '0');
INSERT INTO `wgi_share_number_info` VALUES ('79', '1', '27', 'tang005', '拆分后配股', 'Split', '拆分', '800', '400', '400', '1', '2017-09-07', '2017-09-07 20:21:39', '0');
INSERT INTO `wgi_share_number_info` VALUES ('80', '1', '28', 'tang006', '拆分后配股', 'Split', '拆分', '800', '400', '400', '1', '2017-09-07', '2017-09-07 20:21:39', '0');
INSERT INTO `wgi_share_number_info` VALUES ('81', '1', '29', 'tang008', '拆分后配股', 'Split', '拆分', '800', '400', '400', '1', '2017-09-07', '2017-09-07 20:21:39', '0');
INSERT INTO `wgi_share_number_info` VALUES ('82', '2', '23', 'tang001', '爆仓自动出售股份', 'Auto Sell', '爆仓自动出售股份', '91', '256', '165', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_share_number_info` VALUES ('83', '4', '23', 'tang001', '回购', 'Repurchase', null, '113', '91', '22', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_share_number_info` VALUES ('84', '2', '23', 'tang001', '爆仓自动出售股份', 'Auto Sell', null, '216', '256', '40', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_share_number_info` VALUES ('85', '2', '24', 'tang002', '爆仓出局，股份清零', 'Burst warehouse out, shares cleared', null, '0', '4128', '2200', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_share_number_info` VALUES ('86', '2', '25', 'tang003', '爆仓出局，股份清零', 'Burst warehouse out, shares cleared', null, '0', '800', '440', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_share_number_info` VALUES ('87', '2', '26', 'tang004', '爆仓出局，股份清零', 'Burst warehouse out, shares cleared', null, '0', '800', '440', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_share_number_info` VALUES ('88', '2', '27', 'tang005', '爆仓出局，股份清零', 'Burst warehouse out, shares cleared', null, '0', '800', '440', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_share_number_info` VALUES ('89', '2', '28', 'tang006', '爆仓出局，股份清零', 'Burst warehouse out, shares cleared', null, '0', '800', '440', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_share_number_info` VALUES ('90', '2', '29', 'tang008', '爆仓出局，股份清零', 'Burst warehouse out, shares cleared', null, '0', '800', '440', null, '2017-09-07', '2017-09-07 20:35:42', '0');
INSERT INTO `wgi_share_number_info` VALUES ('91', '2', '23', 'tang001', '爆仓自动出售股份', 'Auto Sell', null, '43', '216', '173', null, '2017-09-07', '2017-09-07 20:35:52', '0');
INSERT INTO `wgi_share_number_info` VALUES ('92', '1', '24', 'tang002', '复投配股', 'Re-allocation of share', null, '130', '0', '130', null, '2017-09-07', '2017-09-07 20:43:08', '0');

-- ----------------------------
-- Table structure for wgi_share_order_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_share_order_info`;
CREATE TABLE `wgi_share_order_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '用户股份池',
  `order_number` varchar(50) DEFAULT NULL COMMENT '用户订单号',
  `type` int(11) DEFAULT '0' COMMENT '1,买入,2,卖出3.复投',
  `member_id` int(11) DEFAULT NULL COMMENT '所属用户',
  `member_username` varchar(50) DEFAULT NULL COMMENT '用户名称',
  `pay_number` int(11) DEFAULT '0' COMMENT '交易股数',
  `share_price` decimal(10,2) DEFAULT '0.00' COMMENT '股价',
  `pay_price` decimal(10,2) DEFAULT '0.00' COMMENT '交易金额',
  `rest_sell` int(11) NOT NULL DEFAULT '0' COMMENT '剩下能出售股份的数量',
  `title` varchar(255) DEFAULT NULL,
  `title_en` varchar(255) DEFAULT NULL,
  `title_sp` varchar(255) DEFAULT NULL,
  `remark` text,
  `queue_bt` int(11) NOT NULL DEFAULT '0' COMMENT '排队出售补差价',
  `touch_datetime` datetime DEFAULT NULL COMMENT '配股日期',
  `status` tinyint(1) DEFAULT '0' COMMENT '0 配股(排队中) 1,已配股    4 完成',
  `adddate` date DEFAULT NULL,
  `addtime` datetime NOT NULL,
  `delete` int(11) NOT NULL DEFAULT '0',
  `dzid` int(10) DEFAULT '0' COMMENT '电子订单ID',
  PRIMARY KEY (`id`,`addtime`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_share_order_info
-- ----------------------------
INSERT INTO `wgi_share_order_info` VALUES ('70', 'SR9341412', '1', '23', 'tang001', '25', '2.00', '50.00', '0', '认购', 'Register', null, null, '0', '2017-09-07 19:45:59', '4', '2017-09-07', '2017-09-07 19:45:59', '0', '66');
INSERT INTO `wgi_share_order_info` VALUES ('71', 'SR5195414', '1', '24', 'tang002', '25', '2.00', '50.00', '0', '认购', 'Register', null, null, '0', '2017-09-07 19:46:53', '4', '2017-09-07', '2017-09-07 19:46:53', '0', '68');
INSERT INTO `wgi_share_order_info` VALUES ('72', 'SR5603630', '1', '25', 'tang003', '25', '2.00', '50.00', '0', '认购', 'Register', null, null, '0', '2017-09-07 19:47:42', '4', '2017-09-07', '2017-09-07 19:47:42', '0', '70');
INSERT INTO `wgi_share_order_info` VALUES ('73', 'SR3923538', '1', '26', 'tang004', '25', '2.00', '50.00', '0', '认购', 'Register', null, null, '0', '2017-09-07 19:48:27', '4', '2017-09-07', '2017-09-07 19:48:27', '0', '72');
INSERT INTO `wgi_share_order_info` VALUES ('74', 'SR1546482', '1', '27', 'tang005', '25', '2.00', '50.00', '0', '认购', 'Register', null, null, '0', '2017-09-07 19:48:52', '4', '2017-09-07', '2017-09-07 19:48:52', '0', '74');
INSERT INTO `wgi_share_order_info` VALUES ('75', 'SR2089163', '1', '28', 'tang006', '25', '2.00', '50.00', '0', '认购', 'Register', null, null, '0', '2017-09-07 19:51:03', '4', '2017-09-07', '2017-09-07 19:51:03', '0', '76');
INSERT INTO `wgi_share_order_info` VALUES ('76', 'SR5586436', '1', '24', 'tang002', '104', '2.00', '208.00', '0', '认购', 'Register', null, null, '0', '2017-09-07 19:51:39', '4', '2017-09-07', '2017-09-07 19:51:39', '0', '78');
INSERT INTO `wgi_share_order_info` VALUES ('77', 'SR1206781', '1', '29', 'tang008', '25', '2.00', '50.00', '0', '认购', 'Register', null, null, '0', '2017-09-07 19:54:08', '4', '2017-09-07', '2017-09-07 19:54:08', '0', '80');
INSERT INTO `wgi_share_order_info` VALUES ('79', 'WGI23992646', '4', '23', 'tang001', '3', '2.00', '5.40', '0', '回购股份', 'Repurchase shares', null, null, '0', '2017-09-07 19:57:40', '4', '2017-09-07', '2017-09-07 19:57:40', '0', '81');
INSERT INTO `wgi_share_order_info` VALUES ('80', 'WGI5777747', '1', '23', 'tang001', '8', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:13:13', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('81', 'WGI7008398', '1', '24', 'tang002', '129', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:13:13', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('82', 'WGI1375477', '1', '25', 'tang003', '25', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:13:13', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('83', 'WGI3376438', '1', '26', 'tang004', '25', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:13:13', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('84', 'WGI4568616', '1', '27', 'tang005', '25', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:13:13', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('85', 'WGI6724620', '1', '28', 'tang006', '25', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:13:13', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('86', 'WGI9455900', '1', '29', 'tang008', '25', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:13:13', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('87', 'WGI4148935', '1', '23', 'tang001', '16', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:15:47', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('88', 'WGI8986847', '1', '24', 'tang002', '258', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:15:47', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('89', 'WGI6628714', '1', '25', 'tang003', '50', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:15:47', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('90', 'WGI7499507', '1', '26', 'tang004', '50', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:15:47', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('91', 'WGI8271499', '1', '27', 'tang005', '50', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:15:47', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('92', 'WGI5868495', '1', '28', 'tang006', '50', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:15:47', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('93', 'WGI2254859', '1', '29', 'tang008', '50', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:15:47', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('94', 'WGI6884548', '1', '23', 'tang001', '32', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:16:06', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('95', 'WGI6937331', '1', '24', 'tang002', '516', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:16:06', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('96', 'WGI4535553', '1', '25', 'tang003', '100', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:16:06', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('97', 'WGI4643137', '1', '26', 'tang004', '100', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:16:06', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('98', 'WGI2358503', '1', '27', 'tang005', '100', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:16:06', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('99', 'WGI7214578', '1', '28', 'tang006', '100', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:16:06', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('100', 'WGI9625440', '1', '29', 'tang008', '100', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:16:06', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('101', 'WGI9924672', '1', '23', 'tang001', '64', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:17:51', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('102', 'WGI9502490', '1', '24', 'tang002', '1032', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:17:51', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('103', 'WGI1822983', '1', '25', 'tang003', '200', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:17:51', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('104', 'WGI7705329', '1', '26', 'tang004', '200', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:17:51', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('105', 'WGI5908792', '1', '27', 'tang005', '200', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:17:51', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('106', 'WGI2123131', '1', '28', 'tang006', '200', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:17:51', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('107', 'WGI2274798', '1', '29', 'tang008', '200', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:17:51', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('108', 'WGI5735112', '1', '23', 'tang001', '128', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:21:39', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('109', 'WGI6742454', '1', '24', 'tang002', '2064', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:21:39', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('110', 'WGI6594473', '1', '25', 'tang003', '400', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:21:39', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('111', 'WGI7536968', '1', '26', 'tang004', '400', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:21:39', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('112', 'WGI2256671', '1', '27', 'tang005', '400', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:21:39', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('113', 'WGI5937667', '1', '28', 'tang006', '400', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:21:39', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('114', 'WGI8706953', '1', '29', 'tang008', '400', '0.00', '0.00', '0', '拆分后配股', 'Split', null, '拆分', '0', null, '4', '2017-09-07', '2017-09-07 20:21:39', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('115', 'WGI23445180', '2', '23', 'tang001', '165', '2.00', '330.00', '0', '爆仓自动出售股份', 'Auto Sell', null, '爆仓自动出售股份', '0', '2017-09-07 20:35:42', '4', '2017-09-07', '2017-09-07 20:35:42', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('116', 'WGI23415960', '4', '23', 'tang001', '22', '2.00', '44.55', '0', '回购股份', 'Repurchase shares', null, null, '0', '2017-09-07 20:35:42', '4', '2017-09-07', '2017-09-07 20:35:42', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('117', 'WGI23968424', '2', '23', 'tang001', '40', '2.00', '79.60', '0', '爆仓自动出售股份', 'Auto Sell', null, '爆仓自动出售股份', '0', '2017-09-07 20:35:42', '4', '2017-09-07', '2017-09-07 20:35:42', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('118', 'WGI24922929', '2', '24', null, '2200', '2.00', '4400.00', '0', '爆仓自动出售股份', 'Auto Sell', null, '爆仓自动出售股份', '0', '2017-09-07 20:35:42', '4', '2017-09-07', '2017-09-07 20:35:42', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('119', 'WGI25163649', '2', '25', null, '440', '2.00', '880.00', '0', '爆仓自动出售股份', 'Auto Sell', null, '爆仓自动出售股份', '0', '2017-09-07 20:35:42', '4', '2017-09-07', '2017-09-07 20:35:42', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('120', 'WGI26669308', '2', '26', null, '440', '2.00', '880.00', '0', '爆仓自动出售股份', 'Auto Sell', null, '爆仓自动出售股份', '0', '2017-09-07 20:35:42', '4', '2017-09-07', '2017-09-07 20:35:42', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('121', 'WGI27321680', '2', '27', null, '440', '2.00', '880.00', '0', '爆仓自动出售股份', 'Auto Sell', null, '爆仓自动出售股份', '0', '2017-09-07 20:35:42', '4', '2017-09-07', '2017-09-07 20:35:42', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('122', 'WGI28201166', '2', '28', null, '440', '2.00', '880.00', '0', '爆仓自动出售股份', 'Auto Sell', null, '爆仓自动出售股份', '0', '2017-09-07 20:35:42', '4', '2017-09-07', '2017-09-07 20:35:42', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('123', 'WGI29147025', '2', '29', null, '440', '2.00', '880.00', '0', '爆仓自动出售股份', 'Auto Sell', null, '爆仓自动出售股份', '0', '2017-09-07 20:35:42', '4', '2017-09-07', '2017-09-07 20:35:42', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('124', 'WGI23243730', '2', '23', 'tang001', '173', '2.00', '345.60', '0', '爆仓自动出售股份', 'Auto Sell', null, '爆仓自动出售股份', '0', '2017-09-07 20:35:52', '4', '2017-09-07', '2017-09-07 20:35:52', '0', '0');
INSERT INTO `wgi_share_order_info` VALUES ('125', 'WGI24271294', '3', '24', 'tang002', '130', '2.00', '260.00', '0', '复投配股', 'Re-allocation of share', null, '复投配股', '0', '2017-09-07 20:43:08', '4', '2017-09-07', '2017-09-07 20:43:08', '0', '84');
INSERT INTO `wgi_share_order_info` VALUES ('126', 'SR5688935', '1', '30', 'tang888', '0', null, '50.00', '0', '认购', 'Register', null, null, '0', '2017-09-09 16:34:33', '4', '2017-09-09', '2017-09-09 16:34:33', '0', '86');

-- ----------------------------
-- Table structure for wgi_share_system_order_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_share_system_order_info`;
CREATE TABLE `wgi_share_system_order_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '平台股份池',
  `order_number` varchar(50) DEFAULT NULL COMMENT '用户订单号',
  `type` int(11) DEFAULT '0' COMMENT '1.回购',
  `member_id` int(11) DEFAULT NULL COMMENT '所属用户',
  `member_username` varchar(50) DEFAULT NULL COMMENT '用户名称',
  `pay_number` int(11) DEFAULT '0' COMMENT '交易股数',
  `share_price` decimal(10,2) DEFAULT '0.00' COMMENT '股价',
  `pay_price` decimal(10,2) DEFAULT '0.00' COMMENT '交易金额',
  `title` varchar(255) DEFAULT NULL,
  `title_en` varchar(255) DEFAULT NULL,
  `remark` text,
  `touch_datetime` datetime DEFAULT NULL COMMENT '配股日期',
  `adddate` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `delete` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_share_system_order_info
-- ----------------------------

-- ----------------------------
-- Table structure for wgi_sms
-- ----------------------------
DROP TABLE IF EXISTS `wgi_sms`;
CREATE TABLE `wgi_sms` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一递增编号',
  `member_id` int(11) DEFAULT NULL COMMENT '用户id',
  `tel` varchar(32) DEFAULT NULL COMMENT '手机号码',
  `content` varchar(255) DEFAULT NULL COMMENT '内容',
  `sendtime` datetime DEFAULT NULL COMMENT '发送时间',
  `code` char(10) DEFAULT NULL,
  `type` varchar(10) DEFAULT NULL COMMENT '类别（zcyz-注册验证，shtg-审核通过，jhtx-激活提醒，zhmm-找回密码，dktx-打款提醒，xgxx-修改信息，xgzh-收款账户，aqzx-安全中心，xgsj-修改手机号码）',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COMMENT='短信';

-- ----------------------------
-- Records of wgi_sms
-- ----------------------------
INSERT INTO `wgi_sms` VALUES ('7', '23', '18373954288', '【WGI】您正在进入安全设置修改页面，验证码为：2000', '2017-09-07 19:56:57', '2000', 'AQZX');
INSERT INTO `wgi_sms` VALUES ('8', '23', '18373954288', '【WGI】您正在进入收款账户修改页面，验证码为：4164', '2017-09-07 20:27:05', '4164', 'XGZH');
INSERT INTO `wgi_sms` VALUES ('9', '23', '18373954288', '【WGI】您正在进入安全设置修改页面，验证码为：1213', '2017-09-09 16:33:22', '1213', 'AQZX');
INSERT INTO `wgi_sms` VALUES ('10', '30', '18608409053', '【WGI】您正在进入安全设置修改页面，验证码为：6904', '2017-09-09 16:35:13', '6904', 'AQZX');
INSERT INTO `wgi_sms` VALUES ('11', '30', '18608409053', '【WGI】您正在进入安全设置修改页面，验证码为：5031', '2017-09-09 16:51:22', '5031', 'AQZX');
INSERT INTO `wgi_sms` VALUES ('12', null, '18608409053', '【WGI】您的找回密码验证码为3505', '2017-09-09 16:54:26', '3505', 'ZHMM');
INSERT INTO `wgi_sms` VALUES ('13', null, '18373954288', '【WGI】您的找回密码验证码为3193', '2017-09-11 10:04:56', '3193', 'ZHMM');
INSERT INTO `wgi_sms` VALUES ('14', null, '18373954288', '【WGI】Your password verification code is 5638', '2017-09-11 10:07:33', '5638', 'ZHMM');
INSERT INTO `wgi_sms` VALUES ('15', null, '18373954288', '【WGI】Your password verification code is 7544', '2017-09-11 10:10:58', '7544', 'ZHMM');
INSERT INTO `wgi_sms` VALUES ('16', null, '18373954288', '【WGI】您的找回密码验证码为2566', '2017-09-11 10:12:35', '2566', 'ZHMM');

-- ----------------------------
-- Table structure for wgi_split
-- ----------------------------
DROP TABLE IF EXISTS `wgi_split`;
CREATE TABLE `wgi_split` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `old_all_share` varchar(50) DEFAULT NULL COMMENT '拆分前总股数',
  `new_all_share` varchar(50) DEFAULT NULL,
  `split_double` decimal(10,2) DEFAULT '0.00',
  `split_price` decimal(10,3) DEFAULT '0.000',
  `split_new_price` decimal(10,3) DEFAULT '0.000',
  `admin_id` int(11) DEFAULT NULL,
  `admin_name` varchar(50) DEFAULT NULL,
  `remark` varchar(50) DEFAULT NULL,
  `adddate` date DEFAULT NULL,
  `addtime` datetime DEFAULT NULL,
  `delete` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_split
-- ----------------------------
INSERT INTO `wgi_split` VALUES ('13', '300000', '600000', '2.00', '2.000', '2.000', null, null, null, '2017-09-07', '2017-09-07 20:12:58', '0');
INSERT INTO `wgi_split` VALUES ('14', '600000', '1200000', '2.00', '2.000', '2.000', null, null, null, '2017-09-07', '2017-09-07 20:15:34', '0');
INSERT INTO `wgi_split` VALUES ('15', '1200000', '2400000', '2.00', '2.000', '2.000', null, null, null, '2017-09-07', '2017-09-07 20:15:52', '0');
INSERT INTO `wgi_split` VALUES ('16', '2400000', '4800000', '2.00', '2.000', '2.000', null, null, null, '2017-09-07', '2017-09-07 20:17:40', '0');
INSERT INTO `wgi_split` VALUES ('17', '4800000', '9600000', '2.00', '2.000', '2.000', null, null, null, '2017-09-07', '2017-09-07 20:21:28', '0');

-- ----------------------------
-- Table structure for wgi_trade_info
-- ----------------------------
DROP TABLE IF EXISTS `wgi_trade_info`;
CREATE TABLE `wgi_trade_info` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键唯一自增',
  `order_number` varchar(50) DEFAULT NULL COMMENT '订单编号',
  `sell_member_id` int(11) unsigned DEFAULT NULL COMMENT '出售会员ID',
  `buy_member_id` int(11) unsigned DEFAULT NULL COMMENT '购买会员ID',
  `sell_member_username` varchar(50) DEFAULT NULL COMMENT '出售会员账号',
  `buy_member_username` varchar(50) DEFAULT NULL COMMENT '购买会员账号',
  `pay_picture` varchar(255) DEFAULT NULL COMMENT '打款凭证图片',
  `sell_money_id` int(11) unsigned DEFAULT NULL COMMENT '出售会员钱包交易记录ID',
  `buy_money_id` int(11) DEFAULT NULL COMMENT '购买会员钱包交易记录ID',
  `price` decimal(10,2) DEFAULT '0.00' COMMENT '交易金额',
  `system_price` decimal(10,2) DEFAULT '0.00' COMMENT '系统交易金额',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注说明',
  `status` tinyint(1) DEFAULT '0' COMMENT '状态（0-待抢单， 1-已抢单， 2-买家已付款，3-拒绝收款，4-确认收款）',
  `qdtime` datetime DEFAULT NULL COMMENT '购买会员抢单时间',
  `paytime` datetime DEFAULT NULL COMMENT '购买会员付款时间',
  `entertime` datetime DEFAULT NULL COMMENT '出售会员确认收款时间',
  `adddate` date DEFAULT NULL COMMENT '出售会员申请卖出日期',
  `addtime` datetime DEFAULT NULL COMMENT '出售会员申请卖出时间',
  `delete` tinyint(1) DEFAULT '0' COMMENT '是否删除（0-否，1-是）',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COMMENT='现金币出售记录';

-- ----------------------------
-- Records of wgi_trade_info
-- ----------------------------
INSERT INTO `wgi_trade_info` VALUES ('8', 'WGICB6983185', '23', '24', 'tang001', 'tang002', '', '157', '158', '100.00', '90.00', null, '4', '2017-09-07 20:32:39', '2017-09-07 20:32:43', '2017-09-07 20:33:30', '2017-09-07', '2017-09-07 20:31:39', '0');
INSERT INTO `wgi_trade_info` VALUES ('7', 'WGICB6893813', '23', '0', 'tang001', null, '', '156', null, '100.00', '90.00', null, '0', null, null, null, '2017-09-07', '2017-09-07 20:30:12', '0');
INSERT INTO `wgi_trade_info` VALUES ('6', 'WGICB9103833', '23', '24', 'tang001', 'tang002', '/Public/Uploads/paypicture/2017-09-07/1504787340.png', '154', '155', '100.00', '90.00', null, '4', '2017-09-07 20:28:51', '2017-09-07 20:29:02', '2017-09-07 20:29:48', '2017-09-07', '2017-09-07 20:27:50', '0');

-- ----------------------------
-- Table structure for wgi_upgrade
-- ----------------------------
DROP TABLE IF EXISTS `wgi_upgrade`;
CREATE TABLE `wgi_upgrade` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `upsn` varchar(20) DEFAULT '' COMMENT '编号',
  `mid` int(10) DEFAULT '0' COMMENT '会员ID',
  `mname` varchar(32) DEFAULT '' COMMENT '会员姓名',
  `old_lv` int(10) DEFAULT '0' COMMENT '原级别',
  `new_lv` int(10) DEFAULT '0' COMMENT '新级别',
  `diff` decimal(10,2) DEFAULT '0.00' COMMENT '差价',
  `addtime` datetime DEFAULT NULL COMMENT '升级时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of wgi_upgrade
-- ----------------------------
INSERT INTO `wgi_upgrade` VALUES ('5', 'UP2596418', '24', 'tang002', '1', '2', '400.00', '2017-09-07 19:51:39');
